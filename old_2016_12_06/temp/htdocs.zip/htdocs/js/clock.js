﻿function Clock()
{
	var Hour = eval(document.getElementById('ClockHour').innerHTML);
	var Minute = eval(document.getElementById('ClockMinute').innerHTML);
	var Second = eval(document.getElementById('ClockSecond').innerHTML);

	Second += 1;

	if (Second == 60)
	{
		Second = 0;
		Minute += 1;

		if (Minute == 60)
		{
			Minute = 0;
			Hour += 1;

			if (Hour == 24)
				Hour = 0;

			if (Hour < 10)
				Hour = '0' + Hour;

			document.getElementById('ClockHour').innerHTML = Hour;
		}

		if (Minute < 10)
			Minute = '0' + Minute;

		document.getElementById('ClockMinute').innerHTML = Minute;
	}

	if (Second < 10)
		Second = '0' + Second;

	document.getElementById('ClockSecond').innerHTML = Second;

	setTimeout(Clock, 1000);
}

function ClockStart()
{
	setTimeout(Clock, 1000);
}