function ukaz_odkaz_podkategorie(id)
{
	document.getElementById('odkaz_podkategorie_' + id).style.display = 'inline';
}

function ukaz_odkaz_upravit(id)
{
	document.getElementById('odkaz_upravit_' + id).style.display = 'inline';
}

function ukaz_odkaz_polozka(id)
{
	document.getElementById('odkaz_polozka_' + id).style.display = 'inline';
}

function skryj_odkaz_podkategorie(id)
{
	document.getElementById('odkaz_podkategorie_' + id).style.display = 'none';
}

function skryj_odkaz_upravit(id)
{
	document.getElementById('odkaz_upravit_' + id).style.display = 'none';
}

function skryj_odkaz_polozka(id)
{
	document.getElementById('odkaz_polozka_' + id).style.display = 'none';
}

function ukaz_form_podkategorie(id)
{
	document.getElementById('podkategorie_' + id).style.display = 'block';
}

function ukaz_form_polozka(id)
{
	document.getElementById('polozka_' + id).style.display = 'block';
}

function printpage()
{
	window.print();
}

function zmen_barvu_pozadi_o(id, barva)
{
	if (document.getElementById(id).style.background == '#fff' || document.getElementById(id).style.background == 'none repeat scroll 0% 0% rgb(255, 255, 255)' || document.getElementById(id).style.background == 'rgb(255, 255, 255)'){
		document.getElementById(id).style.background = barva;
		document.getElementById('o_t_'+id).focus();
	} else {
		document.getElementById(id).style.background = '#FFF';
	}
}

function oznaceni_checkboxu(id){
	if (document.getElementById(id).checked == true){
		document.getElementById(id).checked = false;
	} else {
		document.getElementById(id).checked = true;
	}
}

function oznaceni_optionu(id){
	document.getElementById(id).checked = true;
}

function rozdil_casu(){
	var x = document.getElementById('datum_od').value;
	var y = document.getElementById('datum_do').value;
	var xa = x.split(/\D/), ya = y.split(/\D/);
	var xd = Date.UTC(xa[2], xa[1]-1, xa[0]), yd = Date.UTC(ya[2], ya[1]-1, ya[0]);
	document.getElementById('pocet_dni').value = ((yd - xd)/86400000);
}

function ukaz_skryj(kam)
{
	if (document.getElementById(kam).style.display == 'none'){
		document.getElementById(kam).style.display = 'block';
	} else {
		document.getElementById(kam).style.display = 'none';
	}
}

function ukaz_odkaz_smazat(id)
{
	document.getElementById('odkaz_smazat_' + id).style.display = 'inline';
}

function skryj_odkaz_odpoved(id)
{
	document.getElementById('odkaz_odpovedet_' + id).style.display = 'none';
}

function skryj_odkaz_smazat(id)
{
	document.getElementById('odkaz_smazat_' + id).style.display = 'none';
}

function ukaz_form_odpoved(id)
{
	document.getElementById('odpoved_' + id).style.display = 'block';
	document.getElementById('area_' + id).focus();
}

function ukaz_form_smazat(id)
{
	document.getElementById('smazat_' + id).style.display = 'inline';
}

function skryj_form_smazat(id)
{
	document.getElementById('smazat_' + id).style.display = 'none';
}

function ukaz_form_smazat_vyrobek(id)
{
	document.getElementById('smazat_vyrobek_' + id).style.display = 'inline';
}

function skryj_form_smazat_vyrobek(id)
{
	document.getElementById('smazat_vyrobek_' + id).style.display = 'none';
}

function ukaz_form_kopirovat_vyrobek(id)
{
	document.getElementById('kopirovat_vyrobek_' + id).style.display = 'inline';
}

function skryj_form_kopirovat_vyrobek(id)
{
	document.getElementById('kopirovat_vyrobek_' + id).style.display = 'none';
}

function ajax(stranka, kam) 
{
    var httpRequest;

    if(typeof window.ActiveXObject != 'undefined') 
	{
		httpRequest = new ActiveXObject("Microsoft.XMLHTTP");
	}
	else
	{  
		httpRequest = new XMLHttpRequest();
	}

	httpRequest.open("GET", stranka, true);
	httpRequest.onreadystatechange= function () 
	{
        processRequest(httpRequest, kam) 
    };
	httpRequest.send(null);
}

function processRequest(httpRequest, kam) 
{
	if (httpRequest.readyState == 4) 
	{
        if (( httpRequest.status >= 200 && httpRequest.status < 300 ) || httpRequest.status == 304) 
		{
            if (typeof kam == 'string') 
			{
                document.getElementById(kam).innerHTML = httpRequest.responseText;
            }
        }
        else
        {
            alert("Chyba pri nacitani stanky " + httpRequest.status +" : "+ httpRequest.statusText);
        }
    }
    else
    {
        document.getElementById(kam).innerHTML = ' <img src="files/loading.gif" height="12px" />';
    }
}

function pocet_exp(vyexpedovano, id){
	var pocet = document.getElementById('pocet_' + id).value;
	if (pocet > vyexpedovano){
		document.getElementById('pocet_' + id).style.background = '#F55';
		document.getElementById('pocet_div_' + id).innerHTML = ' <span style="background: #F55; font-size: 10px;">Chcete expedovat více, než je zadáno do výroby.</span>';
	} else if (pocet < vyexpedovano){
		document.getElementById('pocet_' + id).style.background = '#AEF';
		document.getElementById('pocet_div_' + id).innerHTML = ' <span style="background: #AEF; font-size: 10px;">Chcete expedovat méně, než je zadáno do výroby.</span>';
	} else {
		document.getElementById('pocet_' + id).style.background = '#5F5';
		document.getElementById('pocet_div_' + id).innerHTML = ' <span style="background: #5F5; font-size: 10px;"></span>';
	}
}