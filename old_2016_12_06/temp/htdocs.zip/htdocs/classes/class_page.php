<?php 
class page {
	var $_head_path;
	var $_title;
	var $_path_dir;
	var $_path_file;
	
	function page() {
		$this->_title = "Obal-tisk, s.r.o.";
		$this->get_data();
		$this->_head_path="/";
	}
	
	//funkce, ktera na zaklade _GET['show'] vrati, co se ma v obsahu zobrazit
	function get_data() {
		if (isset($_SESSION['ot_userId'])) {
			$this->_path_dir = 'zakazky';
			$this->_path_file = 'zakazky';
			$_SESSION['id_menu']=200;
			
			if (isset($_GET['show'])) {
				switch ($_GET['show']) {
					case 'zakazky':
						$this->_title .= ' - Seznam zakázek';
						$this->_path_dir = 'zakazky';
						$this->_path_file = 'zakazky';
						$_SESSION['id_menu']=200;
						break;
					
					case 'zakazka_new':
						$this->_title .= ' - Nová zakázka';
						$this->_path_dir = 'zakazky';
						$this->_path_file = 'zakazka_new';
						$_SESSION['id_menu']=200;
						break;
					
					case 'zakazka_show':
						$this->_title .= ' - Zakázka';
						$this->_path_dir = 'zakazky';
						$this->_path_file = 'zakazka_show';
						$_SESSION['id_menu']=200;
						break;
						
					case 'zakazka_vykony':
						$this->_title .= ' - Zakázka';
						$this->_path_dir = 'zakazky';
						$this->_path_file = 'zakazka_vykony';
						$_SESSION['id_menu']=200;
						break;	
						
					case 'zakazka_expedice':
						$this->_title .= ' - Expedice zakázky';
						$this->_path_dir = 'zakazky';
						$this->_path_file = 'zakazka_expedice';
						$_SESSION['id_menu']=200;
						break;	
						
					case 'zakazka_edit':
						$this->_title .= ' - Zakázka';
						$this->_path_dir = 'zakazky';
						$this->_path_file = 'zakazka_edit';
						$_SESSION['id_menu']=200;
						break;
					
					case 'zak_vyrobek_edit':
						$this->_title .= ' - Editace materiálu v zakázce';
						$this->_path_dir = 'zakazky';
						$this->_path_file = 'zak_vyrobek_edit';
						$_SESSION['id_menu']=200;
						break;					
					
					case 'zak_material_edit':
						$this->_title .= ' - Editace materiálu v zakázce';
						$this->_path_dir = 'zakazky';
						$this->_path_file = 'zak_material_edit';
						$_SESSION['id_menu']=200;
						break;	

					case 'zakazka_soubory':
						$this->_title .= ' - Soubory přiřazené k zakázce';
						$this->_path_dir = 'zakazky';
						$this->_path_file = 'zakazka_soubory';
						$_SESSION['id_menu']=200;
						break;
					
					case 'zak_soubory_edit':
						$this->_title .= ' - Editace názvu souboru';
						$this->_path_dir = 'zakazky';
						$this->_path_file = 'zak_soubory_edit';
						$_SESSION['id_menu']=200;
						break;					
					
					case 'dodaci_listy':
						$this->_title .= ' - Dodací listy';
						$this->_path_dir = 'dodaci_listy';
						$this->_path_file = 'dodaci_listy';
						$_SESSION['id_menu']=300;
						break;	
					
					case 'dodaci_list':
						$this->_title .= ' - Dodací list';
						$this->_path_dir = 'dodaci_listy';
						$this->_path_file = 'dodaci_list';
						$_SESSION['id_menu']=300;
						break;
						
					case 'expedice':
						$this->_title .= ' - Expedice zakázek';
						$this->_path_dir = 'dodaci_listy';
						$this->_path_file = 'expedice';
						$_SESSION['id_menu']=300;
						break;	
					
					case 'sklady':
						$this->_title .= ' - Sklady';
						$this->_path_dir = 'sklady';
						$this->_path_file = 'sklady';
						$_SESSION['id_menu']=400;
						break;	
					
					case 'sklad_edit':
						$this->_title .= ' - Editace skladu';
						$this->_path_dir = 'sklady';
						$this->_path_file = 'sklad_edit';
						$_SESSION['id_menu']=400;
						break;
						
					case 'sklady_prehled':
						$this->_title .= ' - Přehled stavu ve skladech';
						$this->_path_dir = 'sklady';
						$this->_path_file = 'sklady_prehled';
						$_SESSION['id_menu']=400;
						break;	
					
					case 'polozka_edit':
						$this->_title .= ' - Editace skladové položky';
						$this->_path_dir = 'sklady';
						$this->_path_file = 'polozka_edit';
						$_SESSION['id_menu']=400;
						break;

					case 'polozka_sjednoceni':
						$this->_title .= ' - Sjednocení skladové položky';
						$this->_path_dir = 'sklady';
						$this->_path_file = 'polozka_sjednoceni';
						$_SESSION['id_menu']=400;
						break;
						
					case 'polozka_spotrebovano':
						$this->_title .= ' - Skladová položka po příjemkách';
						$this->_path_dir = 'sklady';
						$this->_path_file = 'polozka_spotrebovano';
						$_SESSION['id_menu']=400;
						break;
						
					case 'polozka_kons_spotrebovano':
						$this->_title .= ' - Skladová položka po příjemkách';
						$this->_path_dir = 'sklady';
						$this->_path_file = 'polozka_kons_spotrebovano';
						$_SESSION['id_menu']=400;
						break;
					
					case 'prijemky':
						$this->_title .= ' - Příjemky';
						$this->_path_dir = 'sklady';
						$this->_path_file = 'prijemky';
						$_SESSION['id_menu']=400;
						break;
						
					case 'prijemka_new':
						$this->_title .= ' - Nová příjemka';
						$this->_path_dir = 'sklady';
						$this->_path_file = 'prijemka_new';
						$_SESSION['id_menu']=400;
						break;
						
					case 'prijemka_edit':
						$this->_title .= ' - Editace příjemky';
						$this->_path_dir = 'sklady';
						$this->_path_file = 'prijemka_edit';
						$_SESSION['id_menu']=400;
						break;
						
					case 'prijemka_show':
						$this->_title .= ' - Náhled na příjemku';
						$this->_path_dir = 'sklady';
						$this->_path_file = 'prijemka_show';
						$_SESSION['id_menu']=400;
						break;
						
					case 'vydejky':
						$this->_title .= ' - Výdejky';
						$this->_path_dir = 'sklady';
						$this->_path_file = 'vydejky';
						$_SESSION['id_menu']=400;
						break;
						
					case 'vydejka_new':
						$this->_title .= ' - Nová výdejka';
						$this->_path_dir = 'sklady';
						$this->_path_file = 'vydejka_new';
						$_SESSION['id_menu']=400;
						break;
						
					case 'vydejka_edit':
						$this->_title .= ' - Editace výdejky';
						$this->_path_dir = 'sklady';
						$this->_path_file = 'vydejka_edit';
						$_SESSION['id_menu']=400;
						break;
						
					case 'vydejka_kons_new':
						$this->_title .= ' - Nová výdejka z konsignačního skladu';
						$this->_path_dir = 'sklady';
						$this->_path_file = 'vydejka_kons_new';
						$_SESSION['id_menu']=400;
						break;
						
					case 'vydejka_kons_edit':
						$this->_title .= ' - Editace výdejky z konsignačního skladu';
						$this->_path_dir = 'sklady';
						$this->_path_file = 'vydejka_kons_edit';
						$_SESSION['id_menu']=400;
						break;
						
					case 'vydejka_show':
						$this->_title .= ' - Náhled na výdejku';
						$this->_path_dir = 'sklady';
						$this->_path_file = 'vydejka_show';
						$_SESSION['id_menu']=400;
						break;
						
					case 'prehledy':
						$this->_title .= ' - Přehled výrobků';
						$this->_path_dir = 'zakazky';
						$this->_path_file = 'prehledy';
						$_SESSION['id_menu']=500;
						break;
					
					case 'reklamace':
						$this->_title .= ' - Seznam reklamací';
						$this->_path_dir = 'reklamace';
						$this->_path_file = 'reklamace';
						$_SESSION['id_menu']=550;
						break;	
						
					case 'reklamace_new':
						$this->_title .= ' - Nová reklamace';
						$this->_path_dir = 'reklamace';
						$this->_path_file = 'reklamace_new';
						$_SESSION['id_menu']=550;
						break;
						
					case 'reklamace_show':
						$this->_title .= ' - Reklamace';
						$this->_path_dir = 'reklamace';
						$this->_path_file = 'reklamace_show';
						$_SESSION['id_menu']=550;
						break;
					
					case 'firmy':
						$this->_title .= ' - Seznam firem';
						$this->_path_dir = 'firmy';
						$this->_path_file = 'firmy';
						$_SESSION['id_menu']=600;
						break;
					
					case 'firma_edit':
						$this->_title .= ' - Editace firmy';
						$this->_path_dir = 'firmy';
						$this->_path_file = 'firma_edit';
						$_SESSION['id_menu']=600;
						break;
						
					case 'firmy_dodavatelu':
						$this->_title .= ' - Seznam firem';
						$this->_path_dir = 'firmy_dodavatelu';
						$this->_path_file = 'firmy';
						$_SESSION['id_menu']=600;
						break;
					
					case 'firma_dodavatelu_edit':
						$this->_title .= ' - Editace dodavatelské firmy';
						$this->_path_dir = 'firmy_dodavatelu';
						$this->_path_file = 'firma_edit';
						$_SESSION['id_menu']=600;
						break;
						
					case 'vyrobek_edit':
						$this->_title .= ' - Editace výrobku';
						$this->_path_dir = 'vyrobky';
						$this->_path_file = 'vyrobek_edit';
						$_SESSION['id_menu']=600;
						break;
					
					case 'materialy':
						$this->_title .= ' - Seznam materialů';
						$this->_path_dir = 'materialy';
						$this->_path_file = 'materialy';
						$_SESSION['id_menu']=600;
						break;
					
					case 'material_edit':
						$this->_title .= ' - Editace materialu';
						$this->_path_dir = 'materialy';
						$this->_path_file = 'material_edit';
						$_SESSION['id_menu']=600;
						break;
						
					case 'hodnoty_atributu':
						$this->_title .= ' - Hodnoty atributu';
						$this->_path_dir = 'hodnoty_atributu';
						$this->_path_file = 'hodnoty_atributu';
						$_SESSION['id_menu']=600;
						break;
						
					case 'baleni':
						$this->_title .= ' - Seznam balení';
						$this->_path_dir = 'baleni';
						$this->_path_file = 'baleni';
						$_SESSION['id_menu']=600;
						break;
						
					case 'baleni_edit':
						$this->_title .= ' - Editace balení';
						$this->_path_dir = 'baleni';
						$this->_path_file = 'baleni_edit';
						$_SESSION['id_menu']=600;
						break;
						
					case 'operace_vnitrni':
						$this->_title .= ' - Seznam balení';
						$this->_path_dir = 'operace_vnitrni';
						$this->_path_file = 'operace_vnitrni';
						$_SESSION['id_menu']=600;
						break;
						
					case 'operace_vnitrni_edit':
						$this->_title .= ' - Editace vnitřní operace';
						$this->_path_dir = 'operace_vnitrni';
						$this->_path_file = 'operace_vnitrni_edit';
						$_SESSION['id_menu']=600;
						break;
						
					case 'operace_vnejsi':
						$this->_title .= ' - Seznam balení';
						$this->_path_dir = 'operace_vnejsi';
						$this->_path_file = 'operace_vnejsi';
						$_SESSION['id_menu']=600;
						break;
						
					case 'operace_vnejsi_edit':
						$this->_title .= ' - Editace vnitřní operace';
						$this->_path_dir = 'operace_vnejsi';
						$this->_path_file = 'operace_vnejsi_edit';
						$_SESSION['id_menu']=600;
						break;
						
					case 'lakovani':
						$this->_title .= ' - Seznam lakování';
						$this->_path_dir = 'lakovani';
						$this->_path_file = 'lakovani';
						$_SESSION['id_menu']=600;
						break;
						
					case 'lakovani_edit':
						$this->_title .= ' - Editace lakování';
						$this->_path_dir = 'lakovani';
						$this->_path_file = 'lakovani_edit';
						$_SESSION['id_menu']=600;
						break;
						
					case 'vysekove_formy':
						$this->_title .= ' - Seznam výsekových forem';
						$this->_path_dir = 'vysekove_formy';
						$this->_path_file = 'vysekove_formy';
						$_SESSION['id_menu']=600;
						break;
						
					case 'vysekove_formy_edit':
						$this->_title .= ' - Editace výsekové formy';
						$this->_path_dir = 'vysekove_formy';
						$this->_path_file = 'vysekove_formy_edit';
						$_SESSION['id_menu']=600;
						break;
						
					case 'vys_for_soubory':
						$this->_title .= ' - Soubory k výsekové formě';
						$this->_path_dir = 'vysekove_formy';
						$this->_path_file = 'vys_for_soubory';
						$_SESSION['id_menu']=600;
						break;
						
					case 'vys_for_soubory_edit':
						$this->_title .= ' - Editace souboru k výsekové formě';
						$this->_path_dir = 'vysekove_formy';
						$this->_path_file = 'vys_for_soubory_edit';
						$_SESSION['id_menu']=600;
						break;
						
					case 'user_edit':
						$this->_title .= ' - Editace uživatele';
						$this->_path_dir = 'user';
						$this->_path_file = 'user_edit';
						$_SESSION['id_menu']=800;
						break;
						
					case 'user_logout':
						$this->_title .= ' - Odhlášení uživatele';
						$this->_path_dir = 'user';
						$this->_path_file = 'user_logout';
						$_SESSION['id_menu']=101;
						break;
					
					case 'users':
						$this->_title .= ' - Seznam uživatelů';
						$this->_path_dir = 'user';
						$this->_path_file = 'users';
						$_SESSION['id_menu']=800;
						break;
					
					default:
						$this->_path_dir = 'main';
						$this->_path_file = 'news';
				}
			}
		} else {
			$this->_path_dir = 'user';
			$this->_path_file = 'user_login';
			switch ($_GET['show']) {
					case 'user_login':
						$this->_title .= ' - Přihlášení uživatele';
						$this->_path_dir = 'user';
						$this->_path_file = 'user_login';
						$_SESSION['id_menu']=100;
						break;
					
					case 'forget_password':
						$this->_title .= ' - Reset hesla';
						$this->_path_dir = 'user';
						$this->_path_file = 'forget_password';
						$_SESSION['id_menu']=100;
						break;
						
					default:
						$this->_path_dir = 'user';
						$this->_path_file = 'user_login';
						$_SESSION['id_menu']=100;
				}
		}
	}
}
?>