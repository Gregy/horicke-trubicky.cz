<?php
	class mysql {
		var $db_host = '127.0.0.1';
		var $db_user = 'root';
		var $db_psw = '';
		var $db = 'obaltisk';

		function mysql() {
			$this->connect();
			$this->select_db();
		}

		// mysql_connect
		function connect() {
			$connection = @mysql_connect($this->db_host, $this->db_user, $this->db_psw);
			
			if (!empty($connection)) {
				@mysql_query("SET CHARACTER SET utf8");
				@mysql_query("SET NAMES utf8");
				
				return $connection;
			}
			else {
				echo 'Nepodařilo se připojit k serveru.';
				exit;
			}
		}

		// mysql_select_db
		function select_db() {
			$connection = @mysql_select_db($this->db);
			
			if (!empty($connection)) {
				return $connection;
			}
			else {
				echo 'Nepodařilo se připojit k databázi.';
				exit;
			}
		}

		// mysql_query
		function query($query) {
			$result = @mysql_query("$query");
			
			if (!empty($result)) {
				return $result;
			}
			else {		
				echo "SQL <b>$query</b> neproběhl správně.<br />";
				return 0;
			}
		}

		// mysql_num_rows
		function num_rows($result) {
			return @mysql_num_rows($result);
		}

		// mysql_fetch_array
		function fetch_array($result) {
			return @mysql_fetch_array($result);
		}

		// mysql_query + mysql_fetch_array
		function query_array($query) {
			$result = $this->query($query);

			return $this->fetch_array($result);
		}

		// mysql_insert_id
		function insert_id() {
			return @mysql_insert_id();
		}

		function affected_rows() {
			return @mysql_affected_rows();
		}

		// mysql_error
		function error() {
			return @mysql_error();
		}

		function num_fields($result) {
			return @mysql_num_fields($result);
		}

		function field_name($result, $i) {
			return @mysql_field_name($result, $i);
		}

	}
?>