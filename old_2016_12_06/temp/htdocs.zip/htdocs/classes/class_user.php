<?php 
	class classUser {
		var $mUserName;
		var $mUserId;
		var $mRights;
		
		function classUser() {
			if (isset($_SESSION['cp_userId'])){
				$this->mUserId=$_SESSION['cp_userId'];
				$this->mUserName=$_SESSION['cp_userName'];
			}
			$mRightsCount = 0;
			if ($this->isLogged()) $this->initalizeRights();
		}
		
		function login_akord($userId, $userName, $userGroup){
			$this->mUserId=$userId;
			$this->mUserName=$userName;
			$this->mUserGroup=$userGroup;
			$this->setSession($this->mUserId, $this->mUserName);
		}
		
		function logout(){
			unset($_SESSION['cp_userId']);
			unset($_SESSION['cp_userName']);
		}
		
		function isLogged(){
			if (isset($this->mUserId)){
				return 1;
			} else {
				return 0;
			}
		}
		
		function initalizeRights(){
			global $sql;
			$id_uzivatel=$this->userId();
			$rows=$sql->query("SELECT pravo FROM cp_prava p
								JOIN cp_uzivatel_prava up ON p.id_pravo = up.id_pravo
								WHERE up.id_uzivatel=$id_uzivatel");
			$i = 0;
			
			while($row = $sql->fetch_array($rows)){
				$this->mRights[$i] = $row['pravo'];
				$i++;
			}
		}
		
		function haveRight($right){
			if (isset($this->mRights)){
				foreach ($this->mRights as $row){
					if ($row == $right)
						return 1;
				}
			}
			return 0;
		}
		
		function userId(){
			return $this->mUserId;
		}
		
		function setSession($userId, $userName){
			$_SESSION['cp_userId']=$userId;
			$_SESSION['cp_userName']=$userName;
		}
	}
?>