INSERT INTO  `obaltisk`.`prava` (`id_pravo` ,`pravo`) VALUES (NULL ,  'ZAKAZKY_SOUBORY');

CREATE TABLE  `obaltisk`.`zak_soubory` (
`id_zak_souboru` INT NOT NULL AUTO_INCREMENT ,
`id_zakazky` INT NOT NULL ,
`nazev_souboru` VARCHAR( 100 ) NOT NULL ,
`cesta` VARCHAR( 255 ) NOT NULL ,
`editoval` INT NOT NULL ,
`datum_editace` BIGINT NOT NULL ,
`smazano` INT NOT NULL ,
PRIMARY KEY (  `id_zak_souboru` )
) ENGINE = MYISAM


CREATE TABLE  `vys_for_soubory` (
 `id_vys_for_souboru` INT( 11 ) NOT NULL AUTO_INCREMENT ,
 `id_vysekove_formy` INT( 11 ) NOT NULL ,
 `nazev_souboru` VARCHAR( 100 ) COLLATE utf8_czech_ci NOT NULL ,
 `cesta` VARCHAR( 255 ) COLLATE utf8_czech_ci NOT NULL ,
 `editoval` INT( 11 ) NOT NULL ,
 `datum_editace` BIGINT( 20 ) NOT NULL ,
 `smazano` INT( 11 ) NOT NULL ,
PRIMARY KEY (  `id_vys_for_souboru` )
) ENGINE = MYISAM DEFAULT CHARSET = utf8 COLLATE = utf8_czech_ci AUTO_INCREMENT =1;

CREATE TABLE  `obaltisk`.`zak_vys_for_soubory` (
`id_zak_vys_for_souboru` INT NOT NULL AUTO_INCREMENT ,
`id_zak_vyr_vysekove_formy` INT NOT NULL ,
`nazev_souboru` VARCHAR( 100 ) NOT NULL ,
`cesta` VARCHAR( 255 ) NOT NULL ,
PRIMARY KEY (  `id_zak_vys_for_souboru` )
) ENGINE = MYISAM