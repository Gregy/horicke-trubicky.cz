<?php
	if ($_GET['id']){
		$id_galerie=$_GET['id'];
	}
	if (check_rights('5')==1){
		if ($_POST['save']=="Uložit"){
			$error="";
			$id_galerie=$_POST['id_galerie'];
			
			for ($i=1; $i<=9; $i++){
				$foto="foto".$i;
				$name=$_FILES["$foto"]["name"];
				$local_error="";
				if ($_FILES["$foto"]["name"]!=""){
					if ($_FILES["$foto"]["size"]>1048576){
						$local_error.="příliš velký";
						$error.="<p class=\"chyba\">Soubor \"$name\" je příliš velký (max.velikost - 1 MB (1 048 576 B)).</p>";
					}
					$file_types=array("gif","jpeg","jpg","jpe","png");
					$extention=strtolower (substr($_FILES["$foto"]["name"],-3));
					foreach($file_types as $file_type){
						if($file_type == $extention){
							$continue = true;
						}
			        }
					
					if (!isset($continue)){
						$local_error.="špatný typ";
						$error.="<p class=\"chyba\">Soubor \"$name\" není správného typu. Musí být jeden z těchto: " 
								. implode(", ", $file_types) . ").</p>";
					}
					
					if ($local_error==""){
						$upload_dir="temp";
						$resize_dir="files/foto";
						move_uploaded_file($_FILES["$foto"]["tmp_name"], "$upload_dir/$name");
						
						$uploaded_image="$upload_dir/$name";
						$newname=$name;
						while (file_exists ($upload_dir."/".$newname)) {
							$newname=(chr (rand(65,90))).(chr (rand(65,90))).(chr (rand(65,90))).(chr (rand(65,90))).
									(chr (rand(65,90))).(chr (rand(65,90))).(chr (rand(65,90))).(chr (rand(65,90))).$name;
						}
						$finish_image=$resize_dir. "/" . $newname;
						$finish_image_overview=$resize_dir. "/over_" . $newname;
						
						switch ($extention){
							case "gif":  $im=imagecreatefromgif ($uploaded_image); break;
							case "jpg":  $im=imagecreatefromjpeg ($uploaded_image); break;
							case "jpeg": $im=imagecreatefromjpeg ($uploaded_image); break;
							case "png":  $im=imagecreatefrompng ($uploaded_image); break;
						}
						$x=imagesx($im);
						$y=imagesy($im);
						$pomer_stran=$x/$y;
						
						($y<500) ? $high=$y : $high=500;
						
						$high_overview=120;
						
						if (($x/$y)>1){
							$tmp_image=imagecreatetruecolor($high*$pomer_stran,$high);
							imagecopyresized($tmp_image, $im, 0, 0, 0, 0, $high*$pomer_stran, $high, $x, $y);
							$tmp_image_overview=imagecreatetruecolor($high_overview*$pomer_stran,$high_overview);
							imagecopyresized($tmp_image_overview, $im, 0, 0, 0, 0, $high_overview*$pomer_stran, $high_overview, $x, $y);
						} else {
							$tmp_image=imagecreatetruecolor($high*$pomer_stran,$high);
							imagecopyresized($tmp_image, $im, 0, 0, 0, 0, $high*$pomer_stran, $high, $x, $y);
							$tmp_image_overview=imagecreatetruecolor($high_overview*$pomer_stran,$high_overview);
							imagecopyresized($tmp_image_overview, $im, 0, 0, 0, 0, $high_overview*$pomer_stran, $high_overview, $x, $y);
						}
						
						unset($im);
						
						imagejpeg($tmp_image, $finish_image);
						imagejpeg($tmp_image_overview, $finish_image_overview);
						
						$date = StrFTime("%d.%m.%Y", Time());
						$sql->query("insert into `galerie_foto` values ('','','$finish_image_overview','$finish_image',
									'$id_galerie','$_SESSION[user_id]','$date','1')");
						$insert_id=$sql->insert_id();
						
						$error.="<p class=\"oznameni\">$name byl v pořádku uložen.</p>";
						
						delete_file($upload_dir . "/" . $name);
					}
				}	
			}
		}
		
		if ($error!=""){
			echo "<hr />" . $error . "<hr />";
		}
		?>
		<div style="text-align:center; margin-bottom:10px; padding-bottom:4px; border-bottom: solid 1px #888;">
			<? 
				$temp=$sql->query_array("select * from `galerie` where id='$id_galerie'");
				$galerie_name=iso2ascii($temp['galerie_name']);
			?>
			<a href="fotogalerie-<?php echo $id_galerie . "-" . $galerie_name;?>">Zpět do galerie</a>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<a href="fotogalerie">Zpět na seznam fotogalerií</a>
		</div>

		<form action="" method="post" enctype="multipart/form-data">
			<div style="text-align:center;">
				<input type="submit" name="save" value="Uložit" />
			</div>
			<table cellspacing="0" cellpadding="5" border="0" width="100%">
			<?php
				echo "<tr>";
					echo "<td><b>Galerie</b><br /><br /></td>";
					echo "<td><select name=\"id_galerie\" >";
						$result=$sql->query("SELECT * FROM `galerie` WHERE 1");
						while ($row=$sql->fetch_array($result)){
							if ($row["id"]==$id_galerie)
								echo("<OPTION value=\"$row[id]\" selected=\"selected\">$row[galerie_name]</OPTION>");
							else 
								echo("<OPTION value=\"$row[id]\">$row[galerie_name]</OPTION>");
						}
					echo "</select><br /><br /></td>";
				echo "</tr>";
				
				for ($i=1; $i<=9; $i++){
					?>
					<tr>
						<td><?php echo $i;?>. foto</td> 
						<td><input type="file" name="foto<?php echo $i;?>" size="60" /></td>
					</tr>
					<?php
				}
				?>
			</table>
		</form>
	<?php
	} else echo "<p class=\"chyba\">Na toto nemáte přirazená práva.</p>";
?>