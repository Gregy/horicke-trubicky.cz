<div class="definice">
<?
if (haveRight('OPERACE_VNEJSI')){
	if (isset($_GET['id_operace_vnejsi'])){
		global $sql;
		$temp=$sql->query_array("SELECT id_operace_vnejsi, nazev_operace_vnejsi FROM operace_vnejsi WHERE id_operace_vnejsi='$_GET[id_operace_vnejsi]'");
		$id_operace_vnejsi = $temp['id_operace_vnejsi'];
		$nazev_operace_vnejsi = $temp['nazev_operace_vnejsi'];
	}
	
	if ($_POST['save']=="Uložit"){
		$error="";
		if (isset($_POST['id_operace_vnejsi']))
			$id_operace_vnejsi = $_POST['id_operace_vnejsi'];
		$nazev_operace_vnejsi = $_POST['nazev_operace_vnejsi'];
		
		$error.=(empty($nazev_operace_vnejsi)) ? "<p class=\"chyba\">Nebyl zadán název operace.</p>" : "";
	}
	
		if ($error=="" && $_POST['save']=="Uložit"){
			$nazev_operace_vnejsi=check_input($nazev_operace_vnejsi);
			$datum_editace = Time();
			if (isset($id_operace_vnejsi)){
				$sql->query("UPDATE operace_vnejsi SET nazev_operace_vnejsi='$nazev_operace_vnejsi', editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace' WHERE id_operace_vnejsi=$id_operace_vnejsi");
			} else {
				$temp = $sql->query_array("SELECT max(poradi) max_poradi FROM operace_vnejsi");
				$max_poradi = $temp['max_poradi']+100;
				$sql->query("INSERT INTO operace_vnejsi VALUES (NULL, '$nazev_operace_vnejsi', $max_poradi, '$_SESSION[ot_userId]', '$datum_editace', '0')");
				$id_operace_vnejsi=$sql->insert_id();
			}
			
			$saved=1;
			echo "<p class=\"oznameni\">Kooperace v pořádku uložena.</p>";
			$refresh_page=$page->_head_path . "?show=operace_vnejsi";
			echo "<meta http-equiv=\"refresh\" content=\"1; url=$refresh_page\">";
			message_auto_forward($refresh_page);
		} else if ($error!=""){
			echo "<hr /><b>" . $error . "</b><hr />";
		}
		if ($saved==0){
			?>
			<form action="" method="post" name="operace_vnejsi">
				<div style="text-align: center; padding: 5px; border-bottom: #aaa 1px dashed;">
					<input type="submit" name="save" value="Uložit" id="ulozit" />
					<span style="padding-left: 100px">
						<a href="?show=operace_vnejsi" class="zpet">Zpět na seznam kooperací (bez uložení)</a>
					</span>
				</div>
				
				<?php
					if (isset($id_operace_vnejsi)){
						?>
						<input type="hidden" name="id_operace_vnejsi" value="<?echo $id_operace_vnejsi;?>" />
						<?
					}
				?>
				<table cellspacing="0" cellpadding="5" border="0" width="60%" align="center">
					<tr>
						<td><b>Název koperace</b> (*)</td>
						<td><input id="nazev_operace_vnejsi" type="text" size="30" maxlength="100" name="nazev_operace_vnejsi" value="<?php echo "$nazev_operace_vnejsi";?>" /></td>
					</tr>
				</table>
				<br />(*) - povinné položky
			</form>
			<script type="text/javascript"> document.getElementById("nazev_operace_vnejsi").focus(); </script>
			<?php
		}
} else echo "<p class=\"chyba\">Na toto nemáte přiřazená práva.</p>";
?>
</div>