<div class="definice">
<?
if (haveRight('BALENI')){
	if (isset($_GET['id_baleni'])){
		global $sql;
		$temp=$sql->query_array("SELECT id_baleni, nazev_baleni FROM baleni WHERE id_baleni='$_GET[id_baleni]'");
		$id_baleni = $temp['id_baleni'];
		$nazev_baleni = $temp['nazev_baleni'];
	}
	
	if ($_POST['save']=="Uložit"){
		$error="";
		if (isset($_POST['id_baleni']))
			$id_baleni = $_POST['id_baleni'];
		$nazev_baleni = $_POST['nazev_baleni'];
		
		$error.=(empty($nazev_baleni)) ? "<p class=\"chyba\">Nebyl zadán název balení.</p>" : "";
	}
	
		if ($error=="" && $_POST['save']=="Uložit"){
			$nazev_baleni=check_input($nazev_baleni);
			$datum_editace = Time();
			if (isset($id_baleni)){
				$sql->query("UPDATE baleni SET nazev_baleni='$nazev_baleni', editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace' WHERE id_baleni=$id_baleni");
			} else {
					$sql->query("INSERT INTO baleni VALUES (NULL, '$nazev_baleni', '$_SESSION[ot_userId]', '$datum_editace', '0')");
					$id_baleni=$sql->insert_id();
			}
			
			$saved=1;
			echo "<p class=\"oznameni\">Balení v pořádku uloženo.</p>";
			$refresh_page=$page->_head_path . "?show=baleni";
			echo "<meta http-equiv=\"refresh\" content=\"1; url=$refresh_page\">";
			message_auto_forward($refresh_page);
		} else if ($error!=""){
			echo "<hr /><b>" . $error . "</b><hr />";
		}
		if ($saved==0){
?>
		<form action="" method="post" name="baleni">
			<div style="text-align: center; padding: 5px; border-bottom: #aaa 1px dashed;">
				<input type="submit" name="save" value="Uložit" id="ulozit" />
				<span style="padding-left: 100px">
					<a href="?show=baleni" class="zpet">Zpět na seznam balení (bez uložení)</a>
				</span>
			</div>
			
			<?php
				if (isset($id_baleni)){
					?>
					<input type="hidden" name="id_baleni" value="<?echo $id_baleni;?>" />
					<?
				}
			?>
			<table cellspacing="0" cellpadding="5" border="0" width="50%" align="center">
				<tr>
					<td><b>Název balení</b> (*)</td>
					<td><input id="nazev_baleni" type="text" size="30" maxlength="100" name="nazev_baleni" value="<?php echo "$nazev_baleni";?>" /></td>
				</tr>
			</table>
			<br />(*) - povinné položky
		</form>
		<script type="text/javascript"> document.getElementById("nazev_baleni").focus(); </script>
		<?php
		}
} else echo "<p class=\"chyba\">Na toto nemáte přiřazená práva.</p>";
?>
</div>