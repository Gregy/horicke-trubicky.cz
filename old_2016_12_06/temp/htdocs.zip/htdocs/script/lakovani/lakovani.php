<div class="definice">
<?
if (haveRight('LAKOVANI')){
	include_once 'script/main/submenu.php';
	if (isset($_GET['smaz_id'])){
		$datum_editace = Time();
		$temp = $sql->query("SELECT v.nazev_vyrobku, f.nazev_firmy FROM vyrobky v 
							JOIN firmy f ON f.id_firmy = v.id_firmy
							WHERE v.id_lakovani=$_GET[smaz_id]");
		if ($sql->num_rows($temp)>0){
			echo "<p class=\"chyba\">Lakování nelze smazat. Je použité v definici následujících výrobků.</p>";
			while ($row=$sql->fetch_array($temp)){	
				echo "<p class=\"chyba\">$row[nazev_firmy] - $row[nazev_vyrobku].</p>";
			}
		} else {
			$sql->query("UPDATE lakovani SET smazano=1, editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace' WHERE id_lakovani=$_GET[smaz_id]");
		}
	}
	?>
	<div style="width: 100%; text-align:center; padding-bottom: 5px; font-size: 15px;">
		<div class="hlavicka"><a href="?show=lakovani_edit">Nové lakování</a></div>
	</div>
	<?
	$rows = $sql->query("SELECT l.id_lakovani, l.nazev_lakovani, l.datum_editace, u.name editoval FROM `lakovani` l
							JOIN `user` u ON u.id_uzivatel = l.editoval
						WHERE l.smazano=0
						ORDER BY l.nazev_lakovani");
						
	?>
	<table cellspacing="0" cellpadding="5" border="0" width="50%" align="center">
		<?
		$i=0;
		while ($row=$sql->fetch_array($rows)){
			(($i % 2)==0) ? $color="#ffe684" : $color="#EEE";
			$i++;
			$datum_editace = StrFTime("%d.%m.%Y %H:%M", $row['datum_editace']);
			?>
			<tr style="text-align:center; background-color: <?echo $color;?>;">
				<td style="text-align:left;">
					<?echo $row['nazev_lakovani'];?>
				</td>
				<td>
					<a href="?show=lakovani_edit&id_lakovani=<?echo $row['id_lakovani'];?>" style="text-decoration: none;" title="Naposledy editoval(a) <?echo $row['editoval'] . ' ' . $datum_editace;?>"><img src="files/edit.png" height="16px"></a>
				</td>
				<td style="width: 100px;">
					<span style="cursor: pointer;" id="odkaz_smazat_<?echo $row['id_lakovani'];?>"	onClick="ukaz_form_smazat(<?echo $row['id_lakovani'];?>)">
						<img src="files/smazat.png" height="16px">
					</span>
					<br />
					<span id="smazat_<?echo $row['id_lakovani'];?>" style="display: none;">
						<a href="?show=lakovani&smaz_id=<?echo $row['id_lakovani'];?>">Ano</a>
						<a style="margin-left: 20px;" href="javascript:void(0)" onclick="skryj_form_smazat(<?echo $row['id_lakovani'];?>)">Ne</a>
					</span>
				</td>
			</tr>
			<?
		}
		?>
	</table>
	<?
} else echo "<p class=\"chyba\">Na toto nemáte přiřazená práva.</p>";
?>
</div>