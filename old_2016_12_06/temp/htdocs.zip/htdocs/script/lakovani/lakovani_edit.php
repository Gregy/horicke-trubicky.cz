<div class="definice">
<?
if (haveRight('LAKOVANI')){
	if (isset($_GET['id_lakovani'])){
		global $sql;
		$temp=$sql->query_array("SELECT id_lakovani, nazev_lakovani FROM lakovani WHERE id_lakovani='$_GET[id_lakovani]'");
		$id_lakovani = $temp['id_lakovani'];
		$nazev_lakovani = $temp['nazev_lakovani'];
	}
	
	if ($_POST['save']=="Uložit"){
		$error="";
		if (isset($_POST['id_lakovani']))
			$id_lakovani = $_POST['id_lakovani'];
		$nazev_lakovani = $_POST['nazev_lakovani'];
		
		$error.=(empty($nazev_lakovani)) ? "<p class=\"chyba\">Nebyl zadán název lakovaní.</p>" : "";
	}
	
		if ($error=="" && $_POST['save']=="Uložit"){
			$nazev_lakovani=check_input($nazev_lakovani);
			$datum_editace = Time();
			if (isset($id_lakovani)){
				$sql->query("UPDATE lakovani SET nazev_lakovani='$nazev_lakovani', editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace' WHERE id_lakovani=$id_lakovani");
			} else {
					$sql->query("INSERT INTO lakovani VALUES (NULL, '$nazev_lakovani', '$_SESSION[ot_userId]', '$datum_editace', '0')");
					$id_lakovani=$sql->insert_id();
			}
			
			$saved=1;
			echo "<p class=\"oznameni\">Lakovaní v pořádku uloženo.</p>";
			$refresh_page=$page->_head_path . "?show=lakovani";
			echo "<meta http-equiv=\"refresh\" content=\"1; url=$refresh_page\">";
			message_auto_forward($refresh_page);
		} else if ($error!=""){
			echo "<hr /><b>" . $error . "</b><hr />";
		}
		if ($saved==0){
?>
		<form action="" method="post" name="lakovani">
			<div style="text-align: center; padding: 5px; border-bottom: #aaa 1px dashed;">
				<input type="submit" name="save" value="Uložit" id="ulozit" />
				<span style="padding-left: 100px">
					<a href="?show=lakovani" class="zpet">Zpět na seznam lakovaní (bez uložení)</a>
				</span>
			</div>
			
			<?php
				if (isset($id_lakovani)){
					?>
					<input type="hidden" name="id_lakovani" value="<?echo $id_lakovani;?>" />
					<?
				}
			?>
			<table cellspacing="0" cellpadding="5" border="0" width="50%" align="center">
				<tr>
					<td><b>Název lakovaní</b> (*)</td>
					<td><input id="nazev_lakovani" type="text" size="30" maxlength="100" name="nazev_lakovani" value="<?php echo "$nazev_lakovani";?>" /></td>
				</tr>
			</table>
			<br />(*) - povinné položky
		</form>
		<script type="text/javascript"> document.getElementById("nazev_lakovani").focus(); </script>
		<?php
		}
} else echo "<p class=\"chyba\">Na toto nemáte přiřazená práva.</p>";
?>
</div>