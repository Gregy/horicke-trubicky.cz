<?
	require_once '../../classes/class_mysql.php';
	$sql=new mysql;
	$sql->query("INSERT INTO vyrobek_vysekove_formy VALUES (NULL, $_GET[id_vysekove_formy], $_GET[id_vyrobku])");
	
	$result=$sql->query("SELECT vf.id_vysekove_formy, cislo_vysekove_formy, nazev_vysekove_formy, cislo_vysekove_formy, nazev_vysekove_formy, 
								ks_na_arch, min_rozmer_sirka, min_rozmer_delka, rozmer_obalu_sirka, rozmer_obalu_delka, rozmer_obalu_vyska
						FROM vysekove_formy vf
						JOIN vyrobek_vysekove_formy vvf ON vvf.id_vysekove_formy = vf.id_vysekove_formy
						WHERE smazano=0 and id_vyrobku=$_GET[id_vyrobku]
						ORDER BY nazev_vysekove_formy");
	while ($row=$sql->fetch_array($result)){
		echo $row['cislo_vysekove_formy'] . ' - ' . $row['nazev_vysekove_formy']  . ', ' . $row['ks_na_arch']  . ' ks/arch, min.roz.: ' . $row['min_rozmer_sirka'] 
			. 'x' . $row['min_rozmer_delka']  . ', roz.obalu: ' . $row['rozmer_obalu_sirka']  . 'x' . $row['rozmer_obalu_delka']  . 'x' . $row['rozmer_obalu_vyska'];
		?>
		<img src="files/smazat.png" onclick="ajax('script/vyrobky/aj_smazat_vys_formu.php?id_vyrobku=<?echo $_GET['id_vyrobku'];?>&id_vysekove_formy='+document.getElementById('id_vysekove_formy').value,'prir_vf');" height="13px" />
		<br />
		<?
	}
?>