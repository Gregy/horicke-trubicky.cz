<div class="definice">
<?
if (haveRight('VYROBKY')){
	if (isset($_GET['id_vyrobku'])){
		global $sql;
		$temp=$sql->query_array("SELECT id_vyrobku, nazev_vyrobku, id_firmy, id_baleni, id_lakovani, barevnost, konstrukce_obalu, cislo_vykresu FROM vyrobky WHERE id_vyrobku='$_GET[id_vyrobku]'");
		$id_vyrobku = $temp['id_vyrobku'];
		$nazev_vyrobku = $temp['nazev_vyrobku'];
		$id_firmy = $temp['id_firmy'];
		$id_baleni = $temp['id_baleni'];
		$id_lakovani = $temp['id_lakovani'];
		$barevnost = $temp['barevnost'];
		$konstrukce_obalu = $temp['konstrukce_obalu'];
		$cislo_vykresu = $temp['cislo_vykresu'];
		
		$operace_vnitrni = $sql->query("SELECT vo.id_operace_vnitrni, o.nazev_operace_vnitrni, vo.poznamka
											FROM vyrobek_operace_vnitrni vo
										JOIN operace_vnitrni o ON vo.id_operace_vnitrni = o.id_operace_vnitrni
										WHERE o.smazano=0 and id_vyrobku=$id_vyrobku
										ORDER BY poradi");
		$i = 0;
		while ($operace=$sql->fetch_array($operace_vnitrni)){
			$oznacene_operace_vnitrni[$i] = array (
				'id_operace_vnitrni' => $operace['id_operace_vnitrni'],
				'nazev_operace_vnitrni' => $operace['nazev_operace_vnitrni'],
				'poznamka' => $operace['poznamka']
			);
			$i++;
		}
		
		$operace_vnejsi = $sql->query("SELECT vo.id_operace_vnejsi, o.nazev_operace_vnejsi, vo.poznamka
											FROM vyrobek_operace_vnejsi vo
										JOIN operace_vnejsi o ON vo.id_operace_vnejsi = o.id_operace_vnejsi
										WHERE o.smazano=0 and id_vyrobku=$id_vyrobku
										ORDER BY poradi");
		$i = 0;
		while ($operace=$sql->fetch_array($operace_vnejsi)){
			$oznacene_operace_vnejsi[$i] = array (
				'id_operace_vnejsi' => $operace['id_operace_vnejsi'],
				'nazev_operace_vnejsi' => $operace['nazev_operace_vnejsi'],
				'poznamka' => $operace['poznamka']
			);
			$i++;
		}
	}
	
	if ($_POST['save']=="Uložit"){
		$error="";
		$ulozeno_poprve=0;
		if (isset($_POST['id_vyrobku']))
			$id_vyrobku = $_POST['id_vyrobku'];
		$nazev_vyrobku = $_POST['nazev_vyrobku'];
		$id_firmy = $_POST['id_firmy'];
		$id_baleni = $_POST['id_baleni'];
		$id_lakovani = $_POST['id_lakovani'];
		$barevnost = $_POST['barevnost'];
		$cislo_vykresu = $_POST['cislo_vykresu'];
		$konstrukce_obalu = $_POST['konstrukce_obalu'];
		
		$operace_vnitrni = $sql->query("SELECT id_operace_vnitrni, nazev_operace_vnitrni
											FROM operace_vnitrni
										WHERE smazano=0
										ORDER BY poradi");
		unset($oznacene_operace_vnitrni);
		$i = 0;
		while ($operace=$sql->fetch_array($operace_vnitrni)){
			if (isset($_POST["o_c_operace_vnitrni_$operace[id_operace_vnitrni]"])){
				$oznacene_operace_vnitrni[$i] = array (
					'id_operace_vnitrni' => $operace['id_operace_vnitrni'],
					'nazev_operace_vnitrni' => $operace['nazev_operace_vnitrni'],
					'poznamka' => $_POST["o_t_operace_vnitrni_$operace[id_operace_vnitrni]"]
				);
				$i++;
			}
		}
		
		$operace_vnejsi = $sql->query("SELECT id_operace_vnejsi, nazev_operace_vnejsi
											FROM operace_vnejsi
										WHERE smazano=0
										ORDER BY poradi");
		unset($oznacene_operace_vnejsi);
		$i = 0;
		while ($operace=$sql->fetch_array($operace_vnejsi)){
			if (isset($_POST["o_c_operace_vnejsi_$operace[id_operace_vnejsi]"])){
				$oznacene_operace_vnejsi[$i] = array (
					'id_operace_vnejsi' => $operace['id_operace_vnejsi'],
					'nazev_operace_vnejsi' => $operace['nazev_operace_vnejsi'],
					'poznamka' => $_POST["o_t_operace_vnejsi_$operace[id_operace_vnejsi]"]
				);
				$i++;
			}
		}
		
		$error.=(empty($nazev_vyrobku)) ? "<p class=\"chyba\">Nebyl zadán název výrobku.</p>" : "";
		$error.=(empty($id_firmy)) ? "<p class=\"chyba\">Nebyla zadána firma.</p>" : "";
		$error.=(empty($id_baleni)) ? "<p class=\"chyba\">Nebylo zadáno balení.</p>" : "";
	}
	
	if ($error=="" && $_POST['save']=="Uložit"){
		$nazev_vyrobku=check_input($nazev_vyrobku);
		$datum_editace = Time();
		if (isset($id_vyrobku)){
			$sql->query("UPDATE vyrobky 
						SET nazev_vyrobku='$nazev_vyrobku', id_firmy='$id_firmy', id_baleni=$id_baleni, editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace',
							id_lakovani='$id_lakovani', barevnost='$barevnost', konstrukce_obalu='$konstrukce_obalu', cislo_vykresu='$cislo_vykresu'
						WHERE id_vyrobku=$id_vyrobku");
		} else {
			$sql->query("INSERT INTO vyrobky VALUES (NULL, '$nazev_vyrobku', '$id_firmy', '$_SESSION[ot_userId]', '$datum_editace', '0', '$id_baleni', '$id_lakovani', '$barevnost', '$konstrukce_obalu', '$cislo_vykresu')");
			$id_vyrobku=$sql->insert_id();
			$ulozeno_poprve=1;
		}
		
		$sql->query("DELETE FROM vyrobek_operace_vnitrni WHERE id_vyrobku=$id_vyrobku");
		if (isset($oznacene_operace_vnitrni)){
			foreach($oznacene_operace_vnitrni as $oz_pol){
				$sql->query("INSERT INTO vyrobek_operace_vnitrni VALUES ('$id_vyrobku', '$oz_pol[id_operace_vnitrni]', '$oz_pol[poznamka]')");
			}
		}
		
		$sql->query("DELETE FROM vyrobek_operace_vnejsi WHERE id_vyrobku=$id_vyrobku");
		if (isset($oznacene_operace_vnejsi)){
			foreach($oznacene_operace_vnejsi as $oz_pol){
				$sql->query("INSERT INTO vyrobek_operace_vnejsi VALUES ('$id_vyrobku', '$oz_pol[id_operace_vnejsi]', '$oz_pol[poznamka]')");
			}
		}
		
		$saved=1;
		echo "<p class=\"oznameni\">Výrobek v pořádku uložen.</p>";
		if ($ulozeno_poprve==1)
			$refresh_page=$page->_head_path . "?show=vyrobek_edit&id_vyrobku=$id_vyrobku";
		else
			$refresh_page=$page->_head_path . "?show=firmy&id_firmy=$id_firmy";
		echo "<meta http-equiv=\"refresh\" content=\"1; url=$refresh_page\">";
		message_auto_forward($refresh_page);
	} else if ($error!=""){
		echo "<hr /><b>" . $error . "</b><hr />";
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	if (isset($_POST['save_material'])){
		$error_under="";
		if (isset($_POST['id_vyrobku']))
			$id_vyrobku = $_POST['id_vyrobku'];
		$id_materialu = $_POST['id_materialu'];
		
		$hodnota = $_POST['hodnota'];
		if (!isset($hodnota)){
			$hodnota=0;
		}
		$hodnota = str_replace(",", ".", $hodnota);
		
		$atributy = $sql->query("SELECT a.id_atributu, a.nazev_atributu FROM atributy a
								WHERE a.id_materialu=$id_materialu and a.smazano=0");
		if ($sql->num_rows($atributy)){
			while ($atribut=$sql->fetch_array($atributy)){
				$hodnoty_atributu[$atribut['id_atributu']] = $_POST["atribut$atribut[id_atributu]"];
			}
		}
		
		$error_under.=($id_materialu==0) ? "<p class=\"chyba\">Vyberte materiál.</p>" : "";
	}
	
	if ($error_under=="" && isset($_POST['save_material'])){
		$datum_editace = Time();
		
		$temp = $sql->query_array("SELECT max(razeni) razeni FROM vyrobek_material WHERE id_vyrobku='$id_vyrobku'");
		$razeni = $temp['razeni'] + 100;
		
		$sql->query("UPDATE vyrobky SET editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace' WHERE id_vyrobku=$id_vyrobku");
		$sql->query("INSERT INTO vyrobek_material VALUES (NULL ,  '$id_vyrobku',  '$id_materialu',  $razeni, '$_SESSION[ot_userId]', $datum_editace, '$hodnota')");
		$id_vyrobek_material = $sql->insert_id();
		
		$atributy = $sql->query("SELECT a.id_atributu, a.nazev_atributu FROM atributy a
								WHERE a.id_materialu=$id_materialu and a.smazano=0");
		if ($sql->num_rows($atributy)){
			while ($atribut=$sql->fetch_array($atributy)){
				$hodnota_temp = $hodnoty_atributu[$atribut['id_atributu']];
				$sql->query("INSERT INTO `vyrobek_material_atribut` VALUES (NULL ,  '$atribut[id_atributu]',  '$id_vyrobek_material', '$hodnota_temp', '$_SESSION[ot_userId]', $datum_editace)");
			}
		}
		
		unset($atributy);
		unset($hodnoty_atributu);
		unset($id_materialu);
	} else if ($error_under!=""){
		echo "<hr /><b>" . $error_under . "</b><hr />";
	}
	
	if (isset($_GET['smaz_id'])){
		$datum_editace = Time();
		$sql->query("DELETE FROM vyrobek_material WHERE id_vyrobek_material=$_GET[smaz_id]");
	}
		
	if ($saved==0){
		?>
		<form action="" method="post" name="vyrobky">
			<div style="text-align: center; padding: 5px; border-bottom: #aaa 1px dashed;">
				<input type="submit" name="save" value="Uložit" id="ulozit" />
				<span style="padding-left: 100px">
					<a href="?show=firmy&id_firmy=<?echo $id_firmy;?>" class="zpet">Zpět na seznam firem a výrobků (bez uložení)</a>
				</span>
			</div>
			
			<?php
				if (isset($id_vyrobku)){
					?>
					<input type="hidden" name="id_vyrobku" value="<?echo $id_vyrobku;?>" />
					<?
				}
			?>
			<table cellspacing="0" cellpadding="5" border="0" width="95%" align="center">
				<tr>
					<td><b>Název výrobku</b> (*)</td>
					<td><input id="nazev_vyrobku" type="text" size="30" maxlength="100" name="nazev_vyrobku" value="<?php echo "$nazev_vyrobku";?>" /></td>
					
					<td><b>Pro odběratele</b> (*)</td>
					<td>
						<select id="id_firmy" name="id_firmy" onchange="ajax('script/vyrobky/aj_nacist_vys_formy.php?id_vyrobku=<?echo $id_vyrobku;?>&id_firmy='+document.getElementById('id_firmy').value,'vys_formy');">
							<OPTION value="0">Vyberte možnost...</OPTION>
							<?
							$result=$sql->query("SELECT f.id_firmy, f.nazev_firmy FROM firmy f
												WHERE smazano=0
												ORDER BY f.nazev_firmy");
							while ($row=$sql->fetch_array($result)){
								if ($row['id_firmy'] == $id_firmy){
									?>
									<OPTION value="<?echo $row['id_firmy'];?>" selected="selected"><?echo $row['nazev_firmy'];?></OPTION>
									<?
								} else {
									?>
									<OPTION value="<?echo $row['id_firmy'];?>"><?echo $row['nazev_firmy'];?></OPTION>
									<?
								}
							}
							?>
						</select>
					</td>
				</tr>
				<tr>
					<td><b>Balení</b> (*)</td>
					<td>
						<select name="id_baleni" >
							<OPTION value="0">Vyberte možnost...</OPTION>
							<?
							$result=$sql->query("SELECT id_baleni, nazev_baleni FROM baleni
												WHERE smazano=0
												ORDER BY nazev_baleni");
							while ($row=$sql->fetch_array($result)){
								if ($row['id_baleni'] == $id_baleni){
									?>
									<OPTION value="<?echo $row['id_baleni'];?>" selected="selected"><?echo $row['nazev_baleni'];?></OPTION>
									<?
								} else {
									?>
									<OPTION value="<?echo $row['id_baleni'];?>"><?echo $row['nazev_baleni'];?></OPTION>
									<?
								}
							}
							?>
						</select>
					</td>
					<td><b>Lakování</b></td>
					<td>
						<select name="id_lakovani" >
							<OPTION value="0">Vyberte možnost...</OPTION>
							<?
							$result=$sql->query("SELECT id_lakovani, nazev_lakovani FROM lakovani
												WHERE smazano=0
												ORDER BY nazev_lakovani");
							while ($row=$sql->fetch_array($result)){
								if ($row['id_lakovani'] == $id_lakovani){
									?>
									<OPTION value="<?echo $row['id_lakovani'];?>" selected="selected"><?echo $row['nazev_lakovani'];?></OPTION>
									<?
								} else {
									?>
									<OPTION value="<?echo $row['id_lakovani'];?>"><?echo $row['nazev_lakovani'];?></OPTION>
									<?
								}
							}
							?>
						</select>
					</td>
				</tr>
				<tr>
					<td><b>Konstrukce obalu</b></td>
					<td><input id="konstrukce_obalu" type="text" size="30" maxlength="50" name="konstrukce_obalu" value="<?php echo "$konstrukce_obalu";?>" /></td>

					<td><b>Barevnost</b></td>
					<td><input id="barevnost" type="text" size="30" maxlength="50" name="barevnost" value="<?php echo "$barevnost";?>" /></td>
				</tr>
				<tr>
					<td><b>Číslo výkresu</b></td>
					<td><input id="cislo_vykresu" type="text" size="30" maxlength="50" name="cislo_vykresu" value="<?php echo "$cislo_vykresu";?>" /></td>

					<td></td>
					<td></td>
				</tr>
				<tr id="vysekove_formy">
					<td style="vertical-align: top;"><b>Výsekové formy</b></td>
					<td colspan="3">
						<?
						if (isset($id_vyrobku)){
							?>
							<div id="prir_vf">
								<?
								$result=$sql->query("SELECT vf.id_vysekove_formy, cislo_vysekove_formy, nazev_vysekove_formy, cislo_vysekove_formy, nazev_vysekove_formy, 
															ks_na_arch, min_rozmer_sirka, min_rozmer_delka, rozmer_obalu_sirka, rozmer_obalu_delka, rozmer_obalu_vyska
													FROM vysekove_formy vf
													JOIN vyrobek_vysekove_formy vvf ON vvf.id_vysekove_formy = vf.id_vysekove_formy
													WHERE smazano=0 and id_vyrobku=$id_vyrobku
													ORDER BY nazev_vysekove_formy");
								while ($row=$sql->fetch_array($result)){
									echo $row['cislo_vysekove_formy'] . ' - ' . $row['nazev_vysekove_formy']  . ', ' . $row['ks_na_arch']  . ' ks/arch, min.roz.: ' . $row['min_rozmer_sirka'] 
										. 'x' . $row['min_rozmer_delka']  . ', roz.obalu: ' . $row['rozmer_obalu_sirka']  . 'x' . $row['rozmer_obalu_delka']  . 'x' . $row['rozmer_obalu_vyska'];
									?>
									<img src="files/smazat.png" onclick="ajax('script/vyrobky/aj_smazat_vys_formu.php?id_vyrobku=<?echo $id_vyrobku;?>&id_vysekove_formy='+document.getElementById('id_vysekove_formy').value,'prir_vf');" height="13px" />
									<br />
									<?
								}
								?>
							</div>
							<div id="vys_formy">
								<select name="id_vysekove_formy" id="id_vysekove_formy" onchange="ajax('script/vyrobky/aj_nacist_prir_vys_formy.php?id_vyrobku=<?echo $id_vyrobku;?>&id_vysekove_formy='+document.getElementById('id_vysekove_formy').value,'prir_vf');">
									<OPTION value="0">Vyberte možnost...</OPTION>
									<?
									$result=$sql->query("SELECT id_vysekove_formy, cislo_vysekove_formy, nazev_vysekove_formy, cislo_vysekove_formy, nazev_vysekove_formy, 
															ks_na_arch, min_rozmer_sirka, min_rozmer_delka, rozmer_obalu_sirka, rozmer_obalu_delka, rozmer_obalu_vyska
														FROM vysekove_formy vf
														WHERE smazano=0 and id_firmy=$id_firmy AND id_vysekove_formy NOT IN (SELECT id_vysekove_formy FROM vyrobek_vysekove_formy WHERE id_vyrobku=$id_vyrobku)
														ORDER BY nazev_vysekove_formy");
									while ($row=$sql->fetch_array($result)){
										if ($row['id_vysekove_formy'] == $id_vysekove_formy){
											?>
											<OPTION value="<?echo $row['id_vysekove_formy'];?>" selected="selected">
												<?
												echo $row['cislo_vysekove_formy'] . ' - ' . $row['nazev_vysekove_formy']  . ', ' . $row['ks_na_arch']  . ' ks/arch, min.roz.: ' . $row['min_rozmer_sirka'] 
													 . 'x' . $row['min_rozmer_delka']  . ', roz.obalu: ' . $row['rozmer_obalu_sirka']  . 'x' . $row['rozmer_obalu_delka']  . 'x' . $row['rozmer_obalu_vyska'] ;
												?>
											</OPTION>
											<?
										} else {
											?>
											<OPTION value="<?echo $row['id_vysekove_formy'];?>">
												<?
												echo $row['cislo_vysekove_formy'] . ' - ' . $row['nazev_vysekove_formy']  . ', ' . $row['ks_na_arch']  . ' ks/arch, min.roz.: ' . $row['min_rozmer_sirka'] 
													 . 'x' . $row['min_rozmer_delka']  . ', roz.obalu: ' . $row['rozmer_obalu_sirka']  . 'x' . $row['rozmer_obalu_delka']  . 'x' . $row['rozmer_obalu_vyska'] ;
												?>
											</OPTION>
											<?
										}
									}
									?>
								</select>
							</div>
							<?
						}
						?>
					</td>
				</tr>
				<tr>
					<td colspan=4>
						<b>Operace vnitřní</b><br />
						<?
						$i=0;
						$operace_vnitrni = $sql->query("SELECT id_operace_vnitrni, nazev_operace_vnitrni
															FROM operace_vnitrni
														WHERE smazano=0
														ORDER BY poradi");
						while ($operace=$sql->fetch_array($operace_vnitrni)){
							$checked=0;
							if (isset($oznacene_operace_vnitrni)){
								foreach($oznacene_operace_vnitrni as $oz_pol){
									if ($oz_pol['id_operace_vnitrni']==$operace['id_operace_vnitrni']){
										$checked=1;
										$poznamka=$oz_pol['poznamka'];
									}
								}
							}
							zaskrtavaci_policko_o($operace['nazev_operace_vnitrni'], "operace_vnitrni_$operace[id_operace_vnitrni]", $checked, barva($i), $poznamka);
							$poznamka="";
							$i++;
						}
						?>
					</td>
				</tr>
				<tr>
					<td colspan=4>
						<b>Operace vnější</b><br />
						<?
						$i=0;
						$operace_vnejsi = $sql->query("SELECT id_operace_vnejsi, nazev_operace_vnejsi
															FROM operace_vnejsi
														WHERE smazano=0
														ORDER BY poradi");
						while ($operace=$sql->fetch_array($operace_vnejsi)){
							$checked=0;
							if (isset($oznacene_operace_vnejsi)){
								foreach($oznacene_operace_vnejsi as $oz_pol){
									if ($oz_pol['id_operace_vnejsi']==$operace['id_operace_vnejsi']){
										$checked=1;
										$poznamka=$oz_pol['poznamka'];
									}
								}
							}
							zaskrtavaci_policko_o_v($operace['nazev_operace_vnejsi'], "operace_vnejsi_$operace[id_operace_vnejsi]", $checked, barva($i), $poznamka);
							$poznamka="";
							$i++;
						}
						?>
					</td>
				</tr>
			</table>
		</form>
		
		<?
		if (isset($id_vyrobku)){
			$rows = $sql->query("SELECT vm.id_vyrobek_material, m.nazev_materialu, vm.hodnota, mj.zkratka_jednotky, u.name editoval, vm.datum_editace 
								FROM vyrobek_material vm
								JOIN materialy m ON m.id_materialu = vm.id_materialu
								JOIN user u ON u.id_uzivatel = vm.editoval
								LEFT JOIN merna_jednotka mj ON mj.id_merna_jednotka = m.id_merna_jednotka
								WHERE vm.id_vyrobku=$id_vyrobku
								ORDER BY vm.razeni");
			?>
			<table cellspacing="0" cellpadding="5" border="0" width="90%" align="center">
				<tr style="text-align:center; background-color: <?echo $color;?>;">
						<td style="font-weight: bold;">
							Název materiálu
						</td>
						<td style="font-weight: bold;">
							Jednotka
						</td>
						<td style="font-weight: bold; width: 400px;">
							Atributy materiálu
						</td>
						<td style="width: 100px;">
							
						</td>
					</tr>
				<?
				$i=0;
				while ($row=$sql->fetch_array($rows)){
					(($i % 2)==0) ? $color="#DDD" : $color="#FFF";
					$i++;
					$datum_editace = StrFTime("%d.%m.%Y %H:%M", $row['datum_editace']);
					?>
					<tr style="text-align:center; background-color: <?echo $color;?>;">
						<td>
							<?echo $row['nazev_materialu'];?>
						</td>
						<td>
							<?echo $row['zkratka_jednotky'];?>
						</td>
						<td>
							<?
							$atributy_temp = $sql->query("SELECT a.nazev_atributu, vma.hodnota, mj.zkratka_jednotky, vma.datum_editace, u.name editoval
															FROM vyrobek_material_atribut vma
															JOIN atributy a ON a.id_atributu = vma.id_atributu
															LEFT JOIN merna_jednotka mj ON mj.id_merna_jednotka = a.id_merna_jednotka
															JOIN user u ON vma.editoval = u.id_uzivatel
															WHERE vma.id_vyrobek_material=$row[id_vyrobek_material]");
							while ($atribut_temp=$sql->fetch_array($atributy_temp)){
								$datum_editace_temp = StrFTime("%d.%m.%Y %H:%M", $atribut_temp['datum_editace']);
								?>
								<span style="border: 1px dotted #888; padding: 0px 10px;" title="Vytvořil(a) <?echo $atribut_temp['editoval'] . ' ' . $datum_editace_temp;?>">
									<?echo $atribut_temp['nazev_atributu'] . " " . $atribut_temp['hodnota'] . " " . $atribut_temp['zkratka_jednotky'];?>
								</span>
								<?
							}
							?>
						</td>
						<td style="width: 100px;">
							<span style="cursor: pointer;" id="odkaz_smazat_<?echo $row['id_vyrobek_material'];?>"	onClick="ukaz_form_smazat(<?echo $row['id_vyrobek_material'];?>)"
							title="Vytvořil(a) <?echo $row['editoval'] . ' ' . $datum_editace;?>">
								<img src="files/smazat.png" height="16px">
							</span>
							<br />
							<span id="smazat_<?echo $row['id_vyrobek_material'];?>" style="display: none;">
								<a href="?show=vyrobek_edit&id_vyrobku=<?echo $id_vyrobku;?>&smaz_id=<?echo $row['id_vyrobek_material'];?>">Ano</a>
								<a style="margin-left: 20px;" href="javascript:void(0)" onclick="skryj_form_smazat(<?echo $row['id_vyrobek_material'];?>)">Ne</a>
							</span>
						</td>
					</tr>
					<?
				}
				?>
			</table>
		
			<form action="" method="post" name="vyrobek_material">
				<?
				if (isset($id_vyrobku)){
					?>
					<input type="hidden" name="id_vyrobku" value="<?echo $id_vyrobku;?>" />
					<?
				}
				?>
				<div style="text-align: left; margin-top: 20px; padding: 5px; border-bottom: #aaa 1px dashed;border-top: #aaa 1px dashed;">
					<table cellspacing="0" cellpadding="5" border="0" width="50%">
						<tr>
							<td><b>Materiál</b> (*)</td>
							<td>
								<select id="id_materialu" name="id_materialu" onchange="ajax('script/vyrobky/aj_nacist_atributy.php?id_materialu='+document.getElementById('id_materialu').value,'formular');">
									<OPTION value="0">Vyberte možnost...</OPTION>
									<?
									$result=$sql->query("SELECT m.id_materialu, m.nazev_materialu, mj.zkratka_jednotky FROM materialy m
														JOIN merna_jednotka mj ON m.id_merna_jednotka = mj.id_merna_jednotka
														WHERE m.smazano=0
														ORDER BY m.nazev_materialu");
									while ($row=$sql->fetch_array($result)){
										if ($row['id_materialu'] == $id_materialu){
											?>
											<OPTION value="<?echo $row['id_materialu'];?>" selected="selected"><?echo $row['nazev_materialu'] . ' (' . $row['zkratka_jednotky'] . ')';?></OPTION>
											<?
										} else {
											?>
											<OPTION value="<?echo $row['id_materialu'];?>"><?echo $row['nazev_materialu'] . ' (' . $row['zkratka_jednotky'] . ')';?></OPTION>
											<?
										}
									}
									?>
								</select>
							</td>
						</tr>
						
					</table>
					<div id="formular">
						<?
						if (isset($id_materialu)){
							$atributy = $sql->query("SELECT a.id_atributu, a.nazev_atributu, mj.zkratka_jednotky FROM atributy a
													LEFT JOIN merna_jednotka mj ON mj.id_merna_jednotka=a.id_merna_jednotka
													WHERE a.id_materialu=$id_materialu AND a.smazano=0");
							if ($sql->num_rows($atributy)){
								while ($atribut=$sql->fetch_array($atributy)){
									?>
									<table cellspacing="0" cellpadding="5" border="0" width="70%">
										<tr>
											<td style="font-weight: bold; width: 200px;">
												<?
												echo $atribut['nazev_atributu'];
												if (!empty($atribut['zkratka_jednotky'])) echo " (" . $atribut['zkratka_jednotky'] . ")";
												?>
												
											</td>
											<td style="text-align: left;">
												<?
												$hodnoty = $sql->query("SELECT id_hodnoty_atributu, hodnota_atributu FROM hodnoty_atributu
																		WHERE id_atributu=$atribut[id_atributu]");
												if ($sql->num_rows($hodnoty)>0){
													?>
													<select name="atribut<?echo $atribut['id_atributu'];?>">
														<OPTION value="0">Vyberte možnost...</OPTION>
														<?
														while ($hodnota=$sql->fetch_array($hodnoty)){
															if ($hodnota['hodnota_atributu'] == $hodnoty_atributu[$atribut['id_atributu']]){
																?>
																<OPTION value="<?echo $hodnota['hodnota_atributu'];?>" selected="selected"><?echo $hodnota['hodnota_atributu'];?></OPTION>
																<?
															} else {
																?>
																<OPTION value="<?echo $hodnota['hodnota_atributu'];?>"><?echo $hodnota['hodnota_atributu'];?></OPTION>
																<?

															}
														}
														?>
													</select>
													<?
												} else {
													?>
													<input type="text" size="20" maxlength="100" name="atribut<?echo $atribut['id_atributu'];?>" value="<?echo $hodnoty_atributu[$atribut['id_atributu']];?>" />
													<?
												}
												?>
											</td>
										</tr>
									</table>
									<?
								}
							}
						}
						?>
					</div>
					<div>
						<input type="submit" name="save_material" value="Vložit materiál" id="ulozit" />
					</div>
				</div>
			</form>
			<?
		}
		?>
		(*) - povinné položky
		<script type="text/javascript"> document.getElementById("nazev_vyrobku").focus(); </script>
		<?php
	}
} else echo "<p class=\"chyba\">Na toto nemáte přiřazená práva.</p>";
?>
</div>