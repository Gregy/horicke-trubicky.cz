<?
	require_once '../../classes/class_mysql.php';
	$sql=new mysql;
		
?>
	<select name="id_vysekove_formy" id="id_vysekove_formy" onchange="ajax('script/vyrobky/aj_nacist_prir_vys_formy.php?id_vyrobku=<?echo $_GET['id_vyrobku'];?>&id_vysekove_formy='+document.getElementById('id_vysekove_formy').value,'prir_vf');">
		<OPTION value="0">Vyberte možnost...</OPTION>
		<?
		$result=$sql->query("SELECT id_vysekove_formy, cislo_vysekove_formy, nazev_vysekove_formy, cislo_vysekove_formy, nazev_vysekove_formy, 
									ks_na_arch, min_rozmer_sirka, min_rozmer_delka, rozmer_obalu_sirka, rozmer_obalu_delka, rozmer_obalu_vyska
							FROM vysekove_formy
							WHERE smazano=0 and id_firmy=$_GET[id_firmy] AND id_vysekove_formy NOT IN (SELECT id_vysekove_formy FROM vyrobek_vysekove_formy WHERE id_vyrobku=$_GET[id_vyrobku])
							ORDER BY nazev_vysekove_formy");
		while ($row=$sql->fetch_array($result)){
				?>
				<OPTION value="<?echo $row['id_vysekove_formy'];?>">
				<?
					echo $row['cislo_vysekove_formy'] . ' - ' . $row['nazev_vysekove_formy']  . ', ' . $row['ks_na_arch']  . ' ks/arch, min.roz.: ' . $row['min_rozmer_sirka'] 
						. 'x' . $row['min_rozmer_delka']  . ', roz.obalu: ' . $row['rozmer_obalu_sirka']  . 'x' . $row['rozmer_obalu_delka']  . 'x' . $row['rozmer_obalu_vyska'] ;
											?>
				</OPTION>
				<?
		}
		?>
	</select>
	