<?
	require_once '../../classes/class_mysql.php';
		$sql=new mysql;
		
	//echo $_GET['id_materialu'];
	$atributy = $sql->query("SELECT a.id_atributu, a.nazev_atributu, mj.zkratka_jednotky FROM atributy a
							LEFT JOIN merna_jednotka mj ON mj.id_merna_jednotka=a.id_merna_jednotka
							WHERE a.id_materialu=$_GET[id_materialu] AND a.smazano=0");
	if ($sql->num_rows($atributy)){
		while ($atribut=$sql->fetch_array($atributy)){
			?>
			<table cellspacing="0" cellpadding="5" border="0" width="70%">
				<tr>
					<td style="font-weight: bold; width: 200px;">
						<?
						echo $atribut['nazev_atributu'];
						if (!empty($atribut['zkratka_jednotky'])) echo " (" . $atribut['zkratka_jednotky'] . ")";
						?>
						
					</td>
					<td style="text-align: left;">
						<?
						$hodnoty = $sql->query("SELECT id_hodnoty_atributu, hodnota_atributu FROM hodnoty_atributu
												WHERE id_atributu=$atribut[id_atributu]
												ORDER BY hodnota_atributu");
						if ($sql->num_rows($hodnoty)>0){
							?>
							<select name="atribut<?echo $atribut['id_atributu'];?>">
								<OPTION value="0">Vyberte možnost...</OPTION>
								<?
								while ($hodnota=$sql->fetch_array($hodnoty)){
									?>
									<OPTION value="<?echo $hodnota['hodnota_atributu'];?>"><?echo $hodnota['hodnota_atributu'];?></OPTION>
									<?
								}
								?>
							</select>
							<?
						} else {
							?>
							<input type="text" size="15" maxlength="100" name="atribut<?echo $atribut['id_atributu'];?>" value="" />
							<?
						}
						?>
					</td>
				</tr>
			</table>
			<?
		}
	}
?>