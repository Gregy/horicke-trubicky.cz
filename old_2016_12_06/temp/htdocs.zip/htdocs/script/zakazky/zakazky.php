﻿<script src="js/tooltip_wz/wz_tooltip.js" type="text/javascript"></script>
<?
if (haveRight("ZAKAZKY")){
	if (isset($_GET['cislo_zakazky'])){
		$_SESSION['filtr_zakazek']['cislo_zakazky'] = $_GET['cislo_zakazky'];
	}
	if (isset($_GET['rok'])){
		$_SESSION['filtr_zakazek']['rok'] = $_GET['rok'];
	}
	if (isset($_GET['id_firmy'])){
		$_SESSION['filtr_zakazek']['id_firmy'] = $_GET['id_firmy'];
	}
	if (isset($_GET['id_stavu'])){
		$_SESSION['filtr_zakazek']['id_stavu'] = $_GET['id_stavu'];
	}
	if (isset($_GET['termin_dokonceni'])){
		$_SESSION['filtr_zakazek']['termin_dokonceni'] = $_GET['termin_dokonceni'];
	}
	
	if (isset($_GET['zrus_filtr'])){
		unset($_SESSION['filtr_zakazek']);
	}
	
	
	if (haveRight("ZAKAZKY_SMAZAT")){
		if (isset($_GET['smaz_id'])){
			$sql->query("DELETE FROM zak_vyr_mat_atributy 
						WHERE id_zak_vyr_material IN 
							(SELECT id_zak_vyr_material FROM zak_vyr_material 
							WHERE id_zak_vyrobku IN 
								(SELECT id_zak_vyrobku FROM zak_vyrobky 
								WHERE id_zakazky=$_GET[smaz_id]))");
			
			$sql->query("DELETE FROM zak_vyr_material 
							WHERE id_zak_vyrobku IN 
								(SELECT id_zak_vyrobku FROM zak_vyrobky 
								WHERE id_zakazky=$_GET[smaz_id])");
			
			$sql->query("DELETE FROM zak_vyr_operace_vnejsi 
							WHERE id_zak_vyrobku IN 
								(SELECT id_zak_vyrobku FROM zak_vyrobky 
								WHERE id_zakazky=$_GET[smaz_id])");
			
			$sql->query("DELETE FROM zak_vyr_operace_vnitrni 
							WHERE id_zak_vyrobku IN 
								(SELECT id_zak_vyrobku FROM zak_vyrobky 
								WHERE id_zakazky=$_GET[smaz_id])");
			
			$sql->query("DELETE FROM zak_vyrobky 
							WHERE id_zakazky=$_GET[smaz_id]");
							
			$sql->query("DELETE FROM zakazky
							WHERE id_zakazky=$_GET[smaz_id]");
		}
	}

	if (haveRight("ZAKAZKY_EDITACE")){
		?>
		<div style="width: 100%; text-align:center; padding-bottom: 5px; margin-bottom: 5px; font-size: 15px; border-bottom: 1px dashed;">
			<a href="?show=zakazka_new">Nová zakázka</a>
		</div>
		<?
	}
	?>
	<div onclick="ukaz_skryj('filtr_zakazek');" style="cursor: pointer;">
		Zobraz / skryj filtr
		<?
		if (!empty($_SESSION['filtr_zakazek']['cislo_zakazky']) || !empty($_SESSION['filtr_zakazek']['rok']) || !empty($_SESSION['filtr_zakazek']['id_firmy'])
			|| !empty($_SESSION['filtr_zakazek']['id_stavu']) || !empty($_SESSION['filtr_zakazek']['termin_dokonceni'])){
				?> 
				<span style="padding-left: 200px; color: #D55; font-weight: bold;">Filtr je AKTIVNÍ</span>
				<a href="?show=zakazky&zrus_filtr=1" style="margin-left: 200px; color: #555; font-weight: bold;">Zrušit filtr</a>
				<?
		}
		?>
	</div>
	<div id="filtr_zakazek" style="display: none;">
		<form action="" method="GET">
			<table cellspacing="0" cellpadding="5" border="0" width="60%">
				<tr>
					<td>
						<b>Číslo zakázky / rok</b>
					</td>
					<td>
						<input id="cislo_zakazky" name="cislo_zakazky" type="text" value="<?echo $_SESSION['filtr_zakazek']['cislo_zakazky'];?>" size="5" maxlength="5" />
						/
						<input id="rok" name="rok" type="text" value="<?echo $_SESSION['filtr_zakazek']['rok'];?>" size="5" maxlength="5" />
					</td>
				</tr>
				<tr>
					<td>
						<b>Pro firmu</b>
					</td>
					<td>
						<select id="id_firmy" name="id_firmy">
							<OPTION value="0">Vyberte možnost...</OPTION>
							<?
							$result=$sql->query("SELECT id_firmy, nazev_firmy FROM firmy
												ORDER BY nazev_firmy");
							while ($row=$sql->fetch_array($result)){
								if ($row['id_firmy'] == $_SESSION['filtr_zakazek']['id_firmy']){
									?>
									<OPTION value="<?echo $row['id_firmy'];?>" selected="selected"><?echo $row['nazev_firmy'];?></OPTION>
									<?
								} else {
									?>
									<OPTION value="<?echo $row['id_firmy'];?>"><?echo $row['nazev_firmy'];?></OPTION>
									<?
								}
							}
							?>
						</select>
					</td>
				</tr>
				<tr>
					<td>
						<b>Stav zakázky</b>
					</td>
					<td>
						<select id="id_stavu" name="id_stavu">
							<OPTION value="0">Vyberte možnost...</OPTION>
							<?
							$result=$sql->query("SELECT id_stavu, nazev_stavu FROM stavy
												ORDER BY id_stavu");
							while ($row=$sql->fetch_array($result)){
								if ($row['id_stavu'] == $_SESSION['filtr_zakazek']['id_stavu']){
									?>
									<OPTION value="<?echo $row['id_stavu'];?>" selected="selected"><?echo $row['nazev_stavu'];?></OPTION>
									<?
								} else {
									?>
									<OPTION value="<?echo $row['id_stavu'];?>"><?echo $row['nazev_stavu'];?></OPTION>
									<?
								}
							}
							?>
						</select>
					</td>
				</tr>
				<tr>
					<td>
						<b>Termín dokončení</b>
					</td>
					<td>
						<select name="termin_dokonceni">
							<OPTION value="0">Vyberte možnost...</OPTION>
							<OPTION value="1" <?if ($_SESSION['filtr_zakazek']['termin_dokonceni']==1) echo "selected=\"selected\"";?>>Po termínu !!!</OPTION>
							<OPTION value="2" <?if ($_SESSION['filtr_zakazek']['termin_dokonceni']==2) echo "selected=\"selected\"";?>>Do 7 dnů</OPTION>
						</select>
					</td>
				</tr>
			</table>
			<div style="padding: 5px;">
				<input type="submit" name="save" value="Použít filtr" id="inform" />
			</div>
		</form>
	</div>
	<?
	$prvni=true;
	if (isset($_SESSION['filtr_zakazek'])){
		if (!empty($_SESSION['filtr_zakazek']['cislo_zakazky'])){
			$where .= "cislo_zakazky=" . $_SESSION['filtr_zakazek']['cislo_zakazky'];
			$prvni=false;
		}
		if (!empty($_SESSION['filtr_zakazek']['rok'])){
			($prvni==false) ? $where .= " AND " : $where .= "";
			$where .= "rok=" . $_SESSION['filtr_zakazek']['rok'];
			$prvni=false;
		}
		
		if (!empty($_SESSION['filtr_zakazek']['cislo_zakazky']) && !empty($_SESSION['filtr_zakazek']['rok'])){
			$temp = $sql->query("SELECT id_zakazky FROM zakazky WHERE cislo_zakazky=" . $_SESSION['filtr_zakazek']['cislo_zakazky'] . " AND rok=" . $_SESSION['filtr_zakazek']['rok']);
			if ($sql->num_rows($temp)>0){
				$temp = $sql->fetch_array($temp);
				
				$union = "UNION
						SELECT z.id_zakazky, z.id_firmy, z.cislo_zakazky cislo_zakazky, z.rok rok, z.termin_dokonceni, z.datum_editace, u.name editoval , z.id_stavu, 
							s.nazev_stavu, nazev_firmy, z.rodic_zakazka, z.poznamka, z.email, z.cislo_objednavky
						FROM zakazky z
						JOIN stavy s ON z.id_stavu = s.id_stavu
						JOIN user u ON u.id_uzivatel = z.editoval
						WHERE z.rodic_zakazka=$temp[id_zakazky]";
			}
		}
		
		if (!empty($_SESSION['filtr_zakazek']['id_firmy'])){
			($prvni==false) ? $where .= " AND " : $where .= "";
			$where .= "id_firmy=" . $_SESSION['filtr_zakazek']['id_firmy'];
			$prvni=false;
		}
		if (!empty($_SESSION['filtr_zakazek']['id_stavu'])){
			($prvni==false) ? $where .= " AND " : $where .= "";
			$where .= "z.id_stavu=" . $_SESSION['filtr_zakazek']['id_stavu'];
			$prvni=false;
		}
		if ($_SESSION['filtr_zakazek']['termin_dokonceni'] == 1){
			($prvni==false) ? $where .= " AND " : $where .= "";
			$aktualni_cas=Time();
			$where .= "termin_dokonceni<$aktualni_cas AND z.id_stavu<550";
			$prvni=false;
		}
		if ($_SESSION['filtr_zakazek']['termin_dokonceni'] == 2){
			($prvni==false) ? $where .= " AND " : $where .= "";
			$aktualni_cas=Time();
			$where .= "termin_dokonceni>$aktualni_cas AND termin_dokonceni<$aktualni_cas+604800 AND z.id_stavu<550";
			$prvni=false;
		}
	} else {
		$where = "s.id_stavu<550";
	}
	
	$where = " WHERE " . $where;
	//echo $where . "<br />";
	
	
	$rows = $sql->query("SELECT z.id_zakazky, z.id_firmy, z.cislo_zakazky cislo_zakazky, z.rok rok, z.termin_dokonceni, z.datum_editace, u.name editoval , z.id_stavu, 
							s.nazev_stavu, nazev_firmy, z.rodic_zakazka, z.poznamka, z.email, z.cislo_objednavky
						FROM zakazky z
						JOIN stavy s ON z.id_stavu = s.id_stavu
						JOIN user u ON u.id_uzivatel = z.editoval
						$where
						$union
						ORDER BY rok DESC, cislo_zakazky DESC
						
						");
	?>
	<table cellspacing="0" cellpadding="5" border="0" width="70%" align="center">
		<tr style="text-align:center; font-weight:bold; border-bottom: 1px solid #555;">
			<td style="width: 90px;">Číslo zakázky</td>
			<td>Zákazník</td>
			<td style="width: 100px;">Termín dokončení</td>
			<td style="width: 100px;">Stav</td>
			<td style="width: 30px;"></td>
			<td style="width: 30px;"></td>
			<td style="width: 30px;"></td>
			<td style="width: 30px;"></td>
			<td style="width: 30px;"></td>
			<td style="width: 30px;"></td>
			<td style="width: 30px;"></td>
			<td style="width: 30px;"></td>
			<td style="width: 100px;"></td>
		</tr>
		<?
		$i=0;
		while ($row=$sql->fetch_array($rows)){
			(($i % 2)==0) ? $color="#b0ffb0" : $color="#FFF";
			$termin_dokonceni = StrFTime("%d.%m.%Y", $row['termin_dokonceni']);
			$datum_editace = StrFTime("%d.%m.%Y %H:%M", $row['datum_editace']);
			$i++;
			$potvrzeni_objednavky = "Číslo objednávky " . $row['cislo_objednavky'] . "%0D%0A";
			$potvrzeni_objednavky .= "Odběratel: " . $row['nazev_firmy'] . "%0D%0A";
			$vyrobky = $sql->query("SELECT id_zak_vyrobku, nazev_vyrobku, nazev_baleni, pocet, jedn_cena, vedlejsi_naklady, fakturace, nazev_lakovani, barevnost, konstrukce_obalu 
									FROM zak_vyrobky 
									WHERE id_zakazky=$row[id_zakazky] AND smazano=0");
			$seznam_vyrobku = "<b>Výrobky zadané do zákázky " . cislo_rok($row['cislo_zakazky'], $row['rok']) . "</b>";
			while ($vyrobek=$sql->fetch_array($vyrobky)){
				$seznam_vyrobku .= "<br />" . $vyrobek['nazev_vyrobku'] . " - " . number_format($vyrobek['pocet'], 0, '.', ' ') . " ks";
				
				$potvrzeni_objednavky .= "%0D%0A" . "Výrobek: " . $vyrobek['nazev_vyrobku'] . "%0D%0A";
				if (!empty($vyrobek['pocet']))
					$potvrzeni_objednavky .= "Množství: " . number_format($vyrobek['pocet'], 0, '.', ' ') . " ks%0D%0A";
				if (!empty($vyrobek['jedn_cena']))
					$potvrzeni_objednavky .= "Cena: " . number_format($vyrobek['jedn_cena'], 2, '.', ' ') . " Kč/ks (bez DPH)%0D%0A";
				if (!empty($vyrobek['vedlejsi_naklady']))
					$potvrzeni_objednavky .= "Vedlejší náklady: " . number_format($vyrobek['vedlejsi_naklady'], 0, '.', ' ') . ",- Kč (bez DPH)%0D%0A";
				$potvrzeni_objednavky .= "Fakturace celkem: " . number_format($vyrobek['pocet']*$vyrobek['jedn_cena'], 0, '.', ' ') . ",- Kč (bez DPH)%0D%0A";
				$potvrzeni_objednavky .= "Termín dodání: " . $termin_dokonceni . "%0D%0A";
				$potvrzeni_objednavky .= "Způsob dopravy: " . "%0D%0A";
				if (!empty($vyrobek['konstrukce_obalu']))
					$potvrzeni_objednavky .= "Konstrukce: " . $vyrobek['konstrukce_obalu'] . "%0D%0A";
				if (!empty($vyrobek['barevnost']))
					$potvrzeni_objednavky .= "Barevnost: " . $vyrobek['barevnost'] . "%0D%0A";
				if (!empty($vyrobek['nazev_lakovani']))
					$potvrzeni_objednavky .= "Lakování: " . $vyrobek['nazev_lakovani'] . "%0D%0A";
				if (!empty($vyrobek['nazev_baleni']))
					$potvrzeni_objednavky .= "Balení: " . $vyrobek['nazev_baleni'] . "%0D%0A";
				
				$materialy = $sql->query("SELECT id_zak_vyr_material, nazev_materialu FROM zak_vyr_material WHERE id_zak_vyrobku=$vyrobek[id_zak_vyrobku]");
				if ($sql->num_rows($materialy)>0){
					$potvrzeni_objednavky .= "Materiál: ";
					$prvni=1;
					while ($material=$sql->fetch_array($materialy)){
						if ($prvni==0){
							$potvrzeni_objednavky .= "; ";
						} else {
							$prvni=0;
						}
						$potvrzeni_objednavky .= $material['nazev_materialu'] . " - ";
						$atributy = $sql->query("SELECT hodnota, zkratka_jednotky 
												FROM zak_vyr_mat_atributy zvma 
												JOIN merna_jednotka mj ON zvma.id_merna_jednotka = mj.id_merna_jednotka
												WHERE id_zak_vyr_material=$material[id_zak_vyr_material]");
						$prvni_under=1;
						while ($atribut=$sql->fetch_array($atributy)){
							if ($prvni_under==0){
								$potvrzeni_objednavky .= ", ";
							} else {
								$prvni_under=0;
							}
							$potvrzeni_objednavky .= $atribut['hodnota'] . " " . $atribut['zkratka_jednotky'];
						}
					}
					$potvrzeni_objednavky .= "%0D%0A";
				}
			}
			if (!empty($row['poznamka']))
				$potvrzeni_objednavky .= "%0D%0APoznámka: %0D%0A" . $row['poznamka'];
			?>
			<tr style="text-align:center; background-color: <?echo $color;?>;">
				<td><?echo cislo_rok($row['cislo_zakazky'], $row['rok']);?></td>
				<td><?echo $row['nazev_firmy'];?></td>
				<td><?echo $termin_dokonceni;?></td>
				<td><?echo $row['nazev_stavu'];?></td>
				<td>
					<a style="text-decoration: none;" href="?show=zakazka_show&id_zakazky=<?echo $row['id_zakazky'];?>">
						<span onmouseover="Tip('<?echo $seznam_vyrobku;?>')" onmouseout="UnTip()">
							<img src="files/lupa.gif" height="15px" />
						</span>
					</a>
				</td>
				<td>
					<?
					if (haveRight("ZAKAZKY")){
						?>
						<a style="text-decoration: none;" href="?show=zakazka_vykony&id_zakazky=<?echo $row['id_zakazky'];?>"><img src="files/vykony.png" title="Výkony zaměstnanců" height="18px" /></a>
						<?
					}
					?>
				</td>
				<td>
					<?
					if (haveRight("ZAKAZKY_EDITACE")){
						?>
						<a style="text-decoration: none;" href="?show=zakazka_edit&id_zakazky=<?echo $row['id_zakazky'];?>"><img src="files/edit.png" title="Editace zakázky" height="18px" /></a>
						<?
					}
					?>
				</td>
				<td>
					<?
					if (haveRight("DODACI_LISTY_EDITACE")){
						?>
						<a style="text-decoration: none;" href="?show=expedice&id_firmy=<?echo $row['id_firmy'];?>"><img src="files/expedice.png" title="Expedice zakázky" height="18px" /></a>
						<?
					}
					?>
				</td>
				<td>
					<?
					$reklamace = $sql->query("SELECT r.cislo_reklamace, r.rok_reklamace, r.pocet, s.nazev_stavu, zv.nazev_vyrobku
											FROM reklamace r
											JOIN stavy_rek s ON s.id_stavu = r.id_stavu
											JOIN zak_vyrobky zv ON zv.id_zak_vyrobku = r.id_zak_vyrobku
											WHERE r.smazano=0 AND zv.id_zakazky=$row[id_zakazky]
											");
					if ($sql->num_rows($reklamace)>0){
						$text = "Reklamace k této zakázce:<br />";
						while ($rek=$sql->fetch_array($reklamace)){
							$text.=cislo_rok($rek['cislo_reklamace'],$rek['rok_reklamace']) . " - " . $rek['nazev_vyrobku'] . " " . $rek['pocet'] . " ks - " . $rek['nazev_stavu'];
						}
						?>
						<span onmouseover="Tip('<?echo $text;?>')" onmouseout="UnTip()" style>
							<img src="files/reklamace.png" height="15px" />
						</span>
						<?
					}
					?>
				</td>
				<td>
					<?
					if (haveRight("ZAKAZKY_EDITACE") && $row['id_stavu']==550){
						?>
						<a style="text-decoration: none;" href="?show=zakazka_new&id_zakazky=<?echo $row['id_zakazky'];?>"><img src="files/subzakazka.png" title="Vytvořit subzakázku" height="18px" /></a>
						<?
					}
					?>
				</td>
				<td>
					<?
					if (haveRight("ZAKAZKY")){
						?>
						<a style="text-decoration: none;" href="?show=zakazka_soubory&id_zakazky=<?echo $row['id_zakazky'];?>"><img src="files/files.png" title="Soubory k zakázce" height="18px" /></a>
						<?
					}
					?>
				</td>
				<td>
					<?
					if (haveRight("ZAKAZKY_EDITACE")){
						?>
						<a style="text-decoration: none;" href="mailto:<?echo $row['email'];?>?subject=Potvrzení objednávky odběratele&body=<?echo $potvrzeni_objednavky;?>"><img src="files/submit.png" title="Potvrzení zakázky" height="18px" /></a>
						<?
					}
					?>
				</td>
				<td style="width: 100px; text-align:center;">
					<?
					if (haveRight("ZAKAZKY_SMAZAT")){
						?>
						<span style="cursor: pointer;" id="odkaz_smazat_<?echo $row['id_zakazky'];?>"	onClick="ukaz_form_smazat(<?echo $row['id_zakazky'];?>)">
							<img src="files/smazat.png" height="16px">
						</span>
						<br />
						<span id="smazat_<?echo $row['id_zakazky'];?>" style="display: none;">
							<a href="?show=zakazky&smaz_id=<?echo $row['id_zakazky'];?>">Ano</a>
							<a style="margin-left: 20px;" href="javascript:void(0)" onclick="skryj_form_smazat(<?echo $row['id_zakazky'];?>)">Ne</a>
						</span>
						<?
					}
					?>
				</td>
			</tr>
			<?
		}
		?>
	</table>
	<?
}
?>