<?
	require_once '../../classes/class_mysql.php';
		$sql=new mysql;

	require_once '../../classes/class_user.php';
		$user=new classUser;
	
	require_once "../../includes/common.php";
	if (isset($_GET['id_zak_vyrobku']) && haveRight('ZAKAZKY_EDITACE')){
		if (isset($_GET['jedn_cena'])){
			$jedn_cena_temp = str_replace(",", ".", $_GET['jedn_cena']);
			if (is_numeric($jedn_cena_temp)){
				$sql->query("UPDATE zak_vyrobky SET jedn_cena='$jedn_cena_temp' WHERE id_zak_vyrobku=$_GET[id_zak_vyrobku]");
				?><img src="../../files/ok.png" height="13px" /><?
			}
			else {
				?><img src="../../files/ko.png" height="13px" /><?
			}
		}
		
		if (isset($_GET['fakturace'])){
			$fakturace_temp = str_replace(",", ".", $_GET['fakturace']);
			if (is_numeric($fakturace_temp)){
				$sql->query("UPDATE zak_vyrobky SET fakturace='$fakturace_temp' WHERE id_zak_vyrobku=$_GET[id_zak_vyrobku]");
				?><img src="../../files/ok.png" height="13px" /><?
			}
			else {
				?><img src="../../files/ko.png" height="13px" /><?
			}
		}
		
		if (isset($_GET['vedlejsi_naklady'])){
			$vedlejsi_naklady_temp = str_replace(",", ".", $_GET['vedlejsi_naklady']);
			if (is_numeric($vedlejsi_naklady_temp)){
				$sql->query("UPDATE zak_vyrobky SET vedlejsi_naklady='$vedlejsi_naklady_temp' WHERE id_zak_vyrobku=$_GET[id_zak_vyrobku]");
				?><img src="../../files/ok.png" height="13px" /><?
			}
			else {
				?><img src="../../files/ko.png" height="13px" /><?
			}
		}
		
		if (isset($_GET['rozpracovanost'])){
			$rozpracovanost_temp = str_replace(",", ".", $_GET['rozpracovanost']);
			if (is_numeric($rozpracovanost_temp)){
				$sql->query("UPDATE zak_vyrobky SET rozpracovanost='$rozpracovanost_temp' WHERE id_zak_vyrobku=$_GET[id_zak_vyrobku]");
				?><img src="../../files/ok.png" height="13px" /><?
			}
			else {
				?><img src="../../files/ko.png" height="13px" /><?
			}
		}
		
		if (isset($_GET['id_operace_vnejsi'])){
		$sql->query("UPDATE zak_vyr_operace_vnejsi SET poznamka='$_GET[poznamka]' WHERE id_operace_vnejsi=$_GET[id_operace_vnejsi] AND id_zak_vyrobku=$_GET[id_zak_vyrobku]");
		?>
		<img src="../../files/ok.png" height="13px" />
		<?
	}
	}
	
?>