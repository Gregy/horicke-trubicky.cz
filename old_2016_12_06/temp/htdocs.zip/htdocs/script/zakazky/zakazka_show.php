<script src="js/tooltip_wz/wz_tooltip.js" type="text/javascript"></script>
<?
if (haveRight('ZAKAZKY')){
	if (isset($_GET['id_zakazky'])){
		global $sql;
		$temp=$sql->query_array("SELECT  z.id_zakazky, z.cislo_zakazky, z.rok, z.id_firmy, z.datum_zadani, z.termin_dokonceni, z.datum_editace, u.name editoval, z.id_stavu, z.poznamka, 
									z.nazev_firmy, z.ulice, z.mesto, z.psc, z.stat, z.telefon, z.email, z.ic, z.dic, z.bank_uc_pred, z.bank_uc_za, z.spec_symb, s.nazev_stavu, rodic_zakazka
								FROM zakazky z
								JOIN stavy s ON z.id_stavu = s.id_stavu
								JOIN user u ON u.id_uzivatel = z.editoval
								WHERE id_zakazky = '$_GET[id_zakazky]'");
		$id_zakazky = $temp['id_zakazky'];
		$cislo_zakazky = $temp['cislo_zakazky'];
		$rok = $temp['rok'];
		$id_firmy = $temp['id_firmy'];
		$datum_zadani = StrFTime("%d.%m.%Y %H:%M", $temp['datum_zadani']);
		$termin_dokonceni = StrFTime("%d.%m.%Y", $temp['termin_dokonceni']);
		$datum_editace = StrFTime("%d.%m.%Y %H:%M", $temp['datum_editace']);
		$editoval = $temp['editoval'];
		$id_stavu = $temp['id_stavu'];
		$poznamka = $temp['poznamka'];
		$nazev_firmy = $temp['nazev_firmy'];
		$ulice = $temp['ulice'];
		$mesto = $temp['mesto'];
		$psc = $temp['psc'];
		$stat = $temp['stat'];
		$telefon = $temp['telefon'];
		$email = $temp['email'];
		$ic = $temp['ic'];
		$dic = $temp['dic'];
		$bank_uc_pred = $temp['bank_uc_pred'];
		$bank_uc_za = $temp['bank_uc_za'];
		$spec_symb = $temp['spec_symb'];
		$nazev_stavu = $temp['nazev_stavu'];
		$rodic_zakazka=$temp['rodic_zakazka'];
	}
	if (!is_print_mod()){
		?>
		<div style="text-align: center; padding: 5px;">
			<span>
				<a href="?show=zakazky" class="zpet">Zpět na seznam zakázek</a>
			</span>
			
			<span style="margin-left: 50px;">
				<?
				if (haveRight("ZAKAZKY")){
					?>
					<a style="text-decoration: none;" href="?show=zakazka_vykony&id_zakazky=<?echo $id_zakazky;?>"><img src="files/vykony.png" title="Výkony zaměstnanců" height="18px" /></a>
					<?
				}
				?>
			</span>
			<span style="margin-left: 50px;">
				<?
				if (haveRight("ZAKAZKY_EDITACE")){
					?>
					<a style="text-decoration: none;" href="?show=zakazka_edit&id_zakazky=<?echo $id_zakazky;?>"><img src="files/edit.png" title="Editace zakázky" height="18px" /></a>
					<?
				}
				?>
			</span>
			<span style="margin-left: 50px;">
				<?
				if (haveRight("DODACI_LISTY_EDITACE")){
					?>
					<a style="text-decoration: none;" href="?show=expedice&id_firmy=<?echo $id_firmy;?>"><img src="files/expedice.png" title="Expedice zakázky" height="18px" /></a>
					<?
				}
				?>
			</span>
			<span style="margin-left: 50px;">
				<?
				if (haveRight("ZAKAZKY")){
					?>
					<a style="text-decoration: none;" href="?show=zakazka_soubory&id_zakazky=<?echo $id_zakazky;?>"><img src="files/files.png" title="Soubory k zakázce" height="18px" /></a>
					<?
				}
				?>
			</span>
		</div>
		<?
	}
	if (is_print_mod()){
		?>
		<div style="font-size:150%;">
		<?
	}
	?>
	<div style="text-align: center; padding: 5px; border: 1px solid;">
		<table cellspacing="0" cellpadding="1" border="0" width="100%" align="center">
			<tr>
				<td>Název firmy</td>
				<td>Číslo zakázky</td>
				<td>Termín dokončení</td>
				<td>Stav zakázky</td>
			</tr>
			<tr>
				<td style="vertical-align: top;">
					<b><?php echo $nazev_firmy;?></b>
				</td>
				<td style="vertical-align: top; width: 150px;">
					<b><?php echo cislo_rok($cislo_zakazky, $rok);?></b>
					<?
					if ($rodic_zakazka>0){
						$temp = $sql->query_array("SELECT cislo_zakazky, rok FROM zakazky WHERE id_zakazky=$rodic_zakazka");
						echo "<br />Subzakázka pro " . cislo_rok($temp['cislo_zakazky'], $temp['rok']);
					}
					?>
				</td>
				<td style="vertical-align: top; width: 150px;">
					<span style="font-weight: bold;"><?php echo $termin_dokonceni;?></span>
				</td>
				<td style="vertical-align: top; width: 150px;">
					<span style="font-weight: bold;"><?php echo $nazev_stavu;?></span>
				</td>
			</tr>
			<tr>
				<td colspan=4 style="text-align: left;">
					<?
					if (!empty($poznamka)){
						?>
						<div style="border-top: #aaa 1px dashed;">
							<b>Poznámka</b><br />
							<?php echo $poznamka;?>
						</div>
						<?
					}
					?>
				</td>
			</tr>
			<tr style="font-size: 80%;">
				<td></td>
				<td></td>
				<td>
					Zákázku naposledy editoval(a):
				</td>
				<td>
					<?
					echo $editoval . "<br />". $datum_editace;
					?>
				</td>
			</tr>
		</table>
	</div>
	<?
	$rows = $sql->query("SELECT zv.id_zak_vyrobku, zv.nazev_vyrobku, zv.pocet, zv.jedn_cena, zv.datum_editace, u.name editoval,
							zv.nazev_baleni, zv.nazev_lakovani, zv.barevnost, zv.konstrukce_obalu
						FROM zak_vyrobky zv
						JOIN user u ON u.id_uzivatel = zv.editoval
						WHERE id_zakazky=$id_zakazky and smazano=0");
	?>
	<table cellspacing="0" cellpadding="5" border="1" width="99%" align="center">
		<?
		$i=0;
		while ($row=$sql->fetch_array($rows)){
			(($i % 2)==0) ? $color="#CFC" : $color="#FFC";
			$i++;
			$datum_editace = StrFTime("%d.%m.%Y %H:%M", $row['datum_editace']);
			?>
			<tr style="text-align:center; background-color: <?echo $color;?>;">
				<td style="border-top: 1px dotted;">
					<b>Výrobek</b><br />
					<span style="font-size: 14px; font-weight: bold; color: #00F;">
						<? 
						echo $row['nazev_vyrobku'];
						?>
					</span>
				</td>
				<td style="border-top: 1px dotted;">
					<b>Počet ks</b><br />
					<?
					$pocet=$row['pocet'];
					$pocet = number_format($pocet, 0, '.', ' ');
					echo $pocet;
					
					$exp = 0;
					$expedovano = $sql->query("SELECT pocet FROM dod_lis_vyrobky dlv
												JOIN dodaci_listy dl ON dl.id_dodaciho_listu = dlv.id_dodaciho_listu
												WHERE id_zak_vyrobku = $row[id_zak_vyrobku] and dl.smazano=0");
					if ($sql->num_rows($expedovano)){
						while ($temp=$sql->fetch_array($expedovano)){
							$exp = $exp + $temp['pocet'];
						}
						$exp_txt = number_format($exp, 0, '.', ' ');
						?>
						<div style="font-size: 90%">
							vyexpedováno: <?echo $exp_txt;?>
						</div>
						<?
					}
					?>
				</td>
				<td style="border-top: 1px dotted;">
					<?
					if (!is_print_mod()){
						$cena = number_format($row['jedn_cena']*$row['pocet'], 2, '.', ' ');
						?>
						<b>Celková cena (Kč)</b><br />
						<?
						echo $cena;	
						
						if ($exp>0){
							(($row['jedn_cena']*($row['pocet']-$exp))>0) ? $cena = number_format($row['jedn_cena']*($row['pocet']-$exp), 2, '.', ' ') : $cena = 0;
							echo "<br>Ve výrobě za: " . $cena;
						}
					}
					?>
				</td>
				<td style="border-top: 1px dotted;">
					<?
					if (!is_print_mod()){
						$vydejky = $sql->query("SELECT id_skl_vydejky, cislo_vydejky, rok FROM skl_vydejky sv
												WHERE id_zak_vyrobku = $row[id_zak_vyrobku] AND smazano=0 AND rozpracovano=0");
						if ($sql->num_rows($vydejky)>0){
							$text_vydejek = "<b>Výdejky k tomuto výrobku</b><br /><br />";
							while ($vydejka = $sql->fetch_array($vydejky)){
								$text_vydejek .= "<b>" . $vydejka['cislo_vydejky'] . "/" . $vydejka['rok'] . "</b><br />";
								$vydane_materialy = $sql->query("SELECT nazev_skl_polozky, popis_skl_polozky, mnozstvi, mj.zkratka_jednotky
																FROM skl_vyd_materialy svm
																JOIN merna_jednotka mj ON mj.id_merna_jednotka = svm.id_merna_jednotka
																WHERE id_skl_vydejky = $vydejka[id_skl_vydejky]");
								while ($vm = $sql->fetch_array($vydane_materialy)){
									$text_vydejek .= $vm['nazev_skl_polozky'] . " (" . $vm['popis_skl_polozky'] . ") - " . $vm['mnozstvi'] . " " . $vm['zkratka_jednotky'] . "<br />";
								}
							}
							?>
							<span onmouseover="Tip('<?echo $text_vydejek;?>')" onmouseout="UnTip()" style>
								<img src="files/lupa.gif" height="15px" />
							</span>
							<br />
							<?
						}
						?>
						<span>
						<a href="?show=vydejka_new&id_zak_vyrobku=<?echo $row['id_zak_vyrobku'];?>">Vytvořit výdejku</a><br />
						<a href="?show=vydejka_kons_new&id_zak_vyrobku=<?echo $row['id_zak_vyrobku'];?>">Vytvořit výdejku z kons.skladu</a>
						</span>
						
						<span style="margin-left: 50px;">
						<a href="?show=reklamace_new&id_zak_vyrobku=<?echo $row['id_zak_vyrobku'];?>"><img src="files/reklamace.png" title="Vytvořit reklamaci" height="18px" /></a><br />
						</span>
						<?
					}
					?>
				</td>
			</tr>
			<tr style="background-color: <?echo $color;?>;">
				<td style="font-size: 90%;">
					<b>Název balení</b><br />
					<?
					//zv.nazev_baleni, zv.nazev_lakovani, zv.barevnost, zv.konstrukce_obalu
					echo $row['nazev_baleni'];
					?>
				</td>
				<td style="font-size: 90%;">
					<b>Název lakování</b><br />
					<?
					echo $row['nazev_lakovani'];
					?>
				</td>
				<td style="font-size: 90%;">
					<b>Barevnost</b><br />
					<?
					echo $row['barevnost'];
					?>
				</td>
				<td style="font-size: 90%;">
					<b>Konstrukce obalu</b><br />
					<?
					echo $row['konstrukce_obalu'];
					?>
				</td>
			</tr>
			<?
			$rows_under = $sql->query("SELECT o.nazev_operace_vnitrni, zvo.poznamka
											FROM zak_vyr_operace_vnitrni zvo
										JOIN operace_vnitrni o ON o.id_operace_vnitrni = zvo.id_operace_vnitrni
										WHERE zvo.id_zak_vyrobku=$row[id_zak_vyrobku]
										ORDER BY o.poradi");
					
			if ($sql->num_rows($rows_under)>0){
				?>
				<tr style="background-color: <?echo $color;?>;">
					<td colspan=4>
						<ul style="margin: 0px; padding: 0px;">
						<b>Vnitřní operace</b>
						<?
						while ($row_under=$sql->fetch_array($rows_under)){
							?>
							<li style="margin: 0 0 0 10px;">
							<?
							echo $row_under['nazev_operace_vnitrni'];
							if (!empty($row_under['poznamka'])) 
								echo " (<i>" . $row_under['poznamka'] . "</i>)";
							?>
							</li>
							<?
						}
						?>
						</ul>
					</td>
				</tr>
				<?
			}
			?>
			<?
			$rows_under = $sql->query("SELECT o.nazev_operace_vnejsi, zvo.poznamka
											FROM zak_vyr_operace_vnejsi zvo
										JOIN operace_vnejsi o ON o.id_operace_vnejsi = zvo.id_operace_vnejsi
										WHERE zvo.id_zak_vyrobku=$row[id_zak_vyrobku]
										ORDER BY o.poradi");
			
			if ($sql->num_rows($rows_under)>0){
				?>
				<tr style="background-color: <?echo $color;?>;">
					<td colspan=4>					
						<ul style="margin: 0px; padding: 0px">
						<b>Operace subdodavatelů</b>
						<?
						while ($row_under=$sql->fetch_array($rows_under)){
							?>
							<li style="margin: 0 0 0 10px;">
							<?
							echo $row_under['nazev_operace_vnejsi'];
							if (!empty($row_under['poznamka'])) 
								echo " (<i>" . $row_under['poznamka'] . "</i>)";
							?>
							</li>
							<?
						}
						?>
						</ul>
					</td>
				</tr>
				<?
			}
			?>
			<tr style="background-color: <?echo $color;?>;">
				<td colspan=4>
					<b>Výsekové formy</b><br />
					<?
					$rows_under = $sql->query("SELECT id_zak_vyr_vysekove_formy, cislo_vysekove_formy, nazev_vysekove_formy, ks_na_arch, min_rozmer_sirka, min_rozmer_delka, rozmer_obalu_sirka, rozmer_obalu_delka, rozmer_obalu_vyska
													FROM zak_vyr_vysekove_formy
												WHERE id_zak_vyrobku=$row[id_zak_vyrobku]
												ORDER BY id_zak_vyr_vysekove_formy");
					while ($row_under=$sql->fetch_array($rows_under)){
						echo $row_under['cislo_vysekove_formy'] . ' - ' . $row_under['nazev_vysekove_formy'] . ' - ' . $row_under['ks_na_arch'] . ' ks/arch (min.rozměr: ' . $row_under['min_rozmer_sirka'] . 'x'
							. $row_under['min_rozmer_delka'] . ', rozměry obalu: ' . $row_under['rozmer_obalu_sirka'] . 'x' . $row_under['rozmer_obalu_delka'] . 'x' . $row_under['rozmer_obalu_vyska'] . ')';
							$soubory = $sql->query("SELECT nazev_souboru, cesta FROM zak_vys_for_soubory WHERE id_zak_vyr_vysekove_formy=$row_under[id_zak_vyr_vysekove_formy]");
							if ($sql->num_rows($soubory)>0){
								while ($soubor=$sql->fetch_array($soubory)){
									?>
									<a href="<?echo $soubor['cesta'];?>" style="margin-left: 5px; margin-right: 5px;"><img src="files/download.png" height="15px" title="<?echo $soubor['nazev_souboru'];?>" /></a>
									<?
								}
							}
						echo "<br />";
					}
					?>	
				</td>
			</tr>
			<tr style="background-color: <?echo $color;?>;">
				<td colspan=4>
					<b>Materiály:</b>
				</td>
			</tr>
			<tr style="background-color: <?echo $color;?>; border-bottom: 1px dotted;">
				<td colspan=4>
					<?
					$rows_under = $sql->query("SELECT id_zak_vyr_material, nazev_materialu, hodnota, zkratka_jednotky 
												FROM zak_vyr_material zvm
												LEFT JOIN merna_jednotka mj ON mj.id_merna_jednotka = zvm.id_merna_jednotka
												WHERE id_zak_vyrobku=$row[id_zak_vyrobku] and smazano=0
												ORDER BY razeni");
					while ($row_under=$sql->fetch_array($rows_under)){
						?>
						<div class="material">
							<?
							echo '<b>' . $row_under['nazev_materialu'] . ' '. $row_under['hodnota'] . ' '. $row_under['zkratka_jednotky'] . '</b><br />';
							$atributy = $sql->query("SELECT nazev_atributu, zkratka_jednotky, hodnota 
													FROM zak_vyr_mat_atributy zvma
													LEFT JOIN merna_jednotka mj ON mj.id_merna_jednotka = zvma.id_merna_jednotka
													WHERE id_zak_vyr_material=$row_under[id_zak_vyr_material] AND zvma.smazano=0
													ORDER BY zvma.razeni");
							while ($atribut=$sql->fetch_array($atributy)){
								echo $atribut['nazev_atributu'] . ' '. $atribut['hodnota'] . ' '. $atribut['zkratka_jednotky'] . '<br />';
							}
							
							?>
						</div>
						<?
					}
					?>	
				</td>
			</tr>
			<?
		}
		?>
	</table>
	<?php
	if (is_print_mod()){
		?>
		</div>
		<?
	}
} else echo "<p class=\"chyba\">Na toto nemáte přiřazená práva.</p>";
?>