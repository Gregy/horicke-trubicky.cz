<?
if (haveRight('ZAKAZKY_EDITACE')){
	if (isset($_GET['id_zakazky'])){
		global $sql;
		$temp=$sql->query_array("SELECT z.id_zakazky, z.id_firmy
								FROM zakazky z
								WHERE id_zakazky = '$_GET[id_zakazky]'");
		$id_subzakazky = $temp['id_zakazky'];
		$id_firmy = $temp['id_firmy'];
	}
	
	if ($_POST['save']=="Uložit"){
		$error="";
		$id_firmy = $_POST['id_firmy'];
		$id_subzakazky = $_POST['id_subzakazky'];
		$nazev_zakazky = $_POST['nazev_zakazky'];
		$termin_dokonceni = $_POST['termin_dokonceni'];
		
		$error.=($id_firmy==0) ? "<p class=\"chyba\">Vyberte firmu.</p>" : "";
		$error.=(empty($termin_dokonceni)) ? "<p class=\"chyba\">Nebyl zadán termín dokončení.</p>" : "";
	}
	
	if ($error=="" && $_POST['save']=="Uložit"){
		$datum_editace = Time();
		$rok = date('Y');
		$max_cislo_zakazky = $sql->query_array("SELECT max(cislo_zakazky) cislo FROM zakazky WHERE rok=$rok");
		if ($max_cislo_zakazky['cislo']>0) 
			$max_cislo_zakazky = $max_cislo_zakazky['cislo']+1;
		else
			$max_cislo_zakazky = 1;
		$termin_dokonceni = strtotime($termin_dokonceni);
		
		$sql->query("INSERT INTO zakazky
					SELECT NULL, '$max_cislo_zakazky', '$rok', '$id_firmy', '$datum_editace', '$termin_dokonceni', '$datum_editace',  '$_SESSION[ot_userId]', 100, '', 
						nazev_firmy, ulice, mesto, psc, stat, telefon, email, ic, dic, bank_uc_pred, bank_uc_za, spec_symb, kontaktni_osoba, '$id_subzakazky', '' FROM firmy 
					WHERE id_firmy=$id_firmy");
		$id_zakazky=$sql->insert_id();
		
		$saved=1;
		echo "<p class=\"oznameni\">Nová zakázka vytvořena.</p>";
		$refresh_page=$page->_head_path . "?show=zakazka_edit&id_zakazky=" . $id_zakazky;
		echo "<meta http-equiv=\"refresh\" content=\"1; url=$refresh_page\">";
		message_auto_forward($refresh_page);
	} else if ($error!=""){
		echo "<hr /><b>" . $error . "</b><hr />";
	}
	
	if ($saved==0){
		?>
		<form action="" method="post" name="zakazky">
			<div style="text-align: center; padding: 5px; border-bottom: #aaa 1px dashed;">
				<input type="submit" name="save" value="Uložit" id="ulozit" />
				<span style="padding-left: 100px">
					<a href="?show=zakazky" class="zpet">Zpět na seznam zakázek (bez uložení)</a>
				</span>
			</div>
			
			<table cellspacing="0" cellpadding="5" border="0" width="50%" align="center">
				<tr>
					<td><b>Pro společnost</b> (*)</td>
					<td>
						<SELECT id="id_firmy" name="id_firmy">
							<OPTION value="0">Vyberte možnost...</OPTION>
							<?
							$result=$sql->query("SELECT id_firmy, nazev_firmy FROM firmy
												WHERE smazano=0
												ORDER BY nazev_firmy");
							while ($row=$sql->fetch_array($result)){
								if ($row['id_firmy'] == $id_firmy){
									?>
									<OPTION value="<?echo $row['id_firmy'];?>" selected="selected"><?echo $row['nazev_firmy']?></OPTION>
									<?
								} else {
									?>
									<OPTION value="<?echo $row['id_firmy'];?>"><?echo $row['nazev_firmy']?></OPTION>
									<?
								}
							}
							?>
						</SELECT>
					</td>
				</tr>
				<tr>
					<td><b>Termín dokončení (dd.mm.rrrr)</b> (*)</td>
					<td><input id="termin_dokonceni" type="text" size="16" maxlength="16" name="termin_dokonceni" value="<?php echo "$termin_dokonceni";?>" /></td>
				</tr>
				<tr>
					<td><b>Subzakázka pro zakázku ze SHV</b></td>
					<td>
						<SELECT id="id_subzakazky" name="id_subzakazky">
							<OPTION value="0">Vyberte možnost...</OPTION>
							<?
							$result=$sql->query("SELECT id_zakazky, cislo_zakazky, rok, nazev_firmy FROM zakazky
												WHERE id_stavu=550
												ORDER BY rok DESC, cislo_zakazky DESC");
							while ($row=$sql->fetch_array($result)){
								if ($row['id_zakazky'] == $id_subzakazky){
									?>
									<OPTION value="<?echo $row['id_zakazky'];?>" selected="selected"><?echo cislo_rok($row['cislo_zakazky'], $row['rok']) . " - " . $row['nazev_firmy'];?></OPTION>
									<?
								} else {
									?>
									<OPTION value="<?echo $row['id_zakazky'];?>"><?echo cislo_rok($row['cislo_zakazky'], $row['rok']) . " - " . $row['nazev_firmy'];?></OPTION>
									<?
								}
							}
							?>
						</SELECT>
					</td>
				</tr>
			</table>
			<br />(*) - povinné položky
		</form>
		<?
	}
} else echo "<p class=\"chyba\">Na toto nemáte přiřazená práva.</p>";