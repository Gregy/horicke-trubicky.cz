<?
if (haveRight('ZAKAZKY_EDITACE')){
	if (isset($_GET['id_zakazky'])){
		global $sql;
		$temp=$sql->query_array("SELECT  z.id_zakazky, z.cislo_zakazky, z.rok, z.id_firmy, z.datum_zadani, z.termin_dokonceni, z.datum_editace, u.name editoval, z.id_stavu, z.poznamka, 
									z.nazev_firmy, z.ulice, z.mesto, z.psc, z.stat, z.telefon, z.email, z.ic, z.dic, z.bank_uc_pred, z.bank_uc_za, z.spec_symb, s.nazev_stavu, z.kontaktni_osoba, z.rodic_zakazka, cislo_objednavky
								FROM zakazky z
								JOIN stavy s ON z.id_stavu = s.id_stavu
								JOIN user u ON u.id_uzivatel = z.editoval
								WHERE id_zakazky = '$_GET[id_zakazky]'");
		$id_zakazky = $temp['id_zakazky'];
		$cislo_zakazky = $temp['cislo_zakazky'];
		$rok = $temp['rok'];
		$id_firmy = $temp['id_firmy'];
		$datum_zadani = StrFTime("%d.%m.%Y %H:%M", $temp['datum_zadani']);
		$termin_dokonceni = StrFTime("%d.%m.%Y", $temp['termin_dokonceni']);
		$datum_editace = StrFTime("%d.%m.%Y %H:%M", $temp['datum_editace']);
		$editoval = $temp['editoval'];
		$id_stavu = $temp['id_stavu'];
		$poznamka = $temp['poznamka'];
		$nazev_firmy = $temp['nazev_firmy'];
		$ulice = $temp['ulice'];
		$mesto = $temp['mesto'];
		$psc = $temp['psc'];
		$stat = $temp['stat'];
		$telefon = $temp['telefon'];
		$email = $temp['email'];
		$ic = $temp['ic'];
		$dic = $temp['dic'];
		$bank_uc_pred = $temp['bank_uc_pred'];
		$bank_uc_za = $temp['bank_uc_za'];
		$spec_symb = $temp['spec_symb'];
		$nazev_stavu = $temp['nazev_stavu'];
		$kontaktni_osoba = $temp['kontaktni_osoba'];
		$rodic_zakazka=$temp['rodic_zakazka'];
		$cislo_objednavky=$temp['cislo_objednavky'];
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	if (isset($_POST['add_vyrobek'])){
		$error_under="";
		if ($_POST['id_vyrobku']>0) {
			$id_vyrobku = $_POST['id_vyrobku'];
		} else {
			$error_under.="<p class=\"chyba\">Vyberte výrobek.</p>";
		}
	}
	
	if ($error_under=="" && (isset($_POST['add_vyrobek']))){
		$datum_editace = Time();
		
		$sql->query("INSERT INTO zak_vyrobky
					SELECT NULL, $_GET[id_zakazky], nazev_vyrobku, '$_SESSION[ot_userId]', '$datum_editace', nazev_baleni, 0, 0, 0, 0, 0, l.nazev_lakovani, barevnost, konstrukce_obalu, v.cislo_vykresu, 0
					FROM vyrobky v
					JOIN baleni b ON b.id_baleni=v.id_baleni
					LEFT JOIN lakovani l ON l.id_lakovani = v.id_lakovani
					WHERE id_vyrobku=$id_vyrobku");
		$nove_id_zak_vyrobku = $sql->insert_id();
		
		$rows = $sql->query("SELECT id_vysekove_formy FROM vyrobek_vysekove_formy WHERE id_vyrobku=$id_vyrobku");
		while ($row = $sql->fetch_array($rows)){
			$sql->query("INSERT INTO zak_vyr_vysekove_formy
					SELECT  NULL, $nove_id_zak_vyrobku, cislo_vysekove_formy, nazev_vysekove_formy, ks_na_arch, min_rozmer_sirka, min_rozmer_delka, rozmer_obalu_sirka, rozmer_obalu_delka, rozmer_obalu_vyska, poznamka 
					FROM vysekove_formy vf 
					WHERE vf.id_vysekove_formy=$row[id_vysekove_formy]");
			$nove_id_zak_vyr_vysekove_formy = $sql->insert_id();
			$sql->query("INSERT INTO zak_vys_for_soubory
						SELECT NULL, $nove_id_zak_vyr_vysekove_formy, nazev_souboru, cesta
						FROM vys_for_soubory
						WHERE id_vysekove_formy=$row[id_vysekove_formy] AND smazano=0");
		}
		
		$sql->query("INSERT INTO zak_vyr_operace_vnitrni
					SELECT $nove_id_zak_vyrobku, id_operace_vnitrni, poznamka
					FROM vyrobek_operace_vnitrni
					WHERE id_vyrobku=$id_vyrobku");
		
		$sql->query("INSERT INTO zak_vyr_operace_vnejsi
					SELECT $nove_id_zak_vyrobku, id_operace_vnejsi, poznamka
					FROM vyrobek_operace_vnejsi
					WHERE id_vyrobku=$id_vyrobku");
		
		$rows = $sql->query("SELECT id_vyrobek_material FROM vyrobek_material WHERE id_vyrobku=$id_vyrobku");
		while ($row = $sql->fetch_array($rows)){
			$sql->query("INSERT INTO zak_vyr_material
						SELECT NULL, $nove_id_zak_vyrobku, m.nazev_materialu, vm.hodnota, m.id_merna_jednotka, vm.razeni, '$_SESSION[ot_userId]', '$datum_editace', 0
						FROM vyrobek_material vm
						JOIN materialy m ON vm.id_materialu = m.id_materialu
						WHERE vm.id_vyrobek_material = $row[id_vyrobek_material]");
			$nove_id_zak_vyr_material = $sql->insert_id();
			$sql->query("INSERT INTO zak_vyr_mat_atributy
						SELECT NULL, $nove_id_zak_vyr_material, a.nazev_atributu, a.id_merna_jednotka, vma.hodnota, a.razeni, '$_SESSION[ot_userId]', '$datum_editace', 0
						FROM vyrobek_material_atribut vma
						JOIN atributy a ON a.id_atributu = vma.id_atributu
						WHERE id_vyrobek_material = $row[id_vyrobek_material]");
		}
		unset($id_vyrobku);	
	} else if ($error_under!=""){
		echo "<hr /><b>" . $error_under . "</b><hr />";
	}

	if (isset($_GET['smaz_id'])){
		$datum_editace = Time();
		$sql->query("UPDATE zak_vyrobky SET smazano=1, editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace' WHERE id_zak_vyrobku=$_GET[smaz_id]");
	}
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	if (isset($_POST['save'])){
		$error="";
		if (isset($_POST['id_zakazky']))
			$id_zakazky = $_POST['id_zakazky'];
		$termin_dokonceni = $_POST['termin_dokonceni'];
		$id_stavu = $_POST['id_stavu'];
		$poznamka = $_POST['poznamka'];
		
		if ($id_stavu>100){
			$rows = $sql->query("SELECT id_zak_vyrobku FROM zak_vyrobky WHERE id_zakazky=$id_zakazky and smazano=0");
			if ($sql->num_rows($rows)>0){
				while ($row = $sql->fetch_array($rows)){
					if (empty($_POST["pocet_$row[id_zak_vyrobku]"]) || (!is_numeric($_POST["pocet_$row[id_zak_vyrobku]"]))){
						$error.="<p class=\"chyba\">Někde chybí počet ks u výrobku, nebo to není číselná hodnota.</p>";
						break;
					}
				}
			} else {
				$error.="<p class=\"chyba\">Do zakázky není zadán žádný výrobek. Nemůžete ho převést ze stavu Připravuje se...</p>";
			}
		}
	}
	if ($error=="" && isset($_POST['save'])){
		
		$saved=1;
		echo "<p class=\"oznameni\">Zakázka v pořádku uložena.</p>";
		if ($_GET['prehled']==1){
			$refresh_page=$page->_head_path . "?show=prehledy";
		} else {
			$refresh_page=$page->_head_path . "?show=zakazky";
		}
		echo "<meta http-equiv=\"refresh\" content=\"1; url=$refresh_page\">";
		message_auto_forward($refresh_page);
	} else if ($error!=""){
		echo "<hr /><b>" . $error . "</b><hr />";
	}
		if ($saved==0){
			?>
			<form action="" method="post" name="zakazky">
				<div style="text-align: center; padding: 5px; border-bottom: #aaa 1px dashed;">
					<input type="submit" name="save" value="Uložit" id="ulozit" />
					<span style="padding-left: 100px">
						<a href="?show=zakazky" class="zpet">Zpět na seznam zakázek (bez uložení)</a>
					</span>
				</div>
				<div style="text-align: center; padding: 5px; border-bottom: #aaa 1px dashed;">
					<table cellspacing="0" cellpadding="1" border="0" width="100%" align="center">
						<tr>
							<td>Název odběratele</td>
							<td>Číslo zakázky</td>
							<td>Číslo objednávky</td>
							<td>Termín dokončení</td>
							<td>Stav zakázky</td>
						</tr>
						<tr>
							<td style="vertical-align: top; cursor: pointer;" onclick="ukaz_skryj('adresy')" title="Kliknutím zobrazíte adresy">
								<b><?php echo $nazev_firmy;?></b>
								<div id="adresy" style="display: none;">
									<div style="font-weight: bold; color: #99F;">
										Fakturační adresa:
										<a href="?show=firma_edit&id_firmy=<?echo $id_firmy;?>&id_zakazky=<?echo $id_zakazky;?>" style="text-decoration: none;" title="Naposledy editoval(a) <?echo $row['editoval'] . ' ' . $datum_editace;?>"><img src="files/edit.png" height="16px"></a>
									</div>
									<div>
										<? 
										echo "$ulice, $mesto, $psc, $stat<br />";
										if (!empty($telefon)) echo $telefon . ", ";
										if (!empty($email)) echo $email;
										echo "<br />";
										if (!empty($bank_uc_pred) && !empty($bank_uc_za)) echo $bank_uc_pred . "/" . $bank_uc_za;
										if (!empty($spec_symb)) echo ", " . $spec_symb;
										echo "<br />";
										if (!empty($ic)) echo $ic;
										if (!empty($dic)) echo ", " . $dic;
										if (!empty($kontaktni_osoba)) echo "<br />Kontaktní osoba: " . $kontaktni_osoba;
										?>
									</div>
								</div>
							</td>
							<td style="vertical-align: top; width: 150px;">
								<b><?php echo cislo_rok($cislo_zakazky, $rok);?></b>
								<?
								if ($rodic_zakazka>0){
									$temp = $sql->query_array("SELECT cislo_zakazky, rok FROM zakazky WHERE id_zakazky=$rodic_zakazka");
									echo "<br />Subzakázka pro " . cislo_rok($temp['cislo_zakazky'], $temp['rok']);
								}
								?>
							</td>
							<td style="vertical-align: top; width: 150px;">
								<input type="text" size="14" maxlength="100" name="cislo_obj" id="cislo_obj" value="<?echo $cislo_objednavky;?>"
									onblur="ajax('script/zakazky/aj.php?id_zakazky=<?echo $id_zakazky;?>&cislo_objednavky='+document.getElementById('cislo_obj').value,'cislo_obj_result');" />
								<span id="cislo_obj_result" style="width: 16px"></span>
							</td>
							<td style="vertical-align: top; width: 150px;">
								<input type="text" size="14" maxlength="100" name="termin_dok" id="termin_dok" value="<?echo $termin_dokonceni;?>"
									onblur="ajax('script/zakazky/aj.php?id_zakazky=<?echo $id_zakazky;?>&termin_dokonceni='+document.getElementById('termin_dok').value,'termin_dok_result');" />
								<span id="termin_dok_result" style="width: 16px"></span>
							</td>
							<td style="vertical-align: top; width: 200px;">
								<select name="id_stavu" id="id_stavu" onchange="ajax('script/zakazky/aj.php?id_zakazky=<?echo $id_zakazky;?>&id_stavu='+document.getElementById('id_stavu').value,'id_stavu_result');">
									<?
									$result=$sql->query("SELECT id_stavu, nazev_stavu FROM stavy
														ORDER BY id_stavu");
									while ($row=$sql->fetch_array($result)){
										if ($row['id_stavu'] == $id_stavu){
											?>
											<OPTION value="<?echo $row['id_stavu'];?>" selected="selected"><?echo $row['nazev_stavu'];?></OPTION>
											<?
										} else {
											?>
											<OPTION value="<?echo $row['id_stavu'];?>"><?echo $row['nazev_stavu'];?></OPTION>
											<?
										}
									}
									?>
								</select>
								<span id="id_stavu_result" style="width: 16px"></span>
							</td>
						</tr>
						<tr>
							<td colspan=5 style="text-align: left;">
								<b>Poznámka</b><br />
								<textarea name="poznamka" id="poznamka" maxlength="500" cols="110" rows="2" onblur="ajax('script/zakazky/aj.php?id_zakazky=<?echo $id_zakazky;?>&poznamka='+document.getElementById('poznamka').value,'poznamka_result');" ><? echo $poznamka;?></textarea>
								<span id="poznamka_result" style="width: 16px"></span>
							</td>
						</tr>
					</table>
				</div>
				<?
				$rows = $sql->query("SELECT zv.id_zak_vyrobku, zv.nazev_vyrobku, zv.pocet, zv.datum_editace, u.name editoval,
										zv.nazev_baleni, zv.nazev_lakovani, zv.barevnost, zv.konstrukce_obalu,
										zv.cislo_vykresu, zv.jedn_cena, zv.vedlejsi_naklady, zv.fakturace, zv.rozpracovanost
									FROM zak_vyrobky zv
									JOIN user u ON u.id_uzivatel = zv.editoval
									WHERE id_zakazky=$id_zakazky and smazano=0");
				?>
				<table cellspacing="0" cellpadding="5" border="0" width="99%" align="center">
					<?
					$i=0;
					while ($row=$sql->fetch_array($rows)){
						(($i % 2)==0) ? $color="#CFC" : $color="#FFC";
						$i++;
						$datum_editace = StrFTime("%d.%m.%Y %H:%M", $row['datum_editace']);
						?>
						<tr style="text-align:center; background-color: <?echo $color;?>; vertical-align: top;">
							<td style="font-size: 14px; font-weight: bold; color: #00F; width: 30%;">
								<? 
								echo $row['nazev_vyrobku'];
								?>
								<br /><a href="?show=zak_vyrobek_edit&id_zak_vyrobku=<?echo $row['id_zak_vyrobku'];?>"><img src="files/edit.png" height="16px" title="Editovat materiály ve výrobku" /></a>
								<span style="margin-left: 50px">
									<span style="cursor: pointer;" id="odkaz_smazat_<?echo $row['id_zak_vyrobku'];?>"	onClick="ukaz_form_smazat(<?echo $row['id_zak_vyrobku'];?>)"
									title="Vytvořil(a) <?echo $row['editoval'] . ' ' . $datum_editace;?>">
										<img src="files/smazat.png" height="16px" />
									</span>
									<br />
									<span id="smazat_<?echo $row['id_zak_vyrobku'];?>" style="display: none;">
										<?($_GET['prehled']==1) ? $prehled="&prehled=1" : $prehled="";?>
										<a href="?show=zakazka_edit&id_zakazky=<?echo $id_zakazky;?>&smaz_id=<?echo $row['id_zak_vyrobku']; echo $prehled;?>">Ano</a>
										<a style="margin-left: 20px;" href="javascript:void(0)" onclick="skryj_form_smazat(<?echo $row['id_zak_vyrobku'];?>)">Ne</a>
									</span>
								</span>
							</td>
							<td style="width: 14%;">
								<b>Počet ks</b><br />
								<?
								if (!empty($_POST["pocet_$row[id_zak_vyrobku]"])){
									$pocet=$_POST["pocet_$row[id_zak_vyrobku]"];
								} else {
									$pocet=$row['pocet'];
								}
								?>
								<input type="text" size="4" maxlength="7" name="pocet_<?echo $row['id_zak_vyrobku'];?>" id="pocet_<?echo $row['id_zak_vyrobku'];?>"	value="<?echo $pocet;?>"
											onblur="ajax('script/zakazky/aj_pocet.php?id_zak_vyrobku=<?echo $row['id_zak_vyrobku'];?>&pocet='+document.getElementById('<?echo "pocet_" . $row['id_zak_vyrobku'];?>').value,'pocet_result<?echo $row['id_zak_vyrobku'];?>');" />
										<span id="pocet_result<?echo $row['id_zak_vyrobku'];?>" style="width: 16px"></span>
								<?
								$expedovano = $sql->query("SELECT pocet FROM dod_lis_vyrobky dlv
															JOIN dodaci_listy dl ON dl.id_dodaciho_listu = dlv.id_dodaciho_listu
															WHERE id_zak_vyrobku = $row[id_zak_vyrobku] and dl.smazano=0");
								if ($sql->num_rows($expedovano)){
									$exp = 0;
									while ($temp=$sql->fetch_array($expedovano)){
										$exp = $exp + $temp['pocet'];
									}
									$exp_txt = number_format($exp, 0, '.', ' ');
									?>
									<div style="font-size: 90%">
										vyexpedováno:<br /><?echo $exp_txt;?>
									</div>
									<?
								}
								?>
							</td>
							<td style="width: 14%;">
								<?
								if (haveRight('ZAKAZKY_EDITACE_CENA')){
									//tato podminka je udelana kvuli zakaznikovi Ella CS, s.r.o.
									if ($id_firmy!=11 || ($id_firmy==11 && $rodic_zakazka==0)){
										?>
										<b>Jedn.cena (Kč)</b><br />
										<?
										$jedn_cena=$row['jedn_cena'];
										?>
										<input type="text" size="4" maxlength="7" name="jedn_cena_<?echo $row['id_zak_vyrobku'];?>" id="jedn_cena_<?echo $row['id_zak_vyrobku'];?>"	value="<?echo $jedn_cena;?>"
													onblur="ajax('script/zakazky/aj_ceny.php?id_zak_vyrobku=<?echo $row['id_zak_vyrobku'];?>&jedn_cena='+document.getElementById('<?echo "jedn_cena_" . $row['id_zak_vyrobku'];?>').value,'jedn_cena_result<?echo $row['id_zak_vyrobku'];?>');" />
												<span id="jedn_cena_result<?echo $row['id_zak_vyrobku'];?>" style="width: 16px"></span>
										<?
									}
								}
								?>
							</td>
							<td style="width: 14%;">
								<?
								if (haveRight('ZAKAZKY_EDITACE_ROZPRACOVANOST')){
									?>
									<b>Rozpracovanost (%)</b><br />
									<?
									$rozpracovanost=$row['rozpracovanost'];
									?>
									<input type="text" size="4" maxlength="7" name="rozpracovanost_<?echo $row['id_zak_vyrobku'];?>" id="rozpracovanost_<?echo $row['id_zak_vyrobku'];?>"	value="<?echo $rozpracovanost;?>"
												onblur="ajax('script/zakazky/aj_ceny.php?id_zak_vyrobku=<?echo $row['id_zak_vyrobku'];?>&rozpracovanost='+document.getElementById('<?echo "rozpracovanost_" . $row['id_zak_vyrobku'];?>').value,'rozpracovanost_result<?echo $row['id_zak_vyrobku'];?>');" />
											<span id="rozpracovanost_result<?echo $row['id_zak_vyrobku'];?>" style="width: 16px"></span>
									<?
								}
								?>
							</td>
							<td style="width: 14%;">
								<?
								if (haveRight('ZAKAZKY_EDITACE_CENA') && $rodic_zakazka==0){
									?>
									<b>Vedl.nákl. (Kč)</b><br />
									<?
									$vedlejsi_naklady=$row['vedlejsi_naklady'];
									?>
									<input type="text" size="4" maxlength="7" name="vedlejsi_naklady_<?echo $row['id_zak_vyrobku'];?>" id="vedlejsi_naklady_<?echo $row['id_zak_vyrobku'];?>"	value="<?echo $vedlejsi_naklady;?>"
												onblur="ajax('script/zakazky/aj_ceny.php?id_zak_vyrobku=<?echo $row['id_zak_vyrobku'];?>&vedlejsi_naklady='+document.getElementById('<?echo "vedlejsi_naklady_" . $row['id_zak_vyrobku'];?>').value,'vedlejsi_naklady_result<?echo $row['id_zak_vyrobku'];?>');" />
											<span id="vedlejsi_naklady_result<?echo $row['id_zak_vyrobku'];?>" style="width: 16px"></span>
									<?
								}
								?>
							</td>
							<td style="width: 14%;">
								<?
								if (haveRight('ZAKAZKY_EDITACE_CENA')){
									//tato podminka je udelana kvuli zakaznikovi Ella CS, s.r.o.
									if ($id_firmy!=11 || ($id_firmy==11 && $rodic_zakazka==0)){
										?>
										<b>Fakturace (Kč)</b><br />
										<?
										$fakturace=$row['fakturace'];
										?>
										<input type="text" size="4" maxlength="7" name="fakturace_<?echo $row['id_zak_vyrobku'];?>" id="fakturace_<?echo $row['id_zak_vyrobku'];?>"	value="<?echo $fakturace;?>"
													onblur="ajax('script/zakazky/aj_ceny.php?id_zak_vyrobku=<?echo $row['id_zak_vyrobku'];?>&fakturace='+document.getElementById('<?echo "fakturace_" . $row['id_zak_vyrobku'];?>').value,'fakturace_result<?echo $row['id_zak_vyrobku'];?>');" />
												<span id="fakturace_result<?echo $row['id_zak_vyrobku'];?>" style="width: 16px"></span>
										<div id="fakt_predpokl" style="font-size: 90%;">
										<?
										if ($rodic_zakazka==0){
											?>
											mělo by být<br />
											<?
											
											$exp_txt = number_format($exp*$jedn_cena, 0, '.', ' ');
											echo $exp_txt;
										}
										?>
										</div>
										<?
									}
								}
								?>
							</td>
						</tr>
						<tr style="background-color: <?echo $color;?>; vertical-align: top;">
							<td style="font-size: 12px;">
								<b>Název balení</b><br />
								<?
								//zv.nazev_baleni, zv.nazev_lakovani, zv.barevnost, zv.konstrukce_obalu
								echo $row['nazev_baleni'];
								?>
							</td>
							<td style="font-size: 12px;">
								<b>Název lakování</b><br />
								<?
								echo $row['nazev_lakovani'];
								?>
							</td>
							<td style="font-size: 12px;">
								<b>Barevnost</b><br />
								<?
								echo $row['barevnost'];
								?>
							</td>
							<td style="font-size: 12px;">
								<b>Konstrukce obalu</b><br />
								<?
								echo $row['konstrukce_obalu'];
								?>
							</td>
							<td style="font-size: 12px;">
								<b>Číslo výkresu</b><br />
								<?
								echo $row['cislo_vykresu'];
								?>
							</td>
							<td></td>
						</tr>
						<tr style="background-color: <?echo $color;?>;">
							<td colspan=6>
								<b>Výsekové formy</b><br />
								<?
								$rows_under = $sql->query("SELECT id_zak_vyr_vysekove_formy, cislo_vysekove_formy, nazev_vysekove_formy, ks_na_arch, min_rozmer_sirka, min_rozmer_delka, rozmer_obalu_sirka, rozmer_obalu_delka, rozmer_obalu_vyska
																FROM zak_vyr_vysekove_formy
															WHERE id_zak_vyrobku=$row[id_zak_vyrobku]
															ORDER BY id_zak_vyr_vysekove_formy");
								while ($row_under=$sql->fetch_array($rows_under)){
									echo $row_under['cislo_vysekove_formy'] . ' - ' . $row_under['nazev_vysekove_formy'] . ' - ' . $row_under['ks_na_arch'] . ' ks/arch (min.rozměr: ' . $row_under['min_rozmer_sirka'] . 'x'
										. $row_under['min_rozmer_delka'] . ', rozměry obalu: ' . $row_under['rozmer_obalu_sirka'] . 'x' . $row_under['rozmer_obalu_delka'] . 'x' . $row_under['rozmer_obalu_vyska'] . ')';
										$soubory = $sql->query("SELECT nazev_souboru, cesta FROM zak_vys_for_soubory WHERE id_zak_vyr_vysekove_formy=$row_under[id_zak_vyr_vysekove_formy]");
										if ($sql->num_rows($soubory)>0){
											while ($soubor=$sql->fetch_array($soubory)){
												?>
												<a href="<?echo $soubor['cesta'];?>" style="margin-left: 5px; margin-right: 5px;"><img src="files/download.png" height="15px" title="<?echo $soubor['nazev_souboru'];?>" /></a>
												<?
											}
										}
									echo "<br />";
								}
								?>	
							</td>
						</tr>
						<tr style="background-color: <?echo $color;?>;">
							<td colspan=6>
								<?
								$prvni=0;
								$vnitrni_operace="";
								$rows_under = $sql->query("SELECT o.nazev_operace_vnitrni, zvo.poznamka
																FROM zak_vyr_operace_vnitrni zvo
															JOIN operace_vnitrni o ON o.id_operace_vnitrni = zvo.id_operace_vnitrni
															WHERE zvo.id_zak_vyrobku=$row[id_zak_vyrobku]
															ORDER BY o.poradi");
								while ($row_under=$sql->fetch_array($rows_under)){
									if ($prvni==1) $vnitrni_operace.=", ";
									$vnitrni_operace.=$row_under['nazev_operace_vnitrni'];
									if (!empty($row_under['poznamka'])) 
										$vnitrni_operace.=" (<i>" . $row_under['poznamka'] . "</i>)";
									$prvni=1;
								}
								if ($prvni==1){
									echo "<b>Vnitřní operace:</b><br />" . $vnitrni_operace;
								}
								?>	
							</td>
						</tr>
						<tr style="background-color: <?echo $color;?>;">
							<td colspan=6>
								<?
								$rows_under = $sql->query("SELECT zvo.id_operace_vnejsi, o.nazev_operace_vnejsi, zvo.poznamka
																FROM zak_vyr_operace_vnejsi zvo
															JOIN operace_vnejsi o ON o.id_operace_vnejsi = zvo.id_operace_vnejsi
															WHERE zvo.id_zak_vyrobku=$row[id_zak_vyrobku]
															ORDER BY o.poradi");
								?>
								<b>Operace subdodavatelů:</b><br />
								<?
								while ($row_under=$sql->fetch_array($rows_under)){
									echo $row_under['nazev_operace_vnejsi'] . " - ";
									?>
									<input type="text" size="40" maxlength="250" name="op_sub_<?echo $row_under['id_operace_vnejsi'];?>" id="op_sub_<?echo $row_under['id_operace_vnejsi'];?>" value="<?echo $row_under['poznamka'];?>"
												onblur="ajax('script/zakazky/aj_ceny.php?id_zak_vyrobku=<?echo $row['id_zak_vyrobku'];?>&id_operace_vnejsi=<?echo $row_under['id_operace_vnejsi'];?>&poznamka='+document.getElementById('<?echo "op_sub_" . $row_under['id_operace_vnejsi'];?>').value,'op_sub_result<?echo $row_under['id_operace_vnejsi'];?>');" />
											<span id="op_sub_result<?echo $row_under['id_operace_vnejsi'];?>" style="width: 16px"></span><br />
									<?
								}
								?>	
							</td>
						</tr>
						<tr style="background-color: <?echo $color;?>;">
							<td colspan=6>
								<b>Materiály:</b>
							</td>
						</tr>
						<tr style="background-color: <?echo $color;?>;">
							<td colspan=6>
								<?
								$rows_under = $sql->query("SELECT id_zak_vyr_material, nazev_materialu, hodnota, zkratka_jednotky 
															FROM zak_vyr_material zvm
															LEFT JOIN merna_jednotka mj ON mj.id_merna_jednotka = zvm.id_merna_jednotka
															WHERE id_zak_vyrobku=$row[id_zak_vyrobku] and smazano=0
															ORDER BY razeni");
								while ($row_under=$sql->fetch_array($rows_under)){
									?>
									<div class="material">
										<?
										echo '<b>' . $row_under['nazev_materialu'] . ' '. $row_under['hodnota'] . ' '. $row_under['zkratka_jednotky'] . '</b><br />';
										$atributy = $sql->query("SELECT nazev_atributu, zkratka_jednotky, hodnota 
																FROM zak_vyr_mat_atributy zvma
																LEFT JOIN merna_jednotka mj ON mj.id_merna_jednotka = zvma.id_merna_jednotka
																WHERE id_zak_vyr_material=$row_under[id_zak_vyr_material] AND zvma.smazano=0
																ORDER BY zvma.razeni");
										while ($atribut=$sql->fetch_array($atributy)){
											echo $atribut['nazev_atributu'] . ' '. $atribut['hodnota'] . ' '. $atribut['zkratka_jednotky'] . '<br />';
										}
										
										?>
									</div>
									<?
								}
								?>	
							</td>
						</tr>
						<?
					}
					?>
				</table>
			</form>
			
			<form action="" method="post" name="vyrobek">				
				<?php
					if (isset($id_zakazky)){
						?>
						<input type="hidden" name="id_zakazky" value="<?echo $id_zakazky;?>" />
						<?
					}
				?>
				<table cellspacing="0" cellpadding="5" border="0" width="50%" align="">
					<tr>
						<td><b>Výrobek</b> (*)</td>
						<td>
							<select name="id_vyrobku" >
								<OPTION value="0">Vyberte možnost...</OPTION>
								<?
								$result=$sql->query("SELECT id_vyrobku, nazev_vyrobku, id_firmy, u.name editoval, datum_editace 
													FROM vyrobky v
													JOIN user u ON u.id_uzivatel = v.editoval
													WHERE id_firmy=$id_firmy and smazano=0");
								while ($row=$sql->fetch_array($result)){
									if ($row['id_vyrobku'] == $id_vyrobku){
										?>
										<OPTION value="<?echo $row['id_vyrobku'];?>" selected="selected"><?echo $row['nazev_vyrobku'];?></OPTION>
										<?
									} else {
										?>
										<OPTION value="<?echo $row['id_vyrobku'];?>"><?echo $row['nazev_vyrobku'];?></OPTION>
										<?
									}
								}
								?>
							</select>
						</td>
					</tr>
				</table>
				<div>
					<input type="submit" name="add_vyrobek" value="Vložit výrobek do zakázky" id="ulozit" />
				</div>
			</form>
			<br />(*) - povinné položky
			<?php
		}
} else echo "<p class=\"chyba\">Na toto nemáte přiřazená práva.</p>";