<?
if (haveRight('ZAKAZKY_EDITACE')){
	if (isset($_GET['id_zak_vyr_material'])){
		global $sql;
		$temp=$sql->query_array("SELECT id_zak_vyr_material, nazev_materialu, id_merna_jednotka FROM zak_vyr_material WHERE id_zak_vyr_material='$_GET[id_zak_vyr_material]'");
		$id_zak_vyr_material = $temp['id_zak_vyr_material'];
		$nazev_materialu = $temp['nazev_materialu'];
		$id_merna_jednotka = $temp['id_merna_jednotka'];
	}
	
	if ($_POST['save']=="Uložit"){
		$error="";
		if (isset($_POST['id_zak_vyr_material']))
			$id_zak_vyr_material = $_POST['id_zak_vyr_material'];
		$nazev_materialu = $_POST['nazev_materialu'];
		$id_merna_jednotka = $_POST['id_merna_jednotka'];

		$error.=(empty($nazev_materialu)) ? "<p class=\"chyba\">Nebyl zadán název materiálu.</p>" : "";
		$error.=($id_merna_jednotka==0) ? "<p class=\"chyba\">Vyberte jednotku.</p>" : "";
	}
	
	if ($error=="" && $_POST['save']=="Uložit"){
		$nazev_materialu=check_input($nazev_materialu);
		$datum_editace = Time();
		$sql->query("UPDATE zak_vyr_material SET nazev_materialu='$nazev_materialu', id_merna_jednotka='$id_merna_jednotka', editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace' WHERE id_zak_vyr_material=$id_zak_vyr_material");
		
		$atributy = $sql->query("SELECT id_zak_vyr_mat_atributu, hodnota, id_merna_jednotka FROM zak_vyr_mat_atributy 
								WHERE id_zak_vyr_material=$_GET[id_zak_vyr_material] AND smazano=0");
		while ($atribut = $sql->fetch_array($atributy)){
			$id_zak_vyr_mat_atributu = $atribut['id_zak_vyr_mat_atributu'];
			$hodnota_atr = $_POST["hodnota_atr_$id_zak_vyr_mat_atributu"];
			$id_merna_jednotka_atr = $_POST["id_merna_jednotka_$id_zak_vyr_mat_atributu"];
			if ($atribut['hodnota']!=$hodnota_atr || $atribut['id_merna_jednotka']!=$id_merna_jednotka_atr){
				$sql->query("UPDATE zak_vyr_mat_atributy SET hodnota='$hodnota_atr', id_merna_jednotka='$id_merna_jednotka_atr', editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace' WHERE id_zak_vyr_mat_atributu=$id_zak_vyr_mat_atributu");
			}
		}
		
		$saved=1;
		echo "<p class=\"oznameni\">Materiál v pořádku uložen.</p>";
		$refresh_page=$page->_head_path . "?show=zak_vyrobek_edit&id_zak_vyrobku=" . $_GET['id_zak_vyrobku'];
		echo "<meta http-equiv=\"refresh\" content=\"1; url=$refresh_page\">";
		message_auto_forward($refresh_page);
	} else if ($error!=""){
		echo "<hr /><b>" . $error . "</b><hr />";
	}
		
		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		if ($_POST['save_atribut']=="Vložit atribut"){
			$error_under="";
			if (isset($_POST['id_zak_vyr_material']))
				$id_zak_vyr_material = $_POST['id_zak_vyr_material'];
			$nazev_atributu = $_POST['nazev_atributu'];
			$hodnota_atributu = $_POST['hodnota_atributu'];
			$id_merna_jednotka_atr = $_POST['id_merna_jednotka_atr'];
			
			$error_under.=(empty($nazev_atributu)) ? "<p class=\"chyba\">Zadejte název atributu.</p>" : "";
		}
		
		if ($error_under=="" && $_POST['save_atribut']=="Vložit atribut"){
			$nazev_atributu=check_input($nazev_atributu);
			$hodnota_atributu=check_input($hodnota_atributu);
			$hodnota_atributu = str_replace(",", ".", $hodnota_atributu);
			$datum_editace = Time();
			
			$temp = $sql->query_array("SELECT max(razeni) razeni FROM zak_vyr_mat_atributy WHERE id_zak_vyr_material='$id_zak_vyr_material'");
			$razeni = $temp['razeni'] + 100;
			
			$sql->query("UPDATE zak_vyr_material SET editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace' WHERE id_zak_vyr_material=$id_zak_vyr_material");
			$sql->query("INSERT INTO zak_vyr_mat_atributy VALUES (NULL, '$id_zak_vyr_material', '$nazev_atributu', '$id_merna_jednotka_atr', '$hodnota_atributu', '$razeni', '$_SESSION[ot_userId]', $datum_editace, '0')");
			
			unset($nazev_atributu);
			unset($id_merna_jednotka_atr);
			unset($razeni);		
			unset($hodnota_atributu);			
		} else if ($error_under!=""){
			echo "<hr /><b>" . $error_under . "</b><hr />";
		}
		
		if (isset($_GET['smaz_id'])){
			$datum_editace = Time();
			$sql->query("UPDATE zak_vyr_mat_atributy SET smazano=1, editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace' WHERE id_zak_vyr_mat_atributu=$_GET[smaz_id]");
		}
		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		
		
		if ($saved==0){
?>
		<form action="" method="post" name="material">
			<div style="text-align: center; padding: 5px; border-bottom: #aaa 1px dashed;">
				<input type="submit" name="save" value="Uložit" id="ulozit" />
				<span style="padding-left: 100px">
					<a href="?show=zak_vyrobek_edit&id_zak_vyrobku=<?echo $_GET['id_zak_vyrobku'];?>" class="zpet">Zpět do editace materiálů v zakázce (bez uložení)</a>
				</span>
			</div>
			
			<?php
				if (isset($id_zak_vyr_material)){
					?>
					<input type="hidden" name="id_zak_vyr_material" value="<?echo $id_zak_vyr_material;?>" />
					<?
				}
			?>
			<table cellspacing="0" cellpadding="5" border="0" width="50%" align="center">
				<tr>
					<td><b>Název materiálu</b> (*)</td>
					<td><input id="nazev_materialu" type="text" size="30" maxlength="100" name="nazev_materialu" value="<?php echo "$nazev_materialu";?>" /></td>
				</tr>
				<tr>
					<td><b>Jednotka</b> (*)</td>
					<td>
						<select name="id_merna_jednotka" >
							<OPTION value="0">Vyberte možnost...</OPTION>
							<?
							$result=$sql->query("SELECT * FROM merna_jednotka");
							while ($row=$sql->fetch_array($result)){
								if ($row['id_merna_jednotka'] == $id_merna_jednotka){
									?>
									<OPTION value="<?echo $row['id_merna_jednotka'];?>" selected="selected"><?echo $row['zkratka_jednotky'];?></OPTION>
									<?
								} else {
									?>
									<OPTION value="<?echo $row['id_merna_jednotka'];?>"><?echo $row['zkratka_jednotky'];?></OPTION>
									<?
								}
							}
							?>
						</select>
					</td>
				</tr>
			</table>
		
		
			<?
			$rows = $sql->query("SELECT id_zak_vyr_mat_atributu, nazev_atributu, zvma.id_merna_jednotka, hodnota, u.name editoval, zvma.datum_editace
									FROM zak_vyr_mat_atributy zvma
								JOIN user u ON u.id_uzivatel= zvma.editoval
								WHERE id_zak_vyr_material=$_GET[id_zak_vyr_material] AND zvma.smazano=0
								ORDER BY zvma.razeni");
			?>
			<table cellspacing="0" cellpadding="5" border="0" width="90%" align="center">
				<tr style="text-align:center; background-color: <?echo $color;?>;">
						<td style="font-weight: bold;">
							Název atributu
						</td>
						<td style="font-weight: bold;">
							Hodnota
						</td>
						<td style="font-weight: bold;">
							Jednotka
						</td>
						<td style="width: 100px;">
							
						</td>
					</tr>
				<?
				$i=0;
				while ($row=$sql->fetch_array($rows)){
					(($i % 2)==0) ? $color="#ddd" : $color="#FFF";
					$i++;
					$datum_editace = StrFTime("%d.%m.%Y %H:%M", $row['datum_editace']);
					$id_zak_vyr_mat_atributu = $row['id_zak_vyr_mat_atributu'];
					
					if (isset($_POST["hodnota_atr_$id_zak_vyr_mat_atributu"])){
						$hodnota_atr = $_POST["hodnota_atr_$id_zak_vyr_mat_atributu"];
					} else {
						$hodnota_atr = $row['hodnota'];
					}
					?>
					<tr style="text-align:center; background-color: <?echo $color;?>;">
						<td>
							<?echo $row['nazev_atributu'];?>
						</td>
						<td>
							<input id="hodnota_atr_<?echo $row['id_zak_vyr_mat_atributu'];?>" type="text" size="5" maxlength="10" name="hodnota_atr_<?echo $row['id_zak_vyr_mat_atributu'];?>"  value="<?echo "$hodnota_atr";?>" />
						</td>
						<td>
							<select name="id_merna_jednotka_<?echo $row['id_zak_vyr_mat_atributu'];?>" >
								<OPTION value="0">Vyberte možnost...</OPTION>
								<?
								$result=$sql->query("SELECT id_merna_jednotka, zkratka_jednotky FROM merna_jednotka
													ORDER BY zkratka_jednotky");
								if (isset($_POST["hodnota_atr_$id_zak_vyr_mat_atributu"])){
									$id_merna_jednotka = $_POST["id_merna_jednotka_$id_zak_vyr_mat_atributu"];
								} else {
									$id_merna_jednotka = $row['id_merna_jednotka'];
								}
								while ($row_under=$sql->fetch_array($result)){
									if ($row_under['id_merna_jednotka'] == $id_merna_jednotka){
										?>
										<OPTION value="<?echo $row_under['id_merna_jednotka'];?>" selected="selected"><?echo $row_under['zkratka_jednotky'];?></OPTION>
										<?
									} else {
										?>
										<OPTION value="<?echo $row_under['id_merna_jednotka'];?>"><?echo $row_under['zkratka_jednotky'];?></OPTION>
										<?
									}
								}
								?>
							</select>
						</td>
						<td style="width: 100px;">
							<span style="cursor: pointer;" id="odkaz_smazat_<?echo $row['id_zak_vyr_mat_atributu'];?>"	onClick="ukaz_form_smazat(<?echo $row['id_zak_vyr_mat_atributu'];?>)"
							title="Naposledy editoval(a) <?echo $row['editoval'] . ' ' . $datum_editace;?>">
								<img src="files/smazat.png" height="16px" />
							</span>
							<br />
							<span id="smazat_<?echo $row['id_zak_vyr_mat_atributu'];?>" style="display: none;">
								<a href="?show=zak_material_edit&id_zak_vyrobku=<?echo $_GET['id_zak_vyrobku'];?>&id_zak_vyr_material=<?echo $id_zak_vyr_material;?>&smaz_id=<?echo $row['id_zak_vyr_mat_atributu'];?>">Ano</a>
								<a style="margin-left: 20px;" href="javascript:void(0)" onclick="skryj_form_smazat(<?echo $row['id_zak_vyr_mat_atributu'];?>)">Ne</a>
							</span>
						</td>
					</tr>
					<?
				}
				?>
			</table>
		</form>
		
			<form action="" method="post" name="vyrobek_material_atribut">
				<?
					if (isset($id_zak_vyr_material)){
						?>
						<input type="hidden" name="id_zak_vyr_material" value="<?echo $id_zak_vyr_material;?>" />
						<?
					}
				?>
				<div style="text-align: left; margin-top: 20px; padding: 5px; border-bottom: #aaa 1px dashed;border-top: #aaa 1px dashed;">
					<table cellspacing="0" cellpadding="5" border="0" width="50%">
						<tr>
							<td><b>Název atributu</b></td>
							<td><input id="nazev_atributu" type="text" size="30" maxlength="100" name="nazev_atributu" value="<? echo "$nazev_atributu";?>" /></td>
						</tr>
						<tr>
							<td><b>Hodnota atributu</b></td>
							<td><input id="hodnota_atributu" type="text" size="5" maxlength="10" name="hodnota_atributu" value="<? echo "$hodnota_atributu";?>" /></td>
						</tr>
						<tr>
							<td><b>Jednotka</b></td>
							<td>
								<select name="id_merna_jednotka_atr" >
									<OPTION value="0">Vyberte možnost...</OPTION>
									<?
									$result=$sql->query("SELECT id_merna_jednotka, zkratka_jednotky FROM merna_jednotka
														ORDER BY zkratka_jednotky");
									while ($row=$sql->fetch_array($result)){
										if ($row['id_merna_jednotka'] == $id_merna_jednotka_atr){
											?>
											<OPTION value="<?echo $row['id_merna_jednotka'];?>" selected="selected"><?echo $row['zkratka_jednotky'];?></OPTION>
											<?
										} else {
											?>
											<OPTION value="<?echo $row['id_merna_jednotka'];?>"><?echo $row['zkratka_jednotky'];?></OPTION>
											<?
										}
									}
									?>
								</select>
							</td>
						</tr>
						<tr>
							<td colspan=2>
								<input type="submit" name="save_atribut" value="Vložit atribut" id="ulozit" />
							</td>
						</tr>
					</table>
				</div>
			</form>
		<script type="text/javascript"> document.getElementById("nazev_materialu").focus(); </script>
		(*) - povinné položky
		<?php
		}
} else echo "<p class=\"chyba\">Na toto nemáte přiřazená práva.</p>";
