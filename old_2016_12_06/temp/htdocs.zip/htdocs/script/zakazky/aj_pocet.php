<?
	require_once '../../classes/class_mysql.php';
		$sql=new mysql;

	require_once '../../classes/class_user.php';
		$user=new classUser;
	
	require_once "../../includes/common.php";

	if (isset($_GET['id_zak_vyrobku']) && haveRight('ZAKAZKY_EDITACE')){
		$datum_editace = Time();
		$pocet_temp = str_replace(",", ".", $_GET['pocet']);
			$id_stavu = $sql->query_array("SELECT id_stavu FROM zakazky WHERE id_zakazky IN (SELECT id_zakazky FROM zak_vyrobky WHERE id_zak_vyrobku=$_GET[id_zak_vyrobku])");
			$id_stavu = $id_stavu['id_stavu'];
			if ($pocet_temp>0 || ($pocet_temp==0 && $id_stavu==100)){
				$sql->query("UPDATE zak_vyrobky SET pocet='$pocet_temp', editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace' WHERE id_zak_vyrobku=$_GET[id_zak_vyrobku]");
				?>
				<img src="../../files/ok.png" height="13px" />
				<?
			} else {
				?>
				<img src="../../files/ko.png" height="13px" />
				<?
			}
	}
?>