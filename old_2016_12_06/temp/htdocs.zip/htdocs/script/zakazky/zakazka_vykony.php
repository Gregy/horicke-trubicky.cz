<?
if (haveRight('ZAKAZKY')){
	if (isset($_GET['id_zakazky'])){
		global $sql;
		$temp=$sql->query_array("SELECT  z.id_zakazky, z.cislo_zakazky, z.rok, z.id_firmy, z.datum_zadani, z.termin_dokonceni, z.datum_editace, u.name editoval, z.id_stavu, z.poznamka, 
									z.nazev_firmy, z.ulice, z.mesto, z.psc, z.stat, z.telefon, z.email, z.ic, z.dic, z.bank_uc_pred, z.bank_uc_za, z.spec_symb, s.nazev_stavu
								FROM zakazky z
								JOIN stavy s ON z.id_stavu = s.id_stavu
								JOIN user u ON u.id_uzivatel = z.editoval
								WHERE id_zakazky = '$_GET[id_zakazky]'");
		$id_zakazky = $temp['id_zakazky'];
		$cislo_zakazky = $temp['cislo_zakazky'];
		$rok = $temp['rok'];
		$id_firmy = $temp['id_firmy'];
		$datum_zadani = StrFTime("%d.%m.%Y %H:%M", $temp['datum_zadani']);
		$termin_dokonceni = StrFTime("%d.%m.%Y", $temp['termin_dokonceni']);
		$datum_editace = StrFTime("%d.%m.%Y %H:%M", $temp['datum_editace']);
		$editoval = $temp['editoval'];
		$id_stavu = $temp['id_stavu'];
		$poznamka = $temp['poznamka'];
		$nazev_firmy = $temp['nazev_firmy'];
		$ulice = $temp['ulice'];
		$mesto = $temp['mesto'];
		$psc = $temp['psc'];
		$stat = $temp['stat'];
		$telefon = $temp['telefon'];
		$email = $temp['email'];
		$ic = $temp['ic'];
		$dic = $temp['dic'];
		$bank_uc_pred = $temp['bank_uc_pred'];
		$bank_uc_za = $temp['bank_uc_za'];
		$spec_symb = $temp['spec_symb'];
		$nazev_stavu = $temp['nazev_stavu'];
	}
	if (!is_print_mod()){
		?>
		<div style="text-align: center; padding: 5px; border-bottom: #aaa 1px dashed;">
			<span style="padding-left: 100px">
				<a href="?show=zakazky" class="zpet">Zpět na seznam zakázek</a>
			</span>
			<span style="margin-left: 50px;">
				<?
				if (haveRight("ZAKAZKY")){
					?>
					<a style="text-decoration: none;" href="?show=zakazka_show&id_zakazky=<?echo $id_zakazky;?>"><img src="files/show.png" title="Náhled na zakázku" height="18px" /></a>
					<?
				}
				?>
			</span>
			<span style="margin-left: 50px;">
				<?
				if (haveRight("ZAKAZKY_EDITACE")){
					?>
					<a style="text-decoration: none;" href="?show=zakazka_edit&id_zakazky=<?echo $id_zakazky;?>"><img src="files/edit.png" title="Editace zakázky" height="18px" /></a>
					<?
				}
				?>
			</span>
			<span style="margin-left: 50px;">
				<?
				if (haveRight("ZAKAZKY_EXPEDICE")){
					?>
					<a style="text-decoration: none;" href="?show=zakazka_expedice&id_zakazky=<?echo $id_zakazky;?>"><img src="files/expedice.png" title="Expedice zakázky" height="18px" /></a>
					<?
				}
				?>
			</span>
		</div>
		<?
	}
	?>
	<div style="text-align: center; padding: 5px;">
		<table cellspacing="0" cellpadding="1" border="0" width="100%" align="center">
			<tr>
				<td>Název firmy</td>
				<td>Číslo zakázky</td>
				<td>Termín dokončení</td>
				<td>Stav zakázky</td>
			</tr>
			<tr>
				<td style="vertical-align: top;">
					<b><?php echo $nazev_firmy;?></b>
				</td>
				<td style="vertical-align: top; width: 150px;">
					<b><?php echo cislo_rok($cislo_zakazky, $rok);?></b>
				</td>
				<td style="vertical-align: top; width: 150px;">
					<span style="font-weight: bold;"><?php echo $termin_dokonceni;?></span>
				</td>
				<td style="vertical-align: top; width: 150px;">
					<span style="font-weight: bold;"><?php echo $nazev_stavu;?></span>
				</td>
			</tr>
		</table>
	</div>
	<?
	$rows = $sql->query("SELECT zv.id_zak_vyrobku, zv.nazev_vyrobku, zv.pocet, zv.datum_editace, u.name editoval,
							zv.nazev_baleni, zv.nazev_lakovani, zv.barevnost, zv.konstrukce_obalu
						FROM zak_vyrobky zv
						JOIN user u ON u.id_uzivatel = zv.editoval
						WHERE id_zakazky=$id_zakazky and smazano=0");
	?>
	<table cellspacing="0" cellpadding="5" border="0" width="99%" align="center">
		<?
		$i=0;
		while ($row=$sql->fetch_array($rows)){
			(($i % 2)==0) ? $color="#CFC" : $color="#FFC";
			$i++;
			$datum_editace = StrFTime("%d.%m.%Y %H:%M", $row['datum_editace']);
			?>
			<tr style="text-align:center; background-color: <?echo $color;?>;">
				<td style="border-top: 1px dotted;">
					<b>Výrobek</b><br />
					<span style="font-size: 14px; font-weight: bold; color: #00F;">
						<? 
						echo $row['nazev_vyrobku'];
						?>
					</span>
				</td>
				<td style="border-top: 1px dotted;">
					<b>Počet ks</b><br />
					<?
					if (!empty($_POST["pocet_$row[id_zak_vyrobku]"])){
						$pocet=$_POST["pocet_$row[id_zak_vyrobku]"];
					} else {
						$pocet=$row['pocet'];
					}
					echo $pocet;
					?>
				</td>
				<td style="border-top: 1px dotted;"></td>
				<td style="border-top: 1px dotted;"></td>
			</tr>
			<tr style="background-color: <?echo $color;?>;">
				<td colspan=4>
					<?
					$rows_under = $sql->query("SELECT o.nazev_operace_vnitrni, zvo.poznamka, o.pocet_radku
													FROM zak_vyr_operace_vnitrni zvo
												JOIN operace_vnitrni o ON o.id_operace_vnitrni = zvo.id_operace_vnitrni
												WHERE zvo.id_zak_vyrobku=$row[id_zak_vyrobku]
												ORDER BY o.poradi");
					
					if ($sql->num_rows($rows_under)>0){
						while ($row_under=$sql->fetch_array($rows_under)){
							if ($row_under['pocet_radku']){
								?>
								<table cellspacing="0" cellpadding="5" border="1" width="99%" align="center" style="margin-bottom: 20px;">
									<tr>
										<td style="font-weight: bold; vertical-align: top;" rowspan="<?echo $row_under['pocet_radku']+2;?>">
											<?
											echo $row_under['nazev_operace_vnitrni'];
											?>
										</td>
										<td style="width: 100px;">Datum</td>
										<td style="width: 150px;">Pracovník</td>
										<td style="width: 80px;">archy</td>
										<td style="width: 80px;">ks</td>
										<td style="width: 120px;">konečný stav počítadla</td>
									</tr>
									<?
									for ($i=0; $i<$row_under['pocet_radku']; $i++){
										?>							
										<tr style="font-weight: bold; height: 25px;">
											<td></td>
											<td></td>
											<td></td>
											<td></td>
											<td></td>
										</tr>
										<?
									}
									?>
									<tr style="font-weight: bold; height: 18px;">
										<td></td>
										<td>Celkem</td>
										<td></td>
										<td></td>
										<td></td>
									</tr>
								</table>
								<?
							}
						}
					}
					?>
				</td>
			</tr>
			<?
		}
		?>
	</table>
	<?php
} else echo "<p class=\"chyba\">Na toto nemáte přiřazená práva.</p>";
?>