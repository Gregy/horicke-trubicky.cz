<?
if (haveRight('ZAKAZKY_SOUBORY')){
	if (isset($_GET['id_zakazky'])){
		$id_zakazky = $_GET['id_zakazky'];
	}
	
	if (isset($_GET['id_zak_souboru'])){
		global $sql;
		$temp=$sql->query_array("SELECT id_zak_souboru, id_zakazky, nazev_souboru, cesta FROM zak_soubory WHERE id_zak_souboru='$_GET[id_zak_souboru]'");
		$id_zak_souboru = $temp['id_zak_souboru'];
		$id_zakazky = $temp['id_zakazky'];
		$nazev_souboru = $temp['nazev_souboru'];
		$cesta = $temp['cesta'];
	}
	
	if ($_POST['save']=="Uložit"){
		$error="";
		if (isset($_POST['id_zak_souboru']))
			$id_zak_souboru = $_POST['id_zak_souboru'];
		$nazev_souboru = $_POST['nazev_souboru'];
		$cesta = $_FILES["cesta"]["name"];
		
		$error.=(empty($nazev_souboru)) ? "<p class=\"chyba\">Nebyl zadán název souboru.</p>" : "";
		
		if (!isset($id_zak_souboru)){
			$error.=(empty($_FILES["cesta"]["name"])) ? "<p class=\"chyba\">Nebyla zadána cesta k souboru.</p>" : "";
		}
	}
	
	if ($error=="" && $_POST['save']=="Uložit"){
		$nazev_souboru=check_input($nazev_souboru);
		$datum_editace = Time();
	
		if (isset($id_zak_souboru)){
			$sql->query("UPDATE zak_soubory SET nazev_souboru='$nazev_souboru', editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace' WHERE id_zak_souboru=$id_zak_souboru");
		} else {
			$temp = $sql->query_array("SELECT max(poradi) max_poradi FROM operace_vnejsi");
			$max_poradi = $temp['max_poradi']+100;
			$sql->query("INSERT INTO zak_soubory VALUES (NULL, '$id_zakazky', '$nazev_souboru', '', '$_SESSION[ot_userId]', '$datum_editace', '0')");
			$id_zak_souboru = $sql->insert_id();
			
			$target_dir = "upload/zakazky/";
			$imageFileType = pathinfo($_FILES["cesta"]["name"],PATHINFO_EXTENSION);
			$target_file = $target_dir . "soubor_" . $id_zak_souboru . "." . $imageFileType;

			move_uploaded_file($_FILES["cesta"]["tmp_name"], $target_file);
			
			$sql->query("UPDATE zak_soubory SET cesta='$target_file' WHERE id_zak_souboru=$id_zak_souboru");
		}
		
		
		
		$saved=1;
		echo "<p class=\"oznameni\">Soubor v pořádku uložen.</p>";
		$refresh_page=$page->_head_path . "?show=zakazka_soubory&id_zakazky=$id_zakazky";
		echo "<meta http-equiv=\"refresh\" content=\"1; url=$refresh_page\">";
		message_auto_forward($refresh_page);
	} else if ($error!=""){
		echo "<hr /><b>" . $error . "</b><hr />";
	}
	if ($saved==0){
		?>
		<form action="" method="post" enctype="multipart/form-data">
			<div style="text-align: center; padding: 5px; border-bottom: #aaa 1px dashed;">
				<input type="submit" name="save" value="Uložit" id="ulozit" />
				<span style="padding-left: 100px">
					<a href="?show=zakazka_soubory&id_zakazky=<? echo $id_zakazky;?>" class="zpet">Zpět na seznam souborů (bez uložení)</a>
				</span>
			</div>
			
			<?
				if (isset($id_zak_souboru)){
					?>
					<input type="hidden" name="id_zak_souboru" value="<?echo $id_zak_souboru;?>" />
					<?
				}
			?>
			<table cellspacing="0" cellpadding="5" border="0" width="50%" align="center">
				<tr>
					<td><b>Název souboru</b> (*)</td>
					<td><input id="nazev_souboru" type="text" size="30" maxlength="100" name="nazev_souboru" value="<? echo $nazev_souboru;?>" /></td>
				</tr>
				<?
				if (!isset($id_zak_souboru)){
					?>
					<tr>
						<td><b>Vyberte soubor</b> (*)</td>
						<td><input id="cesta" name="cesta" type="file" /></td>
					</tr>
					<?
				}
				?>
			</table>
			<br />(*) - povinné položky
		</form>
		<script type="text/javascript"> document.getElementById("nazev_souboru").focus(); </script>
		<?
	}
} else echo "<p class=\"chyba\">Na toto nemáte přiřazená práva.</p>";
?>