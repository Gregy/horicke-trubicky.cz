<?
if (haveRight('ZAKAZKY_EDITACE')){
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//vlozeni vysekove formy
	if (isset($_POST['save_vf'])){
		$error_under2="";
		if ($_POST['id_vysekove_formy']!=0)
			$id_vysekove_formy = $_POST['id_vysekove_formy'];
		else 
			$error_under2.="<p class=\"chyba\">Vyberte výsekovou formu.</p>";
	}
	
	if ($error_under2=="" && isset($_POST['save_vf'])){
		$datum_editace = Time();
		
		$sql->query("INSERT INTO zak_vyr_vysekove_formy
					SELECT  NULL, $id_zak_vyrobku, cislo_vysekove_formy, nazev_vysekove_formy, ks_na_arch, min_rozmer_sirka, min_rozmer_delka, rozmer_obalu_sirka, rozmer_obalu_delka, rozmer_obalu_vyska, poznamka 
					FROM vysekove_formy  
					WHERE id_vysekove_formy=$id_vysekove_formy");
		$nove_id_zak_vyr_vysekove_formy = $sql->insert_id();
		$sql->query("INSERT INTO zak_vys_for_soubory
						SELECT NULL, $nove_id_zak_vyr_vysekove_formy, nazev_souboru, cesta
						FROM vys_for_soubory
						WHERE id_vysekove_formy=$id_vysekove_formy AND smazano=0");
	} else if ($error_under2!=""){
		echo "<hr /><b>" . $error_under2 . "</b><hr />";
	}
	
	if (isset($_GET['smaz_id_vf'])){
		$datum_editace = Time();
		$sql->query("DELETE FROM zak_vyr_vysekove_formy WHERE id_zak_vyr_vysekove_formy=$_GET[smaz_id_vf]");
		$sql->query("DELETE FROM zak_vys_for_soubory WHERE id_zak_vyr_vysekove_formy=$_GET[smaz_id_vf]");
	}
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	if (isset($_GET['id_zak_vyrobku'])){
		global $sql;
		$temp=$sql->query_array("SELECT id_zak_vyrobku, nazev_vyrobku, nazev_baleni, id_zakazky, 
									nazev_lakovani, barevnost, konstrukce_obalu
								FROM zak_vyrobky
								WHERE id_zak_vyrobku='$_GET[id_zak_vyrobku]'");
		$id_zak_vyrobku = $temp['id_zak_vyrobku'];
		$nazev_vyrobku = $temp['nazev_vyrobku'];
		$nazev_baleni = $temp['nazev_baleni'];
		$id_zakazky = $temp['id_zakazky'];
		$nazev_lakovani = $temp['nazev_lakovani'];
		$barevnost = $temp['barevnost'];
		$konstrukce_obalu = $temp['konstrukce_obalu'];
		
		$vysekove_formy = $sql->query("SELECT id_zak_vyr_vysekove_formy, cislo_vysekove_formy, nazev_vysekove_formy, ks_na_arch, min_rozmer_sirka, min_rozmer_delka, 
											rozmer_obalu_sirka, rozmer_obalu_delka, rozmer_obalu_vyska, vf_poznamka
										FROM zak_vyr_vysekove_formy
										WHERE id_zak_vyrobku=$id_zak_vyrobku");
		if ($sql->num_rows($vysekove_formy)){
			while ($vf=$sql->fetch_array($vysekove_formy)){
				$h_cislo_vysekove_formy[$vf['id_zak_vyr_vysekove_formy']] = $vf['cislo_vysekove_formy'];
				$h_nazev_vysekove_formy[$vf['id_zak_vyr_vysekove_formy']] = $vf['nazev_vysekove_formy'];
				$h_ks_na_arch[$vf['id_zak_vyr_vysekove_formy']] = $vf['ks_na_arch'];
				$h_min_rozmer_sirka[$vf['id_zak_vyr_vysekove_formy']] = $vf['min_rozmer_sirka'];
				$h_min_rozmer_delka[$vf['id_zak_vyr_vysekove_formy']] = $vf['min_rozmer_delka'];
				$h_rozmer_obalu_sirka[$vf['id_zak_vyr_vysekove_formy']] = $vf['rozmer_obalu_sirka'];
				$h_rozmer_obalu_delka[$vf['id_zak_vyr_vysekove_formy']] = $vf['rozmer_obalu_delka'];
				$h_rozmer_obalu_vyska[$vf['id_zak_vyr_vysekove_formy']] = $vf['rozmer_obalu_vyska'];
				$h_vf_poznamka[$vf['id_zak_vyr_vysekove_formy']] = $vf['vf_poznamka'];
			}
		}
		
		$operace_vnitrni = $sql->query("SELECT vo.id_operace_vnitrni, o.nazev_operace_vnitrni, vo.poznamka
											FROM zak_vyr_operace_vnitrni vo
										JOIN operace_vnitrni o ON vo.id_operace_vnitrni = o.id_operace_vnitrni
										WHERE o.smazano=0 and id_zak_vyrobku=$id_zak_vyrobku
										ORDER BY poradi");
		$i = 0;
		while ($operace=$sql->fetch_array($operace_vnitrni)){
			$oznacene_operace_vnitrni[$i] = array (
				'id_operace_vnitrni' => $operace['id_operace_vnitrni'],
				'nazev_operace_vnitrni' => $operace['nazev_operace_vnitrni'],
				'poznamka' => $operace['poznamka']
			);
			$i++;
		}
		
		$operace_vnejsi = $sql->query("SELECT vo.id_operace_vnejsi, o.nazev_operace_vnejsi, vo.poznamka
											FROM zak_vyr_operace_vnejsi vo
										JOIN operace_vnejsi o ON vo.id_operace_vnejsi = o.id_operace_vnejsi
										WHERE o.smazano=0 and id_zak_vyrobku=$id_zak_vyrobku
										ORDER BY poradi");
		$i = 0;
		while ($operace=$sql->fetch_array($operace_vnejsi)){
			$oznacene_operace_vnejsi[$i] = array (
				'id_operace_vnejsi' => $operace['id_operace_vnejsi'],
				'nazev_operace_vnejsi' => $operace['nazev_operace_vnejsi'],
				'poznamka' => $operace['poznamka']
			);
			$i++;
		}
	}
	
	if ($_POST['save']=="Uložit"){
		$error="";
		if (isset($_POST['id_zak_vyrobku']))
			$id_zak_vyrobku = $_POST['id_zak_vyrobku'];
		$nazev_vyrobku = $_POST['nazev_vyrobku'];
		$nazev_baleni = $_POST['nazev_baleni'];
		$nazev_lakovani = $_POST['nazev_lakovani'];
		$barevnost = $_POST['barevnost'];
		$konstrukce_obalu = $_POST['konstrukce_obalu'];
		
		$vysekove_formy = $sql->query("SELECT id_zak_vyr_vysekove_formy, cislo_vysekove_formy, nazev_vysekove_formy, ks_na_arch, min_rozmer_sirka, min_rozmer_delka, 
											rozmer_obalu_sirka, rozmer_obalu_delka, rozmer_obalu_vyska, vf_poznamka
										FROM zak_vyr_vysekove_formy
										WHERE id_zak_vyrobku=$id_zak_vyrobku");
		if ($sql->num_rows($vysekove_formy)){
			while ($vf=$sql->fetch_array($vysekove_formy)){
				$h_cislo_vysekove_formy[$vf['id_zak_vyr_vysekove_formy']] = $_POST["cislo_vysekove_formy$vf[id_zak_vyr_vysekove_formy]"];
				$h_nazev_vysekove_formy[$vf['id_zak_vyr_vysekove_formy']] = $_POST["nazev_vysekove_formy$vf[id_zak_vyr_vysekove_formy]"];
				$h_ks_na_arch[$vf['id_zak_vyr_vysekove_formy']] = $_POST["ks_na_arch$vf[id_zak_vyr_vysekove_formy]"];
				$h_min_rozmer_sirka[$vf['id_zak_vyr_vysekove_formy']] = $_POST["min_rozmer_sirka$vf[id_zak_vyr_vysekove_formy]"];
				$h_min_rozmer_delka[$vf['id_zak_vyr_vysekove_formy']] = $_POST["min_rozmer_delka$vf[id_zak_vyr_vysekove_formy]"];
				$h_rozmer_obalu_sirka[$vf['id_zak_vyr_vysekove_formy']] = $_POST["rozmer_obalu_sirka$vf[id_zak_vyr_vysekove_formy]"];
				$h_rozmer_obalu_delka[$vf['id_zak_vyr_vysekove_formy']] = $_POST["rozmer_obalu_delka$vf[id_zak_vyr_vysekove_formy]"];
				$h_rozmer_obalu_vyska[$vf['id_zak_vyr_vysekove_formy']] = $_POST["rozmer_obalu_vyska$vf[id_zak_vyr_vysekove_formy]"];
				$h_vf_poznamka[$vf['id_zak_vyr_vysekove_formy']] = $_POST["vf_poznamka$vf[id_zak_vyr_vysekove_formy]"];
			}
		}
		
		$operace_vnitrni = $sql->query("SELECT id_operace_vnitrni, nazev_operace_vnitrni
											FROM operace_vnitrni
										WHERE smazano=0
										ORDER BY poradi");
		unset($oznacene_operace_vnitrni);
		$i = 0;
		while ($operace=$sql->fetch_array($operace_vnitrni)){
			if (isset($_POST["o_c_operace_vnitrni_$operace[id_operace_vnitrni]"])){
				$oznacene_operace_vnitrni[$i] = array (
					'id_operace_vnitrni' => $operace['id_operace_vnitrni'],
					'nazev_operace_vnitrni' => $operace['nazev_operace_vnitrni'],
					'poznamka' => $_POST["o_t_operace_vnitrni_$operace[id_operace_vnitrni]"]
				);
				$i++;
			}
		}
		
		$operace_vnejsi = $sql->query("SELECT id_operace_vnejsi, nazev_operace_vnejsi
											FROM operace_vnejsi
										WHERE smazano=0
										ORDER BY poradi");
		unset($oznacene_operace_vnejsi);
		$i = 0;
		while ($operace=$sql->fetch_array($operace_vnejsi)){
			if (isset($_POST["o_c_operace_vnejsi_$operace[id_operace_vnejsi]"])){
				$oznacene_operace_vnejsi[$i] = array (
					'id_operace_vnejsi' => $operace['id_operace_vnejsi'],
					'nazev_operace_vnejsi' => $operace['nazev_operace_vnejsi'],
					'poznamka' => $_POST["o_t_operace_vnejsi_$operace[id_operace_vnejsi]"]
				);
				$i++;
			}
		}
		
		$error.=(empty($nazev_vyrobku)) ? "<p class=\"chyba\">Nebyl zadán název výrobku.</p>" : "";
		$error.=(empty($nazev_baleni)) ? "<p class=\"chyba\">Nebyla zadán název balení.</p>" : "";
	}
	
	if ($error=="" && $_POST['save']=="Uložit"){
		$nazev_vyrobku=check_input($nazev_vyrobku);
		$datum_editace = Time();
		
		$vysekove_formy = $sql->query("SELECT id_zak_vyr_vysekove_formy, cislo_vysekove_formy, nazev_vysekove_formy, ks_na_arch, min_rozmer_sirka, min_rozmer_delka, 
											rozmer_obalu_sirka, rozmer_obalu_delka, rozmer_obalu_vyska, vf_poznamka
										FROM zak_vyr_vysekove_formy
										WHERE id_zak_vyrobku=$id_zak_vyrobku");
		if ($sql->num_rows($vysekove_formy)){
			while ($vf=$sql->fetch_array($vysekove_formy)){
				$id_zak_vyr_vysekove_formy = $vf['id_zak_vyr_vysekove_formy'];
				$sql->query("UPDATE zak_vyr_vysekove_formy SET cislo_vysekove_formy='$h_cislo_vysekove_formy[$id_zak_vyr_vysekove_formy]', 
																nazev_vysekove_formy='$h_nazev_vysekove_formy[$id_zak_vyr_vysekove_formy]', 
																ks_na_arch='$h_ks_na_arch[$id_zak_vyr_vysekove_formy]', 
																min_rozmer_sirka='$h_min_rozmer_sirka[$id_zak_vyr_vysekove_formy]', 
																min_rozmer_delka='$h_min_rozmer_delka[$id_zak_vyr_vysekove_formy]',
																rozmer_obalu_sirka='$h_rozmer_obalu_sirka[$id_zak_vyr_vysekove_formy]', 
																rozmer_obalu_delka='$h_rozmer_obalu_delka[$id_zak_vyr_vysekove_formy]', 
																rozmer_obalu_vyska='$h_rozmer_obalu_vyska[$id_zak_vyr_vysekove_formy]', 
																vf_poznamka='$h_vf_poznamka[$id_zak_vyr_vysekove_formy]'
							WHERE id_zak_vyr_vysekove_formy=$id_zak_vyr_vysekove_formy");
			}
		}
		
		$rows = $sql->query("SELECT id_zak_vyr_material
								FROM zak_vyr_material zvm
								WHERE id_zak_vyrobku=$id_zak_vyrobku and smazano=0");
		while ($row = $sql->fetch_array($rows)){
			$pocet = $_POST["pocet_$row[id_zak_vyr_material]"];
			$pocet = str_replace(",", ".", $pocet);
			$sql->query("UPDATE zak_vyr_material SET hodnota='$pocet', editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace' WHERE id_zak_vyr_material=$row[id_zak_vyr_material]");
		}
		
		$sql->query("UPDATE zak_vyrobky 
					SET nazev_vyrobku='$nazev_vyrobku', nazev_baleni='$nazev_baleni', nazev_lakovani='$nazev_lakovani', barevnost='$barevnost', konstrukce_obalu='$konstrukce_obalu', 
						editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace'
					WHERE id_zak_vyrobku=$id_zak_vyrobku");
	
		$sql->query("DELETE FROM zak_vyr_operace_vnitrni WHERE id_zak_vyrobku=$id_zak_vyrobku");
		if (isset($oznacene_operace_vnitrni)){
			foreach($oznacene_operace_vnitrni as $oz_pol){
				$sql->query("INSERT INTO zak_vyr_operace_vnitrni VALUES ('$id_zak_vyrobku', '$oz_pol[id_operace_vnitrni]', '$oz_pol[poznamka]')");
			}
		}
		
		$sql->query("DELETE FROM zak_vyr_operace_vnejsi WHERE id_zak_vyrobku=$id_zak_vyrobku");
		if (isset($oznacene_operace_vnejsi)){
			foreach($oznacene_operace_vnejsi as $oz_pol){
				$sql->query("INSERT INTO zak_vyr_operace_vnejsi VALUES ('$id_zak_vyrobku', '$oz_pol[id_operace_vnejsi]', '$oz_pol[poznamka]')");
			}
		}
		
		$saved=1;
		echo "<p class=\"oznameni\">Výrobek v pořádku uložen.</p>";
		$refresh_page=$page->_head_path . "?show=zakazka_edit&id_zakazky=$id_zakazky";

		echo "<meta http-equiv=\"refresh\" content=\"1; url=$refresh_page\">";
		message_auto_forward($refresh_page);
	} else if ($error!=""){
		echo "<hr /><b>" . $error . "</b><hr />";
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//vlozeni noveho materialu
	if (isset($_POST['save_material'])){
		$error_under="";
		if (isset($_POST['id_zak_vyrobku']))
			$id_zak_vyrobku = $_POST['id_zak_vyrobku'];
		$id_materialu = $_POST['id_materialu'];
		$hodnota = $_POST['hodnota'];
		$hodnota = str_replace(",", ".", $hodnota);
		
		$atributy = $sql->query("SELECT a.id_atributu, a.nazev_atributu FROM atributy a
								WHERE a.id_materialu=$id_materialu and a.smazano=0");
		if ($sql->num_rows($atributy)){
			while ($atribut=$sql->fetch_array($atributy)){
				$hodnoty_atributu[$atribut['id_atributu']] = $_POST["atribut$atribut[id_atributu]"];
			}
		}
		
		$error_under.=($id_materialu==0) ? "<p class=\"chyba\">Vyberte materiál.</p>" : "";
	}
	
	if ($error_under=="" && isset($_POST['save_material'])){
		$datum_editace = Time();
		
		$temp = $sql->query_array("SELECT max(razeni) razeni FROM zak_vyr_material WHERE id_zak_vyrobku='$id_zak_vyrobku'");
		$razeni = $temp['razeni'] + 100;
		
		$sql->query("UPDATE zak_vyrobky SET editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace' WHERE id_zak_vyrobku=$id_zak_vyrobku");
		$sql->query("INSERT INTO zak_vyr_material
						SELECT NULL, '$id_zak_vyrobku', nazev_materialu, '$hodnota', id_merna_jednotka,  $razeni, '$_SESSION[ot_userId]', $datum_editace, 0
						FROM materialy 
						WHERE id_materialu=$id_materialu");
		$id_zak_vyr_material = $sql->insert_id();
		
		$atributy = $sql->query("SELECT a.id_atributu, a.nazev_atributu, a.id_merna_jednotka, a.razeni FROM atributy a
								WHERE a.id_materialu=$id_materialu and a.smazano=0");
		if ($sql->num_rows($atributy)){
			while ($atribut=$sql->fetch_array($atributy)){
				$hodnota_temp = $hodnoty_atributu[$atribut['id_atributu']];
				$sql->query("INSERT INTO zak_vyr_mat_atributy VALUES (NULL, '$id_zak_vyr_material', '$atribut[nazev_atributu]',  '$atribut[id_merna_jednotka]', '$hodnota_temp', '$atribut[razeni]', '$_SESSION[ot_userId]', $datum_editace, 0)");
			}
		}
		
		unset($atributy);
		unset($hodnoty_atributu);
		unset($id_materialu);
	} else if ($error_under!=""){
		echo "<hr /><b>" . $error_under . "</b><hr />";
	}
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	if (isset($_GET['smaz_id'])){
		$datum_editace = Time();
		$sql->query("UPDATE zak_vyr_material SET smazano=1, editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace' WHERE id_zak_vyr_material=$_GET[smaz_id]");
	}
	
		
	if ($saved==0){
?>
		<form action="" method="post" name="vyrobky">
			<div style="text-align: center; padding: 5px; border-bottom: #aaa 1px dashed;">
				<input type="submit" name="save" value="Uložit" id="ulozit" />
				<span style="padding-left: 100px">
					<a href="?show=zakazka_edit&id_zakazky=<?echo $id_zakazky;?>" class="zpet">Zpět do zakázky (bez uložení)</a>
				</span>
			</div>
			
			<?php
				if (isset($id_zak_vyrobku)){
					?>
					<input type="hidden" name="id_zak_vyrobku" value="<?echo $id_zak_vyrobku;?>" />
					<?
				}
			?>
			<table cellspacing="0" cellpadding="5" border="0" width="95%" align="center">
				<tr>
					<td><b>Název výrobku</b> (*)</td>
					<td colspan=3><input id="nazev_vyrobku" type="text" size="30" maxlength="100" name="nazev_vyrobku" value="<?php echo "$nazev_vyrobku";?>" /></td>
				</tr>
				<tr>
					<td><b>Balení</b> (*)</td>
					<td><input id="nazev_baleni" type="text" size="30" maxlength="100" name="nazev_baleni" value="<?php echo "$nazev_baleni";?>" /></td>
					<td><b>Lakování</b></td>
					<td><input id="nazev_lakovani" type="text" size="30" maxlength="100" name="nazev_lakovani" value="<?php echo "$nazev_lakovani";?>" /></select>
					</td>
				</tr>
				<tr>
					<td><b>Konstrukce obalu</b></td>
					<td><input id="konstrukce_obalu" type="text" size="30" maxlength="50" name="konstrukce_obalu" value="<?php echo "$konstrukce_obalu";?>" /></td>

					<td><b>Barevnost</b></td>
					<td><input id="barevnost" type="text" size="30" maxlength="50" name="barevnost" value="<?php echo "$barevnost";?>" /></td>
				</tr>
				<tr>
					<td colspan=2><b>Výsekové formy</b>
						<?
						$rows_under = $sql->query("SELECT id_zak_vyr_vysekove_formy, cislo_vysekove_formy, nazev_vysekove_formy, ks_na_arch, min_rozmer_sirka, min_rozmer_delka, 
													rozmer_obalu_sirka, rozmer_obalu_delka, rozmer_obalu_vyska, vf_poznamka
														FROM zak_vyr_vysekove_formy
													WHERE id_zak_vyrobku=$id_zak_vyrobku
													ORDER BY id_zak_vyr_vysekove_formy");
						while ($row_under=$sql->fetch_array($rows_under)){
							?>
							<table cellspacing="0" cellpadding="5" border="0" width="95%" align="center">
								<tr>
									<td><b><i>Číslo výsekové formy</i></b></td>
									<td><input id="cislo_vysekove_formy<?echo $row_under['id_zak_vyr_vysekove_formy'];?>" type="text" size="10" maxlength="20" name="cislo_vysekove_formy<?echo $row_under['id_zak_vyr_vysekove_formy'];?>" value="<?php echo $h_cislo_vysekove_formy[$row_under['id_zak_vyr_vysekove_formy']];?>" /></td>
								</tr>
								<tr>
									<td><b><i>Název výsekové formy</i></b></td>
									<td><input id="nazev_vysekove_formy<?echo $row_under['id_zak_vyr_vysekove_formy'];?>" type="text" size="30" maxlength="100" name="nazev_vysekove_formy<?echo $row_under['id_zak_vyr_vysekove_formy'];?>" value="<?php echo $h_nazev_vysekove_formy[$row_under['id_zak_vyr_vysekove_formy']];?>" /></td>
								</tr>
								<tr>
									<td><b><i>ks/TA</i></b></td>
									<td><input id="ks_na_arch<?echo $row_under['id_zak_vyr_vysekove_formy'];?>" type="text" size="5" maxlength="5" name="ks_na_arch<?echo $row_under['id_zak_vyr_vysekove_formy'];?>" value="<?php echo $h_ks_na_arch[$row_under['id_zak_vyr_vysekove_formy']];?>" /></td>
								</tr>
								<tr>
									<td><b><i>Minimální rozměr - Š x D (mm)</i></b></td>
									<td>
										<input id="min_rozmer_sirka<?echo $row_under['id_zak_vyr_vysekove_formy'];?>" type="text" size="5" maxlength="5" name="min_rozmer_sirka<?echo $row_under['id_zak_vyr_vysekove_formy'];?>" value="<?php echo $h_min_rozmer_sirka[$row_under['id_zak_vyr_vysekove_formy']];?>" />
										x
										<input id="min_rozmer_delka<?echo $row_under['id_zak_vyr_vysekove_formy'];?>" type="text" size="5" maxlength="5" name="min_rozmer_delka<?echo $row_under['id_zak_vyr_vysekove_formy'];?>" value="<?php echo $h_min_rozmer_delka[$row_under['id_zak_vyr_vysekove_formy']];?>" />
									</td>
								</tr>
								<tr>
									<td><b><i>Rozměry obalu - D x Š x V (mm)</i></b></td>
									<td>
										<input id="rozmer_obalu_delka<?echo $row_under['id_zak_vyr_vysekove_formy'];?>" type="text" size="5" maxlength="5" name="rozmer_obalu_delka<?echo $row_under['id_zak_vyr_vysekove_formy'];?>" value="<?php echo $h_rozmer_obalu_delka[$row_under['id_zak_vyr_vysekove_formy']];?>" />
										x
										<input id="rozmer_obalu_sirka<?echo $row_under['id_zak_vyr_vysekove_formy'];?>" type="text" size="5" maxlength="5" name="rozmer_obalu_sirka<?echo $row_under['id_zak_vyr_vysekove_formy'];?>" value="<?php echo $h_rozmer_obalu_sirka[$row_under['id_zak_vyr_vysekove_formy']];?>" />
										x
										<input id="rozmer_obalu_vyska<?echo $row_under['id_zak_vyr_vysekove_formy'];?>" type="text" size="5" maxlength="5" name="rozmer_obalu_vyska<?echo $row_under['id_zak_vyr_vysekove_formy'];?>" value="<?php echo $h_rozmer_obalu_vyska[$row_under['id_zak_vyr_vysekove_formy']];?>" />
									</td>
								</tr>
								<tr>
									<td colspan=2>
										<b>Poznámka</b><br />
										<input id="vf_poznamka<?echo $row_under['id_zak_vyr_vysekove_formy'];?>" type="text" size="65" maxlength="100" name="vf_poznamka<?echo $row_under['id_zak_vyr_vysekove_formy'];?>" value="<?php echo $h_vf_poznamka[$row_under['id_zak_vyr_vysekove_formy']];?>" />
									</td>
								</tr>
								<tr>
									<td style="text-align:center; border-bottom: 1px dashed;" colspan=2>
										<span style="cursor: pointer;" id="odkaz_smazat_<?echo $row_under['id_zak_vyr_vysekove_formy'];?>" onClick="ukaz_form_smazat(<?echo $row_under['id_zak_vyr_vysekove_formy'];?>)">
											<img src="files/smazat.png" height="16px">
										</span>
										<br />
										<span id="smazat_<?echo $row_under['id_zak_vyr_vysekove_formy'];?>" style="display: none;">
											<a href="?show=zak_vyrobek_edit&id_zak_vyrobku=<?echo $id_zak_vyrobku;?>&smaz_id_vf=<?echo $row_under['id_zak_vyr_vysekove_formy'];?>">Ano</a>
											<a style="margin-left: 20px;" href="javascript:void(0)" onclick="skryj_form_smazat(<?echo $row_under['id_zak_vyr_vysekove_formy'];?>)">Ne</a>
										</span>
									</td>
								</tr>
							</table>
							<?
						}
						?>
					</td>
				</tr>
				<tr>
					<td colspan=4>
						<b>Operace vnitřní</b><br />
						<?
						$i=0;
						$operace_vnitrni = $sql->query("SELECT id_operace_vnitrni, nazev_operace_vnitrni
															FROM operace_vnitrni
														WHERE smazano=0
														ORDER BY poradi");
						while ($operace=$sql->fetch_array($operace_vnitrni)){
							$checked=0;
							if (isset($oznacene_operace_vnitrni)){
								foreach($oznacene_operace_vnitrni as $oz_pol){
									if ($oz_pol['id_operace_vnitrni']==$operace['id_operace_vnitrni']){
										$checked=1;
										$poznamka=$oz_pol['poznamka'];
									}
								}
							}
							zaskrtavaci_policko_o($operace['nazev_operace_vnitrni'], "operace_vnitrni_$operace[id_operace_vnitrni]", $checked, barva($i), $poznamka);
							$poznamka="";
							$i++;
						}
						?>
					</td>
				</tr>
				<tr>
					<td colspan=4>
						<b>Operace vnější</b><br />
						<?
						$i=0;
						$operace_vnejsi = $sql->query("SELECT id_operace_vnejsi, nazev_operace_vnejsi
															FROM operace_vnejsi
														WHERE smazano=0
														ORDER BY poradi");
						while ($operace=$sql->fetch_array($operace_vnejsi)){
							$checked=0;
							if (isset($oznacene_operace_vnejsi)){
								foreach($oznacene_operace_vnejsi as $oz_pol){
									if ($oz_pol['id_operace_vnejsi']==$operace['id_operace_vnejsi']){
										$checked=1;
										$poznamka=$oz_pol['poznamka'];
									}
								}
							}
							zaskrtavaci_policko_o_v($operace['nazev_operace_vnejsi'], "operace_vnejsi_$operace[id_operace_vnejsi]", $checked, barva($i), $poznamka);
							$poznamka="";
							$i++;
						}
						?>
					</td>
				</tr>
			</table>
		
			<?
			$rows = $sql->query("SELECT id_zak_vyr_material, nazev_materialu, hodnota, zkratka_jednotky, u.name editoval, zvm.datum_editace, id_zak_vyrobku
								FROM zak_vyr_material zvm
								JOIN user u ON zvm.editoval = u.id_uzivatel
								LEFT JOIN merna_jednotka mj ON mj.id_merna_jednotka = zvm.id_merna_jednotka
								WHERE id_zak_vyrobku=$id_zak_vyrobku and smazano=0
								ORDER BY zvm.razeni");
			?>
			<table cellspacing="0" cellpadding="5" border="0" width="90%" align="center">
				<tr style="text-align:center; background-color: <?echo $color;?>;">
						<td style="font-weight: bold;">
							Název materiálu
						</td>
						<td style="font-weight: bold;">
							Hodnota
						</td>
						<td style="font-weight: bold; width: 300px;">
							Atributy materiálu
						</td>
						<td style="width: 100px;">
							
						</td>
					</tr>
				<?
				$i=0;
				while ($row=$sql->fetch_array($rows)){
					(($i % 2)==0) ? $color="#DDD" : $color="#FFF";
					$i++;
					$datum_editace = StrFTime("%d.%m.%Y %H:%M", $row['datum_editace']);
					?>
					<tr style="text-align:center; background-color: <?echo $color;?>;">
						<td>
							<?echo $row['nazev_materialu'];?>
						</td>
						<td>
							<?
							if (!empty($_POST["pocet_$row[id_zak_vyr_material]"])){
								$pocet=$_POST["pocet_$row[id_zak_vyr_material]"];
							} else {
								$pocet=$row['hodnota'];
							}
							?>
							<input type="text" size="3" maxlength="5" name="pocet_<?echo $row['id_zak_vyr_material'];?>" value="<?echo $pocet;?>" />
							<?echo $row['zkratka_jednotky'];?>
						</td>
						<td>
							<?
							$atributy_temp = $sql->query("SELECT nazev_atributu, zkratka_jednotky, hodnota, u.name editoval, zvma.datum_editace
																FROM zak_vyr_mat_atributy zvma
																JOIN user u ON u.id_uzivatel= zvma.editoval
																LEFT JOIN merna_jednotka mj ON mj.id_merna_jednotka = zvma.id_merna_jednotka
																WHERE id_zak_vyr_material=$row[id_zak_vyr_material] AND zvma.smazano=0
																ORDER BY zvma.razeni");
							while ($atribut_temp=$sql->fetch_array($atributy_temp)){
								$datum_editace_temp = StrFTime("%d.%m.%Y %H:%M", $atribut_temp['datum_editace']);
								?>
								<span style="border: 1px dotted #888; padding: 0px 10px;">
									<?echo $atribut_temp['nazev_atributu'] . " " . $atribut_temp['hodnota'] . " " . $atribut_temp['zkratka_jednotky'];?>
								</span>
								<?
							}
							?>
						</td>
						<td style="width: 20px;">
							<a href="?show=zak_material_edit&id_zak_vyrobku=<?echo $row['id_zak_vyrobku'];?>&id_zak_vyr_material=<?echo $row['id_zak_vyr_material'];?>"><img src="files/edit.png" height="16px" title="Editovat atributy v materiálu" /></a>
						</td>
						<td style="width: 100px;">
							<span style="cursor: pointer;" id="odkaz_smazat_<?echo $row['id_zak_vyr_material'];?>"	onClick="ukaz_form_smazat(<?echo $row['id_zak_vyr_material'];?>)"
							title="Naposledy editoval(a) <?echo $row['editoval'] . ' ' . $datum_editace;?>">
								<img src="files/smazat.png" height="16px">
							</span>
							<br />
							<span id="smazat_<?echo $row['id_zak_vyr_material'];?>" style="display: none;">
								<a href="?show=zak_vyrobek_edit&id_zak_vyrobku=<?echo $id_zak_vyrobku;?>&smaz_id=<?echo $row['id_zak_vyr_material'];?>">Ano</a>
								<a style="margin-left: 20px;" href="javascript:void(0)" onclick="skryj_form_smazat(<?echo $row['id_zak_vyr_material'];?>)">Ne</a>
							</span>
						</td>
					</tr>
					<?
				}
				?>
			</table>
		</form>
		<div style="text-align: left; margin-top: 20px; padding: 5px; border-bottom: #aaa 1px dashed;border-top: #aaa 1px dashed;">
		<table cellspacing="0" cellpadding="5" border="0" width="100%">
			<tr>
				<td>
					<form action="" method="post" name="vyrobek_material">
						<?
						if (isset($id_zak_vyrobku)){
							?>
							<input type="hidden" name="id_zak_vyrobku" value="<?echo $id_zak_vyrobku;?>" />
							<?
						}
						?>
						
							<table cellspacing="0" cellpadding="5" border="0" width="50%">
								<tr>
									<td><b>Materiál</b> (*)</td>
									<td>
										<select id="id_materialu" name="id_materialu" onchange="ajax('script/vyrobky/aj_nacist_atributy.php?id_materialu='+document.getElementById('id_materialu').value,'formular');">
											<OPTION value="0">Vyberte možnost...</OPTION>
											<?
											$result=$sql->query("SELECT m.id_materialu, m.nazev_materialu, mj.zkratka_jednotky FROM materialy m
																JOIN merna_jednotka mj ON m.id_merna_jednotka = mj.id_merna_jednotka
																WHERE m.smazano=0
																ORDER BY m.nazev_materialu");
											while ($row=$sql->fetch_array($result)){
												if ($row['id_materialu'] == $id_materialu){
													?>
													<OPTION value="<?echo $row['id_materialu'];?>" selected="selected"><?echo $row['nazev_materialu'] . ' (' . $row['zkratka_jednotky'] . ')';?></OPTION>
													<?
												} else {
													?>
													<OPTION value="<?echo $row['id_materialu'];?>"><?echo $row['nazev_materialu'] . ' (' . $row['zkratka_jednotky'] . ')';?></OPTION>
													<?
												}
											}
											?>
										</select>
									</td>
								</tr>
								<tr>
									<td><b>Hodnota</b></td>
									<td>
										<input type="text" size="3" maxlength="10" name="hodnota" value="" />
									</td>
								</tr>
							</table>
							<div id="formular">
								<?
								if (isset($id_materialu)){
									$atributy = $sql->query("SELECT a.id_atributu, a.nazev_atributu, mj.zkratka_jednotky FROM atributy a
															LEFT JOIN merna_jednotka mj ON mj.id_merna_jednotka=a.id_merna_jednotka
															WHERE a.id_materialu=$id_materialu AND a.smazano=0");
									if ($sql->num_rows($atributy)){
										while ($atribut=$sql->fetch_array($atributy)){
											?>
											<table cellspacing="0" cellpadding="5" border="0" width="70%">
												<tr>
													<td style="font-weight: bold; width: 200px;">
														<?
														echo $atribut['nazev_atributu'];
														if (!empty($atribut['zkratka_jednotky'])) echo " (" . $atribut['zkratka_jednotky'] . ")";
														?>
														
													</td>
													<td style="text-align: left;">
														<?
														$hodnoty = $sql->query("SELECT id_hodnoty_atributu, hodnota_atributu FROM hodnoty_atributu
																				WHERE id_atributu=$atribut[id_atributu]");
														if ($sql->num_rows($hodnoty)>0){
															?>
															<select name="atribut<?echo $atribut['id_atributu'];?>">
																<OPTION value="0">Vyberte možnost...</OPTION>
																<?
																while ($hodnota=$sql->fetch_array($hodnoty)){
																	if ($hodnota['hodnota_atributu'] == $hodnoty_atributu[$atribut['id_atributu']]){
																		?>
																		<OPTION value="<?echo $hodnota['hodnota_atributu'];?>" selected="selected"><?echo $hodnota['hodnota_atributu'];?></OPTION>
																		<?
																	} else {
																		?>
																		<OPTION value="<?echo $hodnota['hodnota_atributu'];?>"><?echo $hodnota['hodnota_atributu'];?></OPTION>
																		<?

																	}
																}
																?>
															</select>
															<?
														} else {
															?>
															<input type="text" size="20" maxlength="100" name="atribut<?echo $atribut['id_atributu'];?>" value="<?echo $hodnoty_atributu[$atribut['id_atributu']];?>" />
															<?
														}
														?>
													</td>
												</tr>
											</table>
											<?
										}
									}
								}
								?>
							</div>
							<div>
								<input type="submit" name="save_material" value="Vložit materiál" id="ulozit" />
							</div>
					</form>
				</td>
				<td>
					<form action="" method="post" name="vyrobek_material">
						<table cellspacing="0" cellpadding="5" border="0" width="50%">
							<tr>
								<td><b>Výseková forma</b> (*)</td>
								<td>
									<select id="id_vysekove_formy" name="id_vysekove_formy">
										<OPTION value="0">Vyberte možnost...</OPTION>
										<?
										$result=$sql->query("SELECT id_vysekove_formy, cislo_vysekove_formy, nazev_vysekove_formy, cislo_vysekove_formy, nazev_vysekove_formy, 
															ks_na_arch, min_rozmer_sirka, min_rozmer_delka, rozmer_obalu_sirka, rozmer_obalu_delka, rozmer_obalu_vyska
														FROM zak_vyrobky zv 
														JOIN zakazky z ON z.id_zakazky = zv.id_zakazky
														JOIN vysekove_formy vf ON vf.id_firmy = z.id_firmy
														WHERE vf.smazano=0 and zv.id_zak_vyrobku=$id_zak_vyrobku
														ORDER BY nazev_vysekove_formy");
										while ($row=$sql->fetch_array($result)){
											if ($row['id_vysekove_formy'] == $id_vysekove_formy){
												?>
												<OPTION value="<?echo $row['id_vysekove_formy'];?>" selected="selected">
													<?
													echo $row['cislo_vysekove_formy'] . ' - ' . $row['nazev_vysekove_formy']  . ', ' . $row['ks_na_arch']  . ' ks/arch, min.roz.: ' . $row['min_rozmer_sirka'] 
														 . 'x' . $row['min_rozmer_delka']  . ', roz.obalu: ' . $row['rozmer_obalu_sirka']  . 'x' . $row['rozmer_obalu_delka']  . 'x' . $row['rozmer_obalu_vyska'] ;
													?>
												</OPTION>
												<?
											} else {
												?>
												<OPTION value="<?echo $row['id_vysekove_formy'];?>">
													<?
													echo $row['cislo_vysekove_formy'] . ' - ' . $row['nazev_vysekove_formy']  . ', ' . $row['ks_na_arch']  . ' ks/arch, min.roz.: ' . $row['min_rozmer_sirka'] 
														 . 'x' . $row['min_rozmer_delka']  . ', roz.obalu: ' . $row['rozmer_obalu_sirka']  . 'x' . $row['rozmer_obalu_delka']  . 'x' . $row['rozmer_obalu_vyska'] ;
													?>
												</OPTION>
												<?
											}
										}
										?>
									</select>
								</td>
							</tr>
						</table>
						<div>
							<input type="submit" name="save_vf" value="Vložit výsekovou formu" id="ulozit" />
						</div>
					</form>
				</td>
			</tr>
		</table>
		</div>
		(*) - povinné položky
		<script type="text/javascript"> document.getElementById("nazev_vyrobku").focus(); </script>
		<?php
	}
} else echo "<p class=\"chyba\">Na toto nemáte přiřazená práva.</p>";