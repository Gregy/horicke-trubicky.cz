<?
if (haveRight("ZAKAZKY")){
	if (isset($_GET['smaz_id']) && haveRight('ZAKAZKY_SOUBORY')){
		$datum_editace = Time();
		$sql->query("UPDATE zak_soubory SET smazano=1, editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace' WHERE id_zak_souboru=$_GET[smaz_id]");
	}
	
	$zakazka = $sql->query_array("SELECT id_zakazky, cislo_zakazky, rok, nazev_firmy FROM zakazky WHERE id_zakazky=$_GET[id_zakazky]");
	$id_zakazky = $zakazka['id_zakazky'];
	$cislo_zakazky = $zakazka['cislo_zakazky'];
	$rok = $zakazka['rok'];
	$nazev_firmy = $zakazka['nazev_firmy'];
	
	$rows = $sql->query("SELECT zs.id_zak_souboru, zs.nazev_souboru, zs.cesta, u.name editoval, zs.datum_editace
						FROM zak_soubory zs
						JOIN user u ON u.id_uzivatel = zs.editoval
						WHERE zs.id_zakazky=$id_zakazky AND zs.smazano=0
						ORDER BY zs.id_zak_souboru");
	?>
	<div style="text-align: center; padding: 5px;">
		<span>
			<a href="?show=zakazky" class="zpet">Zpět na seznam zakázek</a>
		</span>
		
		<span style="margin-left: 50px;">
			<?
			if (haveRight("ZAKAZKY")){
				?>
				<a style="text-decoration: none;" href="?show=zakazka_show&id_zakazky=<?echo $id_zakazky;;?>"><img src="files/lupa.gif" title="Náhled na zakázku" height="18px" /></a>
				<?
			}
			?>
		</span>
		<span style="margin-left: 50px;">
			<?
			if (haveRight("ZAKAZKY")){
				?>
				<a style="text-decoration: none;" href="?show=zakazka_vykony&id_zakazky=<?echo $id_zakazky;?>"><img src="files/vykony.png" title="Výkony zaměstnanců" height="18px" /></a>
				<?
			}
			?>
		</span>
		<span style="margin-left: 50px;">
			<?
			if (haveRight("ZAKAZKY_EDITACE")){
				?>
				<a style="text-decoration: none;" href="?show=zakazka_edit&id_zakazky=<?echo $id_zakazky;?>"><img src="files/edit.png" title="Editace zakázky" height="18px" /></a>
				<?
			}
			?>
		</span>
		<span style="margin-left: 50px;">
			<?
			if (haveRight("DODACI_LISTY_EDITACE")){
				?>
				<a style="text-decoration: none;" href="?show=expedice&id_firmy=<?echo $id_firmy;?>"><img src="files/expedice.png" title="Expedice zakázky" height="18px" /></a>
				<?
			}
			?>
		</span>
	</div>
	
	<?
	if (haveRight('ZAKAZKY_SOUBORY')){
		?>
		<div style="width: 100%; text-align:center; padding-bottom: 5px; font-size: 15px;">
			<div class="hlavicka">
				<a href="?show=zak_soubory_edit&id_zakazky=<?echo $id_zakazky;?>" style="margin: 0 25px">Nový soubor</a>
			</div>
		</div>
		<?
	}
	?>
	<h3>
	Soubory k zakázce <?echo cislo_rok($id_zakazky, $rok);?> odběratele <?echo $nazev_firmy;?>
	</h3>
	<?
	if ($sql->num_rows($rows)){
		?>
		<table cellspacing="0" cellpadding="5" border="0" width="50%" align="center">
			<tr style="font-size: 110%; font-weight: bold; vertical-align: bottom;">
				<td style="width: 300px;">
					Název
				</td>
				<td>
					
				</td>
				<td></td>
				<td></td>
			</tr>
			<?
			$i=0;
			while ($row=$sql->fetch_array($rows)){
				(($i % 2)==0) ? $color="#ffe684" : $color="#fff5f5";
				$i++;
				$datum_editace = StrFTime("%d.%m.%Y", $row['datum_editace']);
				?>
				<tr style="background-color: <?echo $color;?>;">
					<td>
						<?echo $row['nazev_souboru'];?>
					</td>
					<td>
						<a href="<?echo $row['cesta'];?>"><img src="files/download.png" height="18px" title="Klikněte pro stažení" /></a>
					</td>
					<td>
						<?
						if (haveRight('ZAKAZKY_SOUBORY')){
							?>
							<a href="?show=zak_soubory_edit&id_zakazky=<?echo $id_zakazky;?>&id_zak_souboru=<?echo $row['id_zak_souboru'];?>" style="text-decoration: none;" title="Naposledy editoval(a) <?echo $row['editoval'] . ' ' . $datum_editace;?>"><img src="files/edit.png" height="16px"></a>
							<?
						}
						?>
					</td>
					<td style="width: 100px; text-align:center;">
						<?
						if (haveRight('ZAKAZKY_SOUBORY')){
							?>
							<span style="cursor: pointer;" id="odkaz_smazat_<?echo $row['id_zak_souboru'];?>"	onClick="ukaz_form_smazat(<?echo $row['id_zak_souboru'];?>)">
								<img src="files/smazat.png" height="16px">
							</span>
							<br />
							<span id="smazat_<?echo $row['id_zak_souboru'];?>" style="display: none;">
								<a href="?show=zakazka_soubory&id_zakazky=<?echo $id_zakazky;?>&smaz_id=<?echo $row['id_zak_souboru'];?>">Ano</a>
								<a style="margin-left: 20px;" href="javascript:void(0)" onclick="skryj_form_smazat(<?echo $row['id_zak_souboru'];?>)">Ne</a>
							</span>
							<?
						}
						?>
					</td>
				</tr>
				<?
			}
			?>
		</table>
		<?
	} else {
		echo "K této zakázce zatím nejsou přiřazené žádné soubory.";
	}
}
?>