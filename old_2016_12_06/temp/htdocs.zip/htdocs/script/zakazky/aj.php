<?
	require_once '../../classes/class_mysql.php';
		$sql=new mysql;

	require_once '../../classes/class_user.php';
		$user=new classUser;
	
	require_once "../../includes/common.php";

	if (isset($_GET['id_zakazky']) && haveRight('ZAKAZKY_EDITACE')){
		$datum_editace = Time();
		if (isset($_GET['cislo_objednavky'])){
			$sql->query("UPDATE zakazky SET cislo_objednavky='$_GET[cislo_objednavky]', editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace' WHERE id_zakazky=$_GET[id_zakazky]");
			?>
			<img src="../../files/ok.png" height="13px" />
			<?
		}
		
		if (isset($_GET['termin_dokonceni'])){
			$termin_dokonceni = strtotime($_GET['termin_dokonceni']);
			$sql->query("UPDATE zakazky SET termin_dokonceni='$termin_dokonceni', editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace' WHERE id_zakazky=$_GET[id_zakazky]");
			?>
			<img src="../../files/ok.png" height="13px" />
			<?
		}
		
		if (isset($_GET['id_stavu'])){
			if ($id_stavu>100){
				$error = "";
				$rows = $sql->query("SELECT id_zak_vyrobku, pocet FROM zak_vyrobky WHERE id_zakazky=$_GET[id_zakazky] and smazano=0");
				if ($sql->num_rows($rows)>0){
					while ($row = $sql->fetch_array($rows)){
						if ($row['pocet']==0){
							$error.="<p class=\"chyba\">Chyb� po�et ks u v�robku.</p>";
						}
					}
				} else {
					$error.="<p class=\"chyba\">Do zak�zky nen� zad�n ��dn� v�robek. Nem��ete ho p�ev�st ze stavu P�ipravuje se...</p>";
				}
			}
			if ($error==""){
				$sql->query("UPDATE zakazky SET id_stavu='$_GET[id_stavu]', editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace' WHERE id_zakazky=$_GET[id_zakazky]");
				?><img src="../../files/ok.png" height="13px" /><?
			}
			else {
				?><img src="../../files/ko.png" height="13px" /><?
			}
		}
		
		if (isset($_GET['poznamka'])){
			$termin_dokonceni = strtotime($_GET['termin_dokonceni']);
			$sql->query("UPDATE zakazky SET poznamka='$poznamka', editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace' WHERE id_zakazky=$_GET[id_zakazky]");
			?>
			<img src="../../files/ok.png" height="13px" />
			<?
		}
	}
	
?>