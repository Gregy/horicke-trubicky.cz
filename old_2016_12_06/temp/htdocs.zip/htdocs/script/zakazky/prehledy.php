<script src="js/tooltip_wz/wz_tooltip.js" type="text/javascript"></script>
<?
if (haveRight("PREHLEDY")){
	if (isset($_GET['cislo_zakazky'])){
		$_SESSION['filtr_prehledu']['cislo_zakazky'] = $_GET['cislo_zakazky'];
	}
	if (isset($_GET['rok'])){
		$_SESSION['filtr_prehledu']['rok'] = $_GET['rok'];
	}
	if (isset($_GET['id_firmy'])){
		$_SESSION['filtr_prehledu']['id_firmy'] = $_GET['id_firmy'];
	}
	if (isset($_GET['id_stavu'])){
		$_SESSION['filtr_prehledu']['id_stavu'] = $_GET['id_stavu'];
	}
	if (isset($_GET['termin_dokonceni_od'])){
		$_SESSION['filtr_prehledu']['termin_dokonceni_od'] = $_GET['termin_dokonceni_od'];
	}
	if (isset($_GET['termin_dokonceni_do'])){
		$_SESSION['filtr_prehledu']['termin_dokonceni_do'] = $_GET['termin_dokonceni_do'];
	}
	if (isset($_GET['save'])){
		$result=$sql->query("SELECT id_stavu, nazev_stavu FROM stavy
							ORDER BY id_stavu");
		while ($row=$sql->fetch_array($result)){
			if (isset($_GET["stav$row[id_stavu]"])){
				$_SESSION['filtr_prehledu']["stav$row[id_stavu]"]=1;
			} else {
				$_SESSION['filtr_prehledu']["stav$row[id_stavu]"]=0;
			}
		}
	}
	
	if (isset($_GET['zrus_filtr'])){
		unset($_SESSION['filtr_prehledu']);
	}
	
	?>
	<div onclick="ukaz_skryj('filtr_prehledu');" style="cursor: pointer;">
		Zobraz / skryj filtr
		<?
		$result=$sql->query("SELECT id_stavu, nazev_stavu FROM stavy
							ORDER BY id_stavu");
		$filtr_stav = 0;
		while ($row=$sql->fetch_array($result)){
			if ($_SESSION['filtr_prehledu']["stav$row[id_stavu]"]==1){
				$filtr_stav = 1;
			}
		}
		
		if (!empty($_SESSION['filtr_prehledu']['cislo_zakazky']) || !empty($_SESSION['filtr_prehledu']['rok']) || !empty($_SESSION['filtr_prehledu']['id_firmy'])
			|| $filtr_stav==1 || !empty($_SESSION['filtr_prehledu']['termin_dokonceni_od']) || !empty($_SESSION['filtr_prehledu']['termin_dokonceni_do'])){
				?> 
				<span style="padding-left: 200px; color: #D55; font-weight: bold;">Filtr je AKTIVNÍ</span>
				<a href="?show=prehledy&zrus_filtr=1" style="margin-left: 200px; color: #555; font-weight: bold;">Zrušit filtr</a>
				<?
		}
		?>
	</div>
	<div id="filtr_prehledu" style="display: none;">
		<form action="" method="GET">
			<input type="hidden" name="show" value="prehledy">
			<table cellspacing="0" cellpadding="5" border="0" width="60%">
				<tr>
					<td>
						<b>Číslo zakázky / rok</b>
					</td>
					<td>
						<input id="cislo_zakazky" name="cislo_zakazky" type="text" value="<?echo $_SESSION['filtr_prehledu']['cislo_zakazky'];?>" size="5" maxlength="5" />
						/
						<input id="rok" name="rok" type="text" value="<?echo $_SESSION['filtr_prehledu']['rok'];?>" size="5" maxlength="5" />
					</td>
				</tr>
				<tr>
					<td>
						<b>Pro firmu</b>
					</td>
					<td>
						<select id="id_firmy" name="id_firmy">
							<OPTION value="0">Vyberte možnost...</OPTION>
							<?
							$result=$sql->query("SELECT id_firmy, nazev_firmy FROM firmy
												ORDER BY nazev_firmy");
							while ($row=$sql->fetch_array($result)){
								if ($row['id_firmy'] == $_SESSION['filtr_prehledu']['id_firmy']){
									?>
									<OPTION value="<?echo $row['id_firmy'];?>" selected="selected"><?echo $row['nazev_firmy'];?></OPTION>
									<?
								} else {
									?>
									<OPTION value="<?echo $row['id_firmy'];?>"><?echo $row['nazev_firmy'];?></OPTION>
									<?
								}
							}
							?>
						</select>
					</td>
				</tr>
				<tr>
					<td>
						<b>Stav zakázky</b>
					</td>
					<td>
						<?
						$result=$sql->query("SELECT id_stavu, nazev_stavu FROM stavy
											ORDER BY id_stavu");
						while ($row=$sql->fetch_array($result)){
							($_SESSION['filtr_prehledu']["stav$row[id_stavu]"]==1) ? $checked='checked="checked"' : $checked="";
							?>
							<div style="padding: 0; margin: 0;">
							<input type="checkbox" size=2 name="stav<?echo $row['id_stavu']?>" <?echo $checked;?> />
							<?
							echo $row['nazev_stavu'];
							?>
							</div>
							<?
						}
						?>
					</td>
				</tr>
				<tr>
					<td>
						<b>Termín dokončení (dd.mm.rrrr)</b>
					</td>
					<td>
						<input id="termin_dokonceni_od" name="termin_dokonceni_od" type="text" value="<?echo $_SESSION['filtr_prehledu']['termin_dokonceni_od'];?>" size="7" maxlength="10" />
						-
						<input id="termin_dokonceni_do" name="termin_dokonceni_do" type="text" value="<?echo $_SESSION['filtr_prehledu']['termin_dokonceni_do'];?>" size="7" maxlength="10" />
					</td>
				</tr>
			</table>
			<div style="padding: 5px;">
				<input type="submit" name="save" value="Použít filtr" id="inform" />
			</div>
		</form>
	</div>
	<?
	$prvni=true;
	if (isset($_SESSION['filtr_prehledu'])){
		if (!empty($_SESSION['filtr_prehledu']['cislo_zakazky'])){
			$where .= "cislo_zakazky=" . $_SESSION['filtr_prehledu']['cislo_zakazky'];
			$prvni=false;
		}
		if (!empty($_SESSION['filtr_prehledu']['rok'])){
			($prvni==false) ? $where .= " AND " : $where .= "";
			$where .= "rok=" . $_SESSION['filtr_prehledu']['rok'];
			$prvni=false;
		}
		if (!empty($_SESSION['filtr_prehledu']['id_firmy'])){
			($prvni==false) ? $where .= " AND " : $where .= "";
			$where .= "id_firmy=" . $_SESSION['filtr_prehledu']['id_firmy'];
			$prvni=false;
		}
		if ($filtr_stav==1){
			$result=$sql->query("SELECT id_stavu, nazev_stavu FROM stavy
								ORDER BY id_stavu");
			$temp_stav = "";
			$prvni_stav = true;
			while ($row=$sql->fetch_array($result)){
				if ($_SESSION['filtr_prehledu']["stav$row[id_stavu]"]==1){
					($prvni_stav==false) ? $temp_stav .= ", " :	$prvni_stav=false;
					$temp_stav .= $row['id_stavu'];
				}
			}
			($prvni==false) ? $where .= " AND " : $where .= "";
			$where .= "s.id_stavu IN (" . $temp_stav . ")";
			$prvni=false;
		}
		if (!empty($_SESSION['filtr_prehledu']['termin_dokonceni_od'])){
			($prvni==false) ? $where .= " AND " : $where .= "";
			$termin_dokonceni_od = strtotime($_SESSION['filtr_prehledu']['termin_dokonceni_od']);
			$where .= "termin_dokonceni>=$termin_dokonceni_od";
			$prvni=false;
		}
		if (!empty($_SESSION['filtr_prehledu']['termin_dokonceni_do'])){
			($prvni==false) ? $where .= " AND " : $where .= "";
			$termin_dokonceni_do = strtotime($_SESSION['filtr_prehledu']['termin_dokonceni_do']);
			$where .= "termin_dokonceni<=$termin_dokonceni_do";
			$prvni=false;
		}
	} else {
		$where = "s.id_stavu<550";
	}
	
	$where = " WHERE " . $where;
	
	$rows = $sql->query("SELECT z.id_zakazky, z.id_firmy, z.cislo_zakazky, z.rok, z.termin_dokonceni, s.nazev_stavu, s.id_stavu, z.nazev_firmy, 
							zv.id_zak_vyrobku, zv.nazev_vyrobku, zv.pocet, zv.jedn_cena, zv.vedlejsi_naklady, zv.fakturace, zv.rozpracovanost, z.rodic_zakazka
						FROM zakazky z
						JOIN zak_vyrobky zv ON zv.id_zakazky = z.id_zakazky and zv.smazano=0
						JOIN stavy s ON z.id_stavu = s.id_stavu
						JOIN user u ON u.id_uzivatel = z.editoval
						$where
						ORDER BY z.rok DESC, z.cislo_zakazky DESC
						");
	?>
	<table cellspacing="0" cellpadding="5" border="0" width="99%" align="center">
		<tr style="text-align:center; font-weight:bold; border-bottom: 1px solid #555; vertical-align: bottom;">
			<td style="width: 70px;">Číslo zakázky</td>
			<td>Odběratel</td>
			<td>Výrobek</td>
			<td>Termín dokončení</td>
			<td style="width: 80px;">Stav</td>
			<td style="width: 60px;">Objednané množství</td>
			<td style="width: 60px;">Exped.</td>
			<td style="width: 30px;">Jedn.cena</td>
			<td style="width: 30px;">Rozpr.(%)</td>
			<td style="width: 60px;">
				Cena ve výrobě
				<span onmouseover="Tip('Výpočet:<br />(Jedn.cena * (Počet - Exped.)) * Rozpr.')" onmouseout="UnTip()" style>
					<img src="files/otaznik.png" height="15px" />
				</span>
			</td>
			<td style="width: 60px;">
				Celk.cena
				<span onmouseover="Tip('Výpočet:<br />Počet * Jedn.cena')" onmouseout="UnTip()" style>
					<img src="files/otaznik.png" height="15px" />
				</span>
			</td>
			<td style="width: 60px;">Vedl.nákl.</td>
			<td style="width: 60px;">
				Fakturováno<br />
				/mělo by být
				<span onmouseover="Tip('Výpočet:<br />Exped. * Jedn.cena')" onmouseout="UnTip()" style>
					<img src="files/otaznik.png" height="15px" />
				</span>
				/
			</td>
			<td style="width: 60px;">Ks k expedici  
				<span onmouseover="Tip('Výpočet:<br />Počet - Exped.')" onmouseout="UnTip()" style>
					<img src="files/otaznik.png" height="15px" />
				</span>
			</td>
			<td style="width: 60px;">Kč k expedici 
				<span onmouseover="Tip('Výpočet:<br />Fakturováno - (Jedn.cena * Počet)')" onmouseout="UnTip()" style>
					<img src="files/otaznik.png" height="15px" />
				</span>
			</td>
			<td></td>
		</tr>
		<?
		$i=0;
		$celk_cena=0;
		$celk_cena_ve_vyrobe=0;
		$celk_vedl_nakl=0;
		$celk_fakturace=0;
		$celk_zbyva_fakturovat=0;
		while ($row=$sql->fetch_array($rows)){
			(($i % 2)==0) ? $color="#b0ffb0" : $color="#FFF";
			$termin_dokonceni = StrFTime("%d.%m.%Y", $row['termin_dokonceni']);
			$datum_editace = StrFTime("%d.%m.%Y %H:%M", $row['datum_editace']);
			$i++;
			?>
			<tr style="text-align:center; background-color: <?echo $color;?>; font-size: 90%;">
				<td>
					<?
					echo cislo_rok($row['cislo_zakazky'], $row['rok']);
					
					if ($row['rodic_zakazka']>0){
						$temp = $sql->query_array("SELECT cislo_zakazky, rok FROM zakazky WHERE id_zakazky=$row[rodic_zakazka]");
						?>
						<span onmouseover="Tip('<?echo "Subzakázka pro " . cislo_rok($temp['cislo_zakazky'], $temp['rok']);?>')" onmouseout="UnTip()" style>
							<img src="files/otaznik.png" height="15px" />
						</span>
						<?
					}
					?>
				</td>
				<td><?echo $row['nazev_firmy'];?></td>
				<td><?echo $row['nazev_vyrobku'];?></td>
				<td><?echo $termin_dokonceni;?></td>
				<td><?echo $row['nazev_stavu'];?></td>
				<td><?echo number_format($row['pocet'], 0, '.', ' ');?></td>
				<td>
					<?
					if ($row['rodic_zakazka']==0){
						$exp = 0;
						$expedovano = $sql->query("SELECT pocet FROM dod_lis_vyrobky dlv
													JOIN dodaci_listy dl ON dl.id_dodaciho_listu = dlv.id_dodaciho_listu
													WHERE id_zak_vyrobku = $row[id_zak_vyrobku] and dl.smazano=0");
						if ($sql->num_rows($expedovano)){
							while ($temp=$sql->fetch_array($expedovano)){
								$exp = $exp + $temp['pocet'];
							}
							echo number_format($exp, 0, '.', ' ');
						}
					} else {
						echo "---";
					}
					?>
				</td>
				<td>
					<?
					//tato podminka je udelana kvuli zakaznikovi Ella CS, s.r.o.
					if ($row['id_firmy']!=11 || ($row['rodic_zakazka']==0 && $row['id_firmy']==11)){
						echo number_format($row['jedn_cena'], 2, '.', ' ');
					} else {
						echo "---";
					}
					?>
				</td>
				<td>
					<?
					echo $row['rozpracovanost'];
					?>
				</td>
				<td>
					<?
					//tato podminka je udelana kvuli zakaznikovi Ella CS, s.r.o.
					if ($row['id_firmy']!=11 || ($row['rodic_zakazka']==0 && $row['id_firmy']==11)){
						//tato podminka vytvorena, aby se do celkove ceny nepromitaly vyexpedovane subzakazky
						if ($row['rodic_zakazka']!=0 && $row['id_stavu']>599){
							echo "---";
						} else {
							($row['jedn_cena']*($row['pocet']-$exp)>0) ? $cena_ve_vyrobe = ($row['jedn_cena']*($row['pocet']-$exp))*($row['rozpracovanost']/100) : $cena_ve_vyrobe=0;
							echo number_format($cena_ve_vyrobe, 0, '.', ' ');
							$celk_cena_ve_vyrobe+=$cena_ve_vyrobe;
						}
					} else {
						echo "---";
					}
					?>
				</td>
				<td>
					<?
					//tato podminka je udelana kvuli zakaznikovi Ella CS, s.r.o.
					if ($row['id_firmy']!=11 || ($row['rodic_zakazka']==0 && $row['id_firmy']==11)){
						echo number_format($row['jedn_cena']*$row['pocet'], 0, '.', ' ');
						$celk_cena+=$row['jedn_cena']*$row['pocet'];
					} else {
						echo "---";
					}
					?>
				</td>
				<td>
					<?
					if ($row['rodic_zakazka']==0){
						echo number_format($row['vedlejsi_naklady'], 0, '.', ' ');
						$celk_vedl_nakl+=$row['vedlejsi_naklady'];
					} else {
						echo "---";
					}
					?>
				</td>
				<td>
					<?
					//tato podminka je udelana kvuli zakaznikovi Ella CS, s.r.o.
					if ($row['id_firmy']!=11 || ($row['rodic_zakazka']==0 && $row['id_firmy']==11)){
						echo number_format($row['fakturace'], 0, '.', ' ');
						if (($exp*$row['jedn_cena'])>0 && $row['fakturace']+0.99<$exp*$row['jedn_cena']){
							echo "<br />/" . number_format($exp*$row['jedn_cena'], 0, '.', ' ') . "/";
						}
						$celk_fakturace+=$row['fakturace'];
					} else {
						echo "---";
					}
					?>
				</td>
				<td>
					<?
					if ($row['rodic_zakazka']==0){
						if (($row['pocet']-$exp)>0){
							echo number_format($row['pocet']-$exp, 0, '.', ' ');
							$celk_ks_shv += $row['pocet']-$exp;
						} else {
							echo "0";
						}
					} else {
						echo "---";
					}
					?>
				</td>
				<td>
					<?
					if ($row['rodic_zakazka']==0){
						((($row['fakturace']-($row['jedn_cena']*$row['pocet']))*-1)>0) ? $zbyva_fakturovat=($row['fakturace']-($row['jedn_cena']*$row['pocet']))*-1 : $zbyva_fakturovat=0;
						echo number_format($zbyva_fakturovat, 0, '.', ' ');
						$celk_zbyva_fakturovat+=$zbyva_fakturovat;
					} else {
						echo "---";
					}
					?>
				</td>
				<td>
					<a style="text-decoration: none;" href="?show=zakazka_edit&id_zakazky=<?echo $row['id_zakazky'];?>&prehled=1"><img src="files/edit.png" title="Editace zakázky" height="18px" /></a>
				</td>
			</tr>
			<?
		}
		?>
		<tr style="text-align:center; font-weight:bold; border-bottom: 1px solid #555;">
			<td>Číslo zakázky</td>
			<td>Odběratel</td>
			<td>Výrobek</td>
			<td>Termín dokončení</td>
			<td>Stav</td>
			<td>Objednané množství</td>
			<td>Exped.</td>
			<td>Jedn.cena</td>
			<td>Rozpr.(%)</td>
			<td>Cena ve výrobě</td>
			<td>Celk.cena</td>
			<td>Vedl.nákl.</td>
			<td>Fakturováno<br />/mělo by být/</td>
			<td>ks k expedici</td>
			<td>Kč k expedici</td>
			<td></td>
		</tr>
		<tr style="text-align:center; background-color: <?echo $color;?>; font-size: 90%;">
			<td colspan=9 style="font-weight: bold; text-align: right;">Celkem</td>
			<td><?echo number_format($celk_cena_ve_vyrobe, 0, '.', ' ');?></td>
			<td><?echo number_format($celk_cena, 0, '.', ' ');?></td>
			<td><?echo number_format($celk_vedl_nakl, 0, '.', ' ');?></td>
			<td><?echo number_format($celk_fakturace, 0, '.', ' ');?></td>
			<td><?echo number_format($celk_ks_shv, 0, '.', ' ');?></td>
			<td><?echo number_format($celk_zbyva_fakturovat, 0, '.', ' ');?></td>
		</tr>
	</table>
	<?
}
?>