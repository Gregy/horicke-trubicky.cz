<div class="sklady">
<?
if (haveRight('SKLADY_POLOZKY_EDITACE')){
	if (isset($_GET['id_skl_polozky'])){
		global $sql;
		$temp = $sql->query_array("SELECT id_skl_polozky, nazev_skl_polozky, popis_skl_polozky FROM skl_polozky WHERE id_skl_polozky='$_GET[id_skl_polozky]'");
		$id_skl_polozky = $temp['id_skl_polozky'];
		$nazev_skl_polozky = $temp['nazev_skl_polozky'];
		$popis_skl_polozky = $temp['popis_skl_polozky'];
	}
	
	if ($_POST['save']=="Uložit"){
		$error="";
		if (isset($_POST['id_skl_polozky']))
			$id_skl_polozky = $_POST['id_skl_polozky'];
		$nazev_skl_polozky = $_POST['nazev_skl_polozky'];
		$popis_skl_polozky = $_POST['popis_skl_polozky'];
		
		$error.=(empty($nazev_skl_polozky)) ? "<p class=\"chyba\">Nebyl zadán název skladové položky.</p>" : "";
	}
	
	if ($error=="" && $_POST['save']=="Uložit"){
		$nazev_skl_polozky=check_input($nazev_skl_polozky);
		$popis_skl_polozky=check_input($popis_skl_polozky);
		$datum_editace = Time();
		$sql->query("UPDATE skl_polozky SET nazev_skl_polozky='$nazev_skl_polozky', popis_skl_polozky='$popis_skl_polozky', editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace' 
					WHERE id_skl_polozky=$id_skl_polozky");
		
		$saved=1;
		echo "<p class=\"oznameni\">Položka v pořádku uložena.</p>";
		
		$refresh_page=$page->_head_path . "?show=sklady_prehled";
		echo "<meta http-equiv=\"refresh\" content=\"1; url=$refresh_page\">";
		message_auto_forward($refresh_page);
	} else if ($error!=""){
		echo "<hr /><b>" . $error . "</b><hr />";
	}
		
	if ($saved==0){
		?>
		<form action="" method="post" name="skl_polozka">
			<div style="text-align: center; padding: 5px; border-bottom: #aaa 1px dashed;">
				<input type="submit" name="save" value="Uložit" id="ulozit" />
				<span style="padding-left: 100px">
					<a href="?show=sklady_prehled" class="zpet">Zpět na přehled skladů (bez uložení)</a>
				</span>
			</div>
			
			<?php
				if (isset($id_skl_polozky)){
					?>
					<input type="hidden" name="id_skl_polozky" value="<?echo $id_skl_polozky;?>" />
					<?
				}
			?>
			<table cellspacing="0" cellpadding="5" border="0" width="100%" align="center">
				<tr>
					<td style="text-align: right"><b>Název</b> (*)</td>
					<td colspan=2><input id="nazev_skl_polozky" type="text" size="30" maxlength="100" name="nazev_skl_polozky" value="<?php echo "$nazev_skl_polozky";?>" /></td>
				</tr>
				<tr>
					<td style="text-align: right"><b>Popis</b> (*)</td>
					<td colspan=2><input id="popis_skl_polozky" type="text" size="30" maxlength="100" name="popis_skl_polozky" value="<?php echo "$popis_skl_polozky";?>" /></td>
				</tr>
			</table>
			<script type="text/javascript"> document.getElementById("nazev_skl_polozky").focus(); </script>
		</form>
		<br /><br />(*) - povinné položky
		<?
	}
} else echo "<p class=\"chyba\">Na toto nemáte přiřazená práva.</p>";
?>
</div>