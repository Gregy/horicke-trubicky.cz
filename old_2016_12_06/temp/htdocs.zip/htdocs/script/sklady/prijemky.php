<div class="sklady">
<script src="js/tooltip_wz/wz_tooltip.js" type="text/javascript"></script>
<?
if (haveRight('SKLADY_PRIJEMKY')){
	if (isset($_GET['cislo_prijemky'])){
		$_SESSION['filtr_prijemek']['cislo_prijemky'] = $_GET['cislo_prijemky'];
	}
	if (isset($_GET['rok'])){
		$_SESSION['filtr_prijemek']['rok'] = $_GET['rok'];
	}
	if (isset($_GET['id_firmy'])){
		$_SESSION['filtr_prijemek']['id_firmy'] = $_GET['id_firmy'];
	}
	if (isset($_GET['id_skl_polozky'])){
		$_SESSION['filtr_prijemek']['id_skl_polozky'] = $_GET['id_skl_polozky'];
	}
	
	if (isset($_GET['zrus_filtr'])){
		unset($_SESSION['filtr_prijemek']);
	}
	
	include_once 'script/sklady/submenu.php';
	?>
	<div style="width: 100%; text-align:center; padding-bottom: 5px; font-size: 15px;">
		<div class="firmy">
			<?
			if (haveRight('SKLADY_PRIJEMKY')){
				?>
				<a href="?show=prijemka_new" style="margin: 0 25px">Nová příjemka</a>
				<?
			}
			?>
		</div>
	</div>
	<?
	
	if (isset($_GET['smaz_id']) && haveRight('SKLADY_PRIJEMKY_SMAZAT')){
		$datum_editace = Time();
		$temp = $sql->query("SELECT * FROM skl_vydejky WHERE id_skl_prijemky=$_GET[smaz_id] AND smazano=0");
		
		if ($sql->num_rows($temp)==0){
			$sql->query("UPDATE skl_prijemky SET smazano=1, editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace' WHERE id_skl_prijemky=$_GET[smaz_id]");
		} else {
			echo "<p class=\"chyba\">Na tuto příjemku je udělaná platná výdejka, takže nelze smazat.</p>";
		}
	}
	?>
	<div onclick="ukaz_skryj('filtr_prijemek');" style="cursor: pointer;">
		Zobraz / skryj filtr
		<?
		if (!empty($_SESSION['filtr_prijemek']['cislo_prijemky']) || !empty($_SESSION['filtr_prijemek']['rok']) || !empty($_SESSION['filtr_prijemek']['id_firmy']) 
			|| !empty($_SESSION['filtr_prijemek']['id_skl_polozky'])){
				?> 
				<span style="padding-left: 200px; color: #D55; font-weight: bold;">Filtr je AKTIVNÍ</span>
				<a href="?show=prijemky&zrus_filtr=1" style="margin-left: 200px; color: #555; font-weight: bold;">Zrušit filtr</a>
				<?
		}
		?>
	</div>
	<div id="filtr_prijemek" style="display: none;">
		<form action="" method="GET">
			<input type="hidden" name="show" value="prijemky">
			<table cellspacing="0" cellpadding="5" border="0" width="60%">
				<tr>
					<td>
						<b>Číslo příjemky / rok</b>
					</td>
					<td>
						<input id="cislo_prijemky" name="cislo_prijemky" type="text" value="<?echo $_SESSION['filtr_prijemek']['cislo_prijemky'];?>" size="5" maxlength="5" />
						/
						<input id="rok" name="rok" type="text" value="<?echo $_SESSION['filtr_prijemek']['rok'];?>" size="5" maxlength="5" />
					</td>
				</tr>
				<tr>
					<td>
						<b>Pro firmu</b>
					</td>
					<td>
						<select id="id_firmy" name="id_firmy">
							<OPTION value="0">Vyberte možnost...</OPTION>
							<?
							$result=$sql->query("SELECT id_firmy, nazev_firmy FROM firmy_dodavatelu
												WHERE smazano=0
												ORDER BY nazev_firmy");
							while ($row=$sql->fetch_array($result)){
								if ($row['id_firmy'] == $_SESSION['filtr_prijemek']['id_firmy']){
									?>
									<OPTION value="<?echo $row['id_firmy'];?>" selected="selected"><?echo $row['nazev_firmy'];?></OPTION>
									<?
								} else {
									?>
									<OPTION value="<?echo $row['id_firmy'];?>"><?echo $row['nazev_firmy'];?></OPTION>
									<?
								}
							}
							?>
						</select>
					</td>
				</tr>
				<tr>
					<td>
						<b>Skladová položka</b>
					</td>
					<td>
						<select id="id_skl_polozky" name="id_skl_polozky">
							<OPTION value="0">Vyberte možnost...</OPTION>
							<?
							$result=$sql->query("SELECT id_skl_polozky, nazev_skl_polozky, popis_skl_polozky FROM skl_polozky 
												WHERE smazano=0
												ORDER BY nazev_skl_polozky, popis_skl_polozky
												");
							while ($row=$sql->fetch_array($result)){
								if ($row['id_skl_polozky'] == $_SESSION['filtr_prijemek']['id_skl_polozky']){
									?>
									<OPTION value="<?echo $row['id_skl_polozky'];?>" selected="selected"><?echo $row['nazev_skl_polozky'] . " (" . $row['popis_skl_polozky'] . ")";?></OPTION>
									<?
								} else {
									?>
									<OPTION value="<?echo $row['id_skl_polozky'];?>"><?echo $row['nazev_skl_polozky'] . " (" . $row['popis_skl_polozky'] . ")";?></OPTION>
									<?
								}
							}
							?>
						</select>
					</td>
				</tr>
			</table>
			<div style="padding: 5px;">
				<input type="submit" name="save" value="Použít filtr" id="inform" />
			</div>
		</form>
	</div>
	<?
	$prvni=false;
	if (isset($_SESSION['filtr_prijemek'])){
		if (!empty($_SESSION['filtr_prijemek']['cislo_prijemky'])){
			($prvni==false) ? $where .= " AND " : $where .= "";
			$where .= "cislo_prijemky=" . $_SESSION['filtr_prijemek']['cislo_prijemky'];
			$prvni=false;
		}
		if (!empty($_SESSION['filtr_prijemek']['rok'])){
			($prvni==false) ? $where .= " AND " : $where .= "";
			$where .= "rok=" . $_SESSION['filtr_prijemek']['rok'];
			$prvni=false;
		}
		if (!empty($_SESSION['filtr_prijemek']['id_firmy'])){
			($prvni==false) ? $where .= " AND " : $where .= "";
			$where .= "id_firmy=" . $_SESSION['filtr_prijemek']['id_firmy'];
			$prvni=false;
		}
		if (!empty($_SESSION['filtr_prijemek']['id_skl_polozky'])){
			($prvni==false) ? $where .= " AND " : $where .= "";
			$where .= "id_skl_polozky=" . $_SESSION['filtr_prijemek']['id_skl_polozky'];
			$prvni=false;
		}
	} else {
		$where = "";
		$limit = "LIMIT 20";
	}
	
	$where = " WHERE sp.smazano=0 " . $where;
	
	$rows = $sql->query("SELECT DISTINCT sp.id_skl_prijemky, sp.cislo_prijemky, sp.rok, sp.nazev_firmy, sp.datum_editace, u.name editoval, sp.rozpracovano, s.nazev_skladu
							FROM skl_prijemky sp
							LEFT JOIN skl_pri_materialy spm ON sp.id_skl_prijemky = spm.id_skl_prijemky
							JOIN user u ON u.id_uzivatel = sp.editoval
							JOIN sklady s ON s.id_skladu = sp.id_skladu
						$where
						ORDER BY sp.rok DESC, sp.cislo_prijemky DESC
						$limit");
	?>
	<table cellspacing="0" cellpadding="5" border="0" width="80%" align="center">
		<tr style="font-size: 110%; font-weight: bold; vertical-align: bottom;">
			<td>
				Datum přijetí
			</td>
			<td>
				Č.příjemky
			</td>
			<td>
				Dod.firma
			</td>
			<td>
				Na sklad
			</td>
			<td></td>
			<td></td>
			<td></td>
		</tr>
		<?
		$i=0;
		while ($row=$sql->fetch_array($rows)){
			(($i % 2)==0) ? $color="#ffe684" : $color="#fff5f5";
			$i++;
			$datum_editace = StrFTime("%d.%m.%Y", $row['datum_editace']);
			?>
			<tr style="background-color: <?echo $color;?>;">
				<td>
					<?echo $datum_editace;?>
				</td>
				<td>
					<?echo $row['cislo_prijemky'] . "/" . $row['rok'];?>
				</td>
				<td>
					<?echo $row['nazev_firmy'];?>
				</td>
				<td>
					<?echo $row['nazev_skladu'];?>
				</td>
				<td>
					<?
					if ($row['rozpracovano']==0){	
						$materialy = $sql->query("SELECT nazev_skl_polozky, popis_skl_polozky, mj.zkratka_jednotky, mnozstvi FROM skl_pri_materialy spm 
												LEFT JOIN merna_jednotka mj ON mj.id_merna_jednotka = spm.id_merna_jednotka
												WHERE id_skl_prijemky=$row[id_skl_prijemky]");
						$seznam_materialu = "<b>Materiály zadané do příjemky " . $row['cislo_prijemky'] . "/" . $row['rok'] . "</b>";
						while ($material=$sql->fetch_array($materialy)){
							$seznam_materialu .= "<br />" . $material['nazev_skl_polozky'] . " - " . $material['popis_skl_polozky'] . " - " . number_format($material['mnozstvi'], 0, '.', ' ') . " " . $material['zkratka_jednotky'];
						}
						?>
						<a href="?show=prijemka_show&id_skl_prijemky=<?echo $row['id_skl_prijemky'];?>" style="text-decoration: none;">
							<span onmouseover="Tip('<?echo $seznam_materialu;?>')" onmouseout="UnTip()">
								<img src="files/lupa.gif" height="16px" />
							</span>
						</a>
						<?
					}
					?>
				</td>
				<td>
					<?
					if ($row['rozpracovano']==1){	
						?>
						<a href="?show=prijemka_edit&id_skl_prijemky=<?echo $row['id_skl_prijemky'];?>" style="text-decoration: none;" title="Naposledy editoval(a) <?echo $row['editoval'] . ' ' . $datum_editace;?>"><img src="files/edit.png" height="16px"></a>
						<?
					}
					?>
				</td>
				<td style="width: 100px; text-align:center;">
					<?
					if (haveRight('SKLADY_PRIJEMKY_SMAZAT')){
						?>
						<span style="cursor: pointer;" id="odkaz_smazat_<?echo $row['id_skl_prijemky'];?>"	onClick="ukaz_form_smazat(<?echo $row['id_skl_prijemky'];?>)">
							<img src="files/smazat.png" height="16px">
						</span>
						<br />
						<span id="smazat_<?echo $row['id_skl_prijemky'];?>" style="display: none;">
							<a href="?show=prijemky&smaz_id=<?echo $row['id_skl_prijemky'];?>">Ano</a>
							<a style="margin-left: 20px;" href="javascript:void(0)" onclick="skryj_form_smazat(<?echo $row['id_skl_prijemky'];?>)">Ne</a>
						</span>
						<?
					}
					?>
				</td>
			</tr>
			<?
		}
		?>
	</table>
	<?
} else echo "<p class=\"chyba\">Na toto nemáte přiřazená práva.</p>";
?>
</div>