<div class="sklady">
<?
if (haveRight('SKLADY')){
	if (isset($_GET['id_skl_polozky'])){
		$datum_tisku = Time();
		$datum_tisku = StrFTime("%d.%m.%Y", $datum_tisku);
		
		if (!is_print_mod()){
			?>
			<div style="text-align: center; padding: 5px; border-bottom: #aaa 1px dashed;">
				<span>
					<a href="?show=sklady_prehled" class="zpet">Zpět na přehled skladů</a>
				</span>
			</div>
			<?
		}
		?>
		<span style="font-weight: bold; font-size: 120%;">
			Obal-tisk, s.r.o. - stav skladové položky a jejích příjemek ke dni <?echo $datum_tisku;?>
		</span>
		<div style="font-weight: bold; font-size: 120%; padding: 10px 0 5px 100px; color: #00F;">
			<?
			echo $sklad['nazev_skladu'];
			?>
		</div>
		<?
		$rows = $sql->query("SELECT sp.id_skl_polozky, sp.nazev_skl_polozky, sp.popis_skl_polozky, 
								(SELECT SUM( mnozstvi ) FROM skl_pri_materialy spm1 
									JOIN skl_prijemky sp1 ON sp1.id_skl_prijemky = spm1.id_skl_prijemky
									WHERE spm1.id_skl_polozky = sp.id_skl_polozky AND sp1.smazano = 0 AND sp1.rozpracovano = 0) prijate_mnozstvi, 
								(SELECT SUM( mnozstvi ) FROM skl_vyd_materialy svm1 
									JOIN skl_vydejky sv1 ON sv1.id_skl_vydejky = svm1.id_skl_vydejky 
									WHERE svm1.id_skl_polozky = sp.id_skl_polozky AND sv1.smazano = 0 AND sv1.rozpracovano = 0) vydane_mnozstvi,
								mj.zkratka_jednotky
							FROM skl_polozky sp
							LEFT JOIN merna_jednotka mj ON mj.id_merna_jednotka = sp.id_merna_jednotka
							WHERE sp.smazano = 0
							AND sp.id_skl_polozky=$_GET[id_skl_polozky]
							ORDER BY sp.nazev_skl_polozky, sp.popis_skl_polozky");
		?>
		<table cellspacing="0" cellpadding="5" border="0" width="99%" align="center">
			<tr style="font-size: 110%; font-weight: bold; vertical-align: bottom;">
				<td style="width: 200px;">
					Název položky
				</td>
				<td style="width: 170px;">
					Popis
				</td>
				<td style="text-align: right; width: 80px;">
					Počet
				</td>
				<td style="text-align: right; width: 100px;">
					Jedn.cena<br>(v Kč)
				</td>
				<td style="text-align: right; width: 100px;">
					Celk.cena<br>(v Kč)
				</td>
				<?
				if (!is_print_mod()){
					?>
					<td></td>
					<td></td>
					<td></td>
					<?
				}
				?>
			</tr>
			<?
			$i=0;
			$row=$sql->query_array("SELECT sp.id_skl_polozky, sp.nazev_skl_polozky, sp.popis_skl_polozky, 
										(SELECT SUM( mnozstvi ) FROM skl_pri_materialy spm1 
											JOIN skl_prijemky sp1 ON sp1.id_skl_prijemky = spm1.id_skl_prijemky
											WHERE spm1.id_skl_polozky = sp.id_skl_polozky AND sp1.smazano = 0 AND sp1.rozpracovano = 0) prijate_mnozstvi, 
										(SELECT SUM( mnozstvi ) FROM skl_vyd_materialy svm1 
											JOIN skl_vydejky sv1 ON sv1.id_skl_vydejky = svm1.id_skl_vydejky 
											WHERE svm1.id_skl_polozky = sp.id_skl_polozky AND sv1.smazano = 0 AND sv1.rozpracovano = 0) vydane_mnozstvi,
										mj.zkratka_jednotky
									FROM skl_polozky sp
									LEFT JOIN merna_jednotka mj ON mj.id_merna_jednotka = sp.id_merna_jednotka
									WHERE sp.smazano = 0
									AND sp.id_skl_polozky=$_GET[id_skl_polozky]
									ORDER BY sp.nazev_skl_polozky, sp.popis_skl_polozky");
				if (($row['prijate_mnozstvi']-$row['vydane_mnozstvi'])>0 || $_SESSION['filtr_skladu']['zobrazit_vse']==1){
					(($i % 2)==0) ? $color="#ffcccc" : $color="#fff5f5";
					$i++;
					
					$datum_editace = StrFTime("%d.%m.%Y %H:%M", $row['datum_editace']);
					$prijemky = $sql->query("SELECT cislo_prijemky, rok, poznamka, mnozstvi, cena FROM skl_pri_materialy spm 
										JOIN skl_prijemky sp ON sp.id_skl_prijemky = spm.id_skl_prijemky
										WHERE sp.smazano=0 AND sp.rozpracovano=0 AND spm.id_skl_polozky=$row[id_skl_polozky]
										ORDER BY sp.id_skl_prijemky DESC");
					$cena=0;
					$mnozstvi=0;
					while ($prijemka=$sql->fetch_array($prijemky)){
						$mnozstvi+=$prijemka['mnozstvi'];
						if ($mnozstvi <= ($row['prijate_mnozstvi']-$row['vydane_mnozstvi'])){
							$cena+=$prijemka['cena']*$prijemka['mnozstvi'];
						} else {
							$cena+=($prijemka['cena'])*($row['prijate_mnozstvi']-$row['vydane_mnozstvi']-($mnozstvi-$prijemka['mnozstvi']));
							break;
						}
					}
					?>
					<tr style="background-color: <?echo $color;?>;">
						<td>
							<?echo $row['nazev_skl_polozky'];?>
						</td>
						<td>
							<?echo $row['popis_skl_polozky'];?>
						</td>
						<td style="text-align: right;">
							<?
							$pocet = number_format($row['prijate_mnozstvi']-$row['vydane_mnozstvi'], 0, '.', ' ');
							echo $pocet . " " . $row['zkratka_jednotky'];
							?>
						</td>
						<td style="text-align: right;">
							<?
							if ($pocet>0){
								$jedn_cena = number_format($cena/$pocet, 2, '.', ' ');
								echo $jedn_cena;
							} else echo "---";
							?>
						</td>
						<td style="text-align: right;">
							<?
							$cena = number_format($cena, 0, '.', ' ');
							echo $cena;
							?>
						</td>
					</tr>
					<?
				}
			?>
		</table>
		
		<table cellspacing="0" cellpadding="5" border="0" width="99%" align="center">
			<tr style="font-size: 110%; font-weight: bold; vertical-align: bottom;">
				<td style="text-align: center;">
					Číslo příjemky / rok
				</td>
				<td>
					Poznámka
				</td>
				<td style="text-align: right; width: 80px;">
					Množství (<?echo $row['zkratka_jednotky'];?>)
				</td>
				<td style="text-align: right; width: 80px;">
					Jedn.cena<br>(v Kč)
				</td>
				<td></td>
			</tr>
			
			<?
			$prijemky = $sql->query("SELECT cislo_prijemky, rok, poznamka, mnozstvi, cena FROM skl_pri_materialy spm 
									JOIN skl_prijemky sp ON sp.id_skl_prijemky = spm.id_skl_prijemky
									WHERE sp.smazano=0 AND sp.rozpracovano=0 AND spm.id_skl_polozky=$row[id_skl_polozky]
									ORDER BY sp.id_skl_prijemky DESC");
			$mnozstvi=0;
			while ($prijemka=$sql->fetch_array($prijemky)){
				?>
				<tr>
					<td style="text-align: center;"><?echo $prijemka['cislo_prijemky'] . "/" . $prijemka['rok'];?></td>
					<td><?echo $prijemka['poznamka'];?></td>
					<td style="text-align: right;"><?echo $prijemka['mnozstvi'];?></td>
					<td style="text-align: right;"><?echo $prijemka['cena'];?></td>
				
				<?
				$mnozstvi+=$prijemka['mnozstvi'];
				if ($mnozstvi <= ($row['prijate_mnozstvi']-$row['vydane_mnozstvi'])){
					$text="na skladě";
				} else if (($mnozstvi - $prijemka['mnozstvi']) < ($row['prijate_mnozstvi']-$row['vydane_mnozstvi'])){
					$text="částečně vyskladněno";
				} else {
					$text="vyskladněno";
				}
				?>
					<td><?echo $text;?></td>
				</tr>
				<?
			}
			?>
			
		</table>
			<?
	}
} else echo "<p class=\"chyba\">Na toto nemáte přiřazená práva.</p>";
?>
</div>