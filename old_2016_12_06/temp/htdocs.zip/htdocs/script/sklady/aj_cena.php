<?
	require_once '../../classes/class_mysql.php';
		$sql=new mysql;

	require_once '../../classes/class_user.php';
		$user=new classUser;
	
	require_once "../../includes/common.php";

	if (isset($_GET['id_skl_pri_materialu']) && haveRight('SKLADY_PRIJEMKY')){
		$cena_temp = str_replace(",", ".", $_GET['cena']);
		if (!empty($cena_temp) && is_numeric($cena_temp) && $cena_temp!=0){
			$sql->query("UPDATE skl_pri_materialy SET cena='$cena_temp' WHERE id_skl_pri_materialu=$_GET[id_skl_pri_materialu]");
			?>
			<img src="../../files/ok.png" height="13px" />
			<?
		}
		else {
			?>
			<img src="../../files/ko.png" height="13px" />
			<?
		}
	}
?>