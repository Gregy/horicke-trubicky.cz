<div class="sklady">
<?
if (haveRight('SKLADY_PRIJEMKY')){
	if (isset($_POST['save'])){
		$error="";
		if ($_POST['id_skladu']!=0)
			$id_skladu = $_POST['id_skladu'];
		else 
			$error.="<p class=\"chyba\">Vyberte sklad, pro který chcete vytvořit příjemku.</p>";
		
		if ($_POST['id_firmy']!=0)
			$id_firmy = $_POST['id_firmy'];
		else 
			$error.="<p class=\"chyba\">Vyberte firmu, od které zboží odebíráte.</p>";
	}
	
	if ($error=="" && isset($_POST['save'])){
		$nazev_firmy = $sql->query_array("SELECT nazev_firmy FROM firmy_dodavatelu WHERE id_firmy=$id_firmy");
		$nazev_firmy = $nazev_firmy['nazev_firmy'];
		$datum_editace = Time();
		$rok = date('Y');
		$max_cislo_prijemky = $sql->query_array("SELECT max(cislo_prijemky) cislo FROM skl_prijemky WHERE rok=$rok");
		if ($max_cislo_prijemky['cislo']>0) 
			$max_cislo_prijemky = $max_cislo_prijemky['cislo']+1;
		else
			$max_cislo_prijemky = 1;
		$sql->query("INSERT INTO skl_prijemky VALUES (NULL, $id_skladu, $id_firmy, '$nazev_firmy', '', '$max_cislo_prijemky', '$rok', '$_SESSION[ot_userId]', $datum_editace, 0, 1)");
		$id_skl_prijemky = $sql->insert_id();
		
		$saved=1;
		echo "<p class=\"oznameni\">Nová příjemka vytvořena.</p>";
		
		$refresh_page=$page->_head_path . "?show=prijemka_edit&id_skl_prijemky=$id_skl_prijemky";
		echo "<meta http-equiv=\"refresh\" content=\"0; url=$refresh_page\">";
		message_auto_forward($refresh_page);
	} else if ($error!=""){
		echo "<hr /><b>" . $error . "</b><hr />";
	}
		
	if ($saved==0){
		?>
		<form action="" method="post" name="prijemka">
			<div style="text-align: center; padding: 5px; border-bottom: #aaa 1px dashed;">
				<input type="submit" name="save" value="Uložit rozpracované" id="ulozit-half" />
				<span style="padding-left: 100px">
					<a href="?show=prijemky" class="zpet">Zpět na příjemky (bez uložení)</a>
				</span>
			</div>
			<table cellspacing="0" cellpadding="5" border="0" width="100%" align="center">
				<tr>
					<td style="text-align: right"><b>Příjemka pro sklad</b> (*)</td>
					<td>
						<select name="id_skladu" >
							<OPTION value="0">Vyberte možnost...</OPTION>
							<?
							$result=$sql->query("SELECT id_skladu, nazev_skladu FROM sklady WHERE smazano=0 ORDER BY nazev_skladu");
							while ($row=$sql->fetch_array($result)){
								if ($row['id_skladu'] == $id_skladu){
									?>
									<OPTION value="<?echo $row['id_skladu'];?>" selected="selected"><?echo $row['nazev_skladu'];?></OPTION>
									<?
								} else {
									?>
									<OPTION value="<?echo $row['id_skladu'];?>"><?echo $row['nazev_skladu'];?></OPTION>
									<?
								}
							}
							?>
						</select>
					</td>
				</tr>
				<tr>
					<td style="text-align: right"><b>Dodavatelská firma</b> (*)</td>
					<td>
						<select name="id_firmy" >
							<OPTION value="0">Vyberte možnost...</OPTION>
							<?
							$result=$sql->query("SELECT id_firmy, nazev_firmy FROM firmy_dodavatelu WHERE smazano=0 ORDER BY nazev_firmy");
							while ($row=$sql->fetch_array($result)){
								if ($row['id_firmy'] == $id_firmy){
									?>
									<OPTION value="<?echo $row['id_firmy'];?>" selected="selected"><?echo $row['nazev_firmy'];?></OPTION>
									<?
								} else {
									?>
									<OPTION value="<?echo $row['id_firmy'];?>"><?echo $row['nazev_firmy'];?></OPTION>
									<?
								}
							}
							?>
						</select>
					</td>
				</tr>
			</table>
			<script type="text/javascript"> document.getElementById("nazev_skladu").focus(); </script>
		</form>
		<br /><br />(*) - povinné položky
		<?
	}
} else echo "<p class=\"chyba\">Na toto nemáte přiřazená práva.</p>";
?>
</div>