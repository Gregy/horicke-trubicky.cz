<style type="text/css">
	.pre{
		padding: 5px 20px 5px 20px;
		margin: 0px 15px 0px 15px;
		-webkit-border-radius: 6px;
		-moz-border-radius: 6px;
		-border-radius: 6px;
		background-color: #ffcccc;
		font-weight: bold;
		text-decoration: none;
	}
	
	.pri{
		padding: 5px 20px 5px 20px;
		margin: 0px 15px 0px 15px;
		-webkit-border-radius: 6px;
		-moz-border-radius: 6px;
		-border-radius: 6px;
		background-color: #ffe684;
		font-weight: bold;
		text-decoration: none;
	}
	
	.vyd{
		padding: 5px 20px 5px 20px;
		margin: 0px 15px 0px 15px;
		-webkit-border-radius: 6px;
		-moz-border-radius: 6px;
		-border-radius: 6px;
		background-color: #baeeff;
		font-weight: bold;
		text-decoration: none;
	}
	
	.skl{
		padding: 5px 20px 5px 20px;
		margin: 0px 15px 0px 15px;
		-webkit-border-radius: 6px;
		-moz-border-radius: 6px;
		-border-radius: 6px;
		background-color: #fbc1ff;
		font-weight: bold;
		text-decoration: none;
	}
</style>
<div style="padding-top: 10px; margin-bottom: 10px; width: 920px; text-align: center">
<?
if (haveRight('SKLADY')){
	?>
	<a href="?show=sklady_prehled" class="pre">Stav skladů</a>
	<?
}
if (haveRight('SKLADY_PRIJEMKY')){
	?>
	<a href="?show=prijemky" class="pri">Příjemky</a>
	<?
}
if (haveRight('SKLADY_VYDEJKY')){
	?>
	<a href="?show=vydejky" class="vyd">Výdejky</a>
	<?
}
if (haveRight('SKLADY_EDITACE')){
	?>
	<a href="?show=sklady" class="skl">Sklady</a>
	<?
}
?>
</div>