<div class="sklady">
<?
if (haveRight('SKLADY_EDITACE')){
	include_once 'script/sklady/submenu.php';
	
	if (isset($_GET['smaz_id'])){
		$datum_editace = Time();
		$sql->query("UPDATE sklady SET smazano=1, editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace' WHERE id_skladu=$_GET[smaz_id]");
	}
	?>
	<div style="width: 100%; text-align:center; padding-bottom: 5px; font-size: 15px;">
		<a href="?show=sklad_edit">Nový sklad</a>
	</div>
	<?
	$rows = $sql->query("SELECT s.id_skladu, s.nazev_skladu, s.datum_editace, u.name editoval FROM sklady s
							JOIN user u ON u.id_uzivatel = s.editoval
						WHERE s.smazano=0
						ORDER BY nazev_skladu");
						
	?>
	<table cellspacing="0" cellpadding="5" border="0" width="50%" align="center">
		<?
		$i=0;
		while ($row=$sql->fetch_array($rows)){
			(($i % 2)==0) ? $color="#fbc1ff" : $color="#fff5f5";
			$i++;
			$datum_editace = StrFTime("%d.%m.%Y %H:%M", $row['datum_editace']);
			?>
			<tr style="background-color: <?echo $color;?>;">
				<td>
					<?echo $row['nazev_skladu'];?>
				</td>
				<td>
					<a href="?show=sklad_edit&id_skladu=<?echo $row['id_skladu'];?>" style="text-decoration: none;" title="Naposledy editoval(a) <?echo $row['editoval'] . ' ' . $datum_editace;?>"><img src="files/edit.png" height="16px"></a>
				</td>
				<td style="width: 100px; text-align:center;">
					<span style="cursor: pointer;" id="odkaz_smazat_<?echo $row['id_skladu'];?>"	onClick="ukaz_form_smazat(<?echo $row['id_skladu'];?>)">
						<img src="files/smazat.png" height="16px">
					</span>
					<br />
					<span id="smazat_<?echo $row['id_skladu'];?>" style="display: none;">
						<a href="?show=sklady&smaz_id=<?echo $row['id_skladu'];?>">Ano</a>
						<a style="margin-left: 20px;" href="javascript:void(0)" onclick="skryj_form_smazat(<?echo $row['id_skladu'];?>)">Ne</a>
					</span>
				</td>
			</tr>
			<?
		}
		?>
	</table>
	<?
} else echo "<p class=\"chyba\">Na toto nemáte přiřazená práva.</p>";
?>
</div>