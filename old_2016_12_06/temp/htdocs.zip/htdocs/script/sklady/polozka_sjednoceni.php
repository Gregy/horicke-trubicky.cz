<div class="sklady">
<?
if (haveRight('SKLADY_POLOZKY_EDITACE')){
	if (isset($_GET['id_skl_polozky'])){
		global $sql;
		$temp = $sql->query_array("SELECT id_skl_polozky, id_skladu, nazev_skl_polozky, popis_skl_polozky, id_merna_jednotka FROM skl_polozky WHERE id_skl_polozky='$_GET[id_skl_polozky]'");
		$id_skl_polozky = $temp['id_skl_polozky'];
		$nazev_skl_polozky = $temp['nazev_skl_polozky'];
		$popis_skl_polozky = $temp['popis_skl_polozky'];
		$id_merna_jednotka = $temp['id_merna_jednotka'];
		$id_skladu = $temp['id_skladu'];
	}
	
	if ($_POST['save']=="Sjednotit"){
		$error="";
		if ($_POST['id_skl_polozky']==0)
			$error.="<p class=\"chyba\">Vyberte položku.</p>";
	}
	
	if ($error=="" && $_POST['save']=="Sjednotit"){
		$datum_editace = Time();
		$sql->query("UPDATE skl_polozky SET smazano=1, editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace' 
					WHERE id_skl_polozky=$id_skl_polozky");
		$sql->query("UPDATE skl_pri_materialy SET id_skl_polozky=$_POST[id_skl_polozky]
					WHERE id_skl_polozky=$id_skl_polozky");
		$sql->query("UPDATE skl_vyd_materialy SET id_skl_polozky=$_POST[id_skl_polozky]
					WHERE id_skl_polozky=$id_skl_polozky");
		
		$saved=1;
		echo "<p class=\"oznameni\">Položky byly sjednoceny.</p>";
		
		$refresh_page=$page->_head_path . "?show=sklady_prehled";
		echo "<meta http-equiv=\"refresh\" content=\"1; url=$refresh_page\">";
		message_auto_forward($refresh_page);
	} else if ($error!=""){
		echo "<hr /><b>" . $error . "</b><hr />";
	}
		
	if ($saved==0){
		?>
		<form action="" method="post" name="skl_polozka">
			<div style="text-align: center; padding: 5px; border-bottom: #aaa 1px dashed;">
				<input type="submit" name="save" value="Sjednotit" id="ulozit" />
				<span style="padding-left: 100px">
					<a href="?show=sklady_prehled" class="zpet">Zpět na přehled skladů (bez uložení)</a>
				</span>
			</div>
			
			<?php
				if (isset($id_skl_polozky)){
					?>
					<input type="hidden" name="id_skl_polozky" value="<?echo $id_skl_polozky;?>" />
					<?
				}
			?>
			<table cellspacing="0" cellpadding="5" border="0" width="100%" align="center">
				<tr>
					<td style="text-align: right"><b>Skladová položka</b></td>
					<td>
						<?echo $nazev_skl_polozky . "(" . $popis_skl_polozky . ")";?>
					</td>
				</tr>
				<tr>
					<td style="text-align: right"><b>Sjednotit k výrobku</b> (*)</td>
					<td>
						<select name="id_skl_polozky" >
							<OPTION value="0">Vyberte možnost...</OPTION>
							<?
							$result=$sql->query("SELECT id_skl_polozky, nazev_skl_polozky, popis_skl_polozky 
												FROM skl_polozky
												WHERE smazano=0 AND id_skladu=$id_skladu AND id_merna_jednotka=$id_merna_jednotka AND id_skl_polozky NOT IN ($id_skl_polozky)
												ORDER BY nazev_skl_polozky, popis_skl_polozky");
							while ($row=$sql->fetch_array($result)){
								if ($row['id_skl_polozky'] == $id_skl_polozky){
									?>
									<OPTION value="<?echo $row['id_skl_polozky'];?>" selected="selected"><?echo $row['nazev_skl_polozky'] . "(" . $row['popis_skl_polozky'] . ")";?></OPTION>
									<?
								} else {
									?>
									<OPTION value="<?echo $row['id_skl_polozky'];?>"><?echo $row['nazev_skl_polozky'] . "(" . $row['popis_skl_polozky'] . ")";?></OPTION>
									<?
								}
							}
							?>
						</select>
					</td>
				</tr>
			</table>
			<script type="text/javascript"> document.getElementById("nazev_skl_polozky").focus(); </script>
		</form>
		<br /><br />(*) - povinné položky
		<?
	}
} else echo "<p class=\"chyba\">Na toto nemáte přiřazená práva.</p>";
?>
</div>