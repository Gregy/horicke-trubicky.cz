<div class="sklady">
<?
if (haveRight('SKLADY')){
	if (isset($_GET['smaz_id']) && haveRight('SKLADY_POLOZKY_SMAZAT')){
		$datum_editace = Time();
		$sql->query("UPDATE skl_polozky SET smazano=1, editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace' WHERE id_skl_polozky=$_GET[smaz_id]");
	}
	
	if (isset($_GET['id_skladu'])){
		$_SESSION['filtr_skladu']['id_skladu'] = $_GET['id_skladu'];
	}
	if (isset($_GET['nazev_skl_pol'])){
		$_SESSION['filtr_skladu']['nazev_skl_pol'] = $_GET['nazev_skl_pol'];
	}
	if (isset($_GET['popis_skl_pol'])){
		$_SESSION['filtr_skladu']['popis_skl_pol'] = $_GET['popis_skl_pol'];
	}
	if (isset($_GET['zobrazit_vse'])){
		$_SESSION['filtr_skladu']['zobrazit_vse'] = $_GET['zobrazit_vse'];
	}
	
	if (isset($_GET['zrus_filtr'])){
		unset($_SESSION['filtr_skladu']);
	}
	if (!is_print_mod()){
		include_once 'script/sklady/submenu.php';
		?>
		<div style="width: 100%; text-align:center; padding-bottom: 5px; font-size: 15px;">
			<div class="sklady_prehled">
				<?
				if (haveRight('SKLADY_PRIJEMKY')){
					?>
					<a href="?show=prijemka_new" style="margin: 0 25px">Nová příjemka</a>
					<?
				}
				if (haveRight('SKLADY_VYDEJKY')){
					?>
					<a href="?show=vydejka_new" style="margin: 0 25px">Nová výdejka</a>
					<a href="?show=vydejka_kons_new" style="margin: 0 25px">Nová výdejka z kons.</a>
					<?
				}
				?>
			</div>
		</div>
		
		<div onclick="ukaz_skryj('filtr_skladu');" style="cursor: pointer;">
			Zobraz / skryj filtr
			<?
			if (!empty($_SESSION['filtr_skladu']['id_skladu']) || !empty($_SESSION['filtr_skladu']['nazev_skl_pol']) || !empty($_SESSION['filtr_skladu']['popis_skl_pol'])
				 || !empty($_SESSION['filtr_skladu']['zobrazit_vse'])){
					?> 
					<span style="padding-left: 200px; color: #D55; font-weight: bold;">Filtr je AKTIVNÍ</span>
					<a href="?show=sklady_prehled&zrus_filtr=1" style="margin-left: 200px; color: #555; font-weight: bold;">Zrušit filtr</a>
					<?
			}
			?>
		</div>
		<div id="filtr_skladu" style="display: none;">
			<form action="" method="GET">
				<input type="hidden" name="show" value="sklady_prehled">
				<table cellspacing="0" cellpadding="5" border="0" width="60%">
					<tr>
						<td>
							<b>Zobrazit sklad</b>
						</td>
						<td>
							<select id="id_skladu" name="id_skladu">
								<OPTION value="0">Vyberte možnost...</OPTION>
								<?
								$result=$sql->query("SELECT id_skladu, nazev_skladu FROM sklady
													WHERE smazano=0
													ORDER BY nazev_skladu");
								while ($row=$sql->fetch_array($result)){
									if ($row['id_skladu'] == $_SESSION['filtr_skladu']['id_skladu']){
										?>
										<OPTION value="<?echo $row['id_skladu'];?>" selected="selected"><?echo $row['nazev_skladu'];?></OPTION>
										<?
									} else {
										?>
										<OPTION value="<?echo $row['id_skladu'];?>"><?echo $row['nazev_skladu'];?></OPTION>
										<?
									}
								}
								?>
							</select>
						</td>
					</tr>
					<tr>
						<td>
							<b>Název skl.pol.</b>
						</td>
						<td>
							<input id="nazev_skl_pol" name="nazev_skl_pol" type="text" value="<?echo $_SESSION['filtr_skladu']['nazev_skl_pol'];?>" size="30" />
						</td>
					</tr>
					<tr>
						<td>
							<b>Popis skl.pol.</b>
						</td>
						<td>
							<input id="popis_skl_pol" name="popis_skl_pol" type="text" value="<?echo $_SESSION['filtr_skladu']['popis_skl_pol'];?>" size="30" />
						</td>
					</tr>
					<tr>
						<td>
							<b>Zobrazit nulové položky</b>
						</td>
						<td>
							<select id="zobrazit_vse" name="zobrazit_vse">
								<OPTION value="0">Ne</OPTION>
								<?
								if ($_SESSION['filtr_skladu']['zobrazit_vse']==1){
									?>
									<OPTION value="1" selected="selected">Ano</OPTION>
									<?
								} else {
									?>
									<OPTION value="1">Ano</OPTION>
									<?
								}
								?>
							</select>
						</td>
					</tr>
				</table>
				<div style="padding: 5px;">
					<input type="submit" name="save" value="Použít filtr" id="inform" />
				</div>
			</form>
		</div>
		<?
	} else {
		$datum_tisku = Time();
		$datum_tisku = StrFTime("%d.%m.%Y", $datum_tisku);
		?>
		<span style="font-weight: bold; font-size: 120%;">
			Obal-tisk, s.r.o. - stav skladu ke dni <?echo $datum_tisku;?>
		</span>
		<?
	}
	$prvni=false;
	if (isset($_SESSION['filtr_skladu'])){
		if (!empty($_SESSION['filtr_skladu']['id_skladu'])){
			($prvni==false) ? $where_skl .= " AND " : $where_skl .= "";
			$where_skl .= "id_skladu=" . $_SESSION['filtr_skladu']['id_skladu'];
			$prvni=false;
		}
		if (!empty($_SESSION['filtr_skladu']['nazev_skl_pol'])){
			($prvni==false) ? $where .= " AND " : $where .= "";
			$where .= "nazev_skl_polozky like '%" . $_SESSION['filtr_skladu']['nazev_skl_pol'] . "%'";
			$prvni=false;
		}
		if (!empty($_SESSION['filtr_skladu']['popis_skl_pol'])){
			($prvni==false) ? $where .= " AND " : $where .= "";
			$where .= "popis_skl_polozky like '%" . $_SESSION['filtr_skladu']['popis_skl_pol'] . "%'";
			$prvni=false;
		}
	} else {
		$where = "";
		$where_skl = "";
		$limit = "LIMIT 20";
	}

	$where_skl = " WHERE smazano=0 " . $where_skl;
	
	$sklady = $sql->query("SELECT id_skladu, nazev_skladu FROM sklady
						$where_skl
						ORDER BY nazev_skladu");
	
	while ($sklad=$sql->fetch_array($sklady)){
		$celkova_cena = 0;
		?>
		<div style="font-weight: bold; font-size: 120%; padding: 10px 0 5px 100px; color: #00F;">
			<?
			echo $sklad['nazev_skladu'];
			?>
		</div>
		<?
		$rows = $sql->query("SELECT sp.id_skl_polozky, sp.nazev_skl_polozky, sp.popis_skl_polozky, 
								(SELECT SUM( mnozstvi ) FROM skl_pri_materialy spm1 
									JOIN skl_prijemky sp1 ON sp1.id_skl_prijemky = spm1.id_skl_prijemky
									WHERE spm1.id_skl_polozky = sp.id_skl_polozky AND sp1.smazano = 0 AND sp1.rozpracovano = 0) prijate_mnozstvi, 
								(SELECT SUM( mnozstvi ) FROM skl_vyd_materialy svm1 
									JOIN skl_vydejky sv1 ON sv1.id_skl_vydejky = svm1.id_skl_vydejky 
									WHERE svm1.id_skl_polozky = sp.id_skl_polozky AND sv1.smazano = 0 AND sv1.rozpracovano = 0) vydane_mnozstvi,
								mj.zkratka_jednotky, s.konsignacni, sp.datum_editace, u.name editoval
							FROM skl_polozky sp
							JOIN sklady s ON s.id_skladu = sp.id_skladu
							LEFT JOIN merna_jednotka mj ON mj.id_merna_jednotka = sp.id_merna_jednotka
							JOIN user u ON u.id_uzivatel = sp.editoval
							WHERE sp.smazano = 0
							$where
							AND sp.id_skladu = $sklad[id_skladu]
							ORDER BY sp.nazev_skl_polozky, sp.popis_skl_polozky");
		?>
		<table cellspacing="0" cellpadding="5" border="0" width="99%" align="center">
			<tr style="font-size: 110%; font-weight: bold; vertical-align: bottom;">
				<td>
					Název položky
				</td>
				<td style="width: 200px;">
					Popis
				</td>
				<td style="text-align: right; width: 80px;">
					Počet
				</td>
				<td style="text-align: center; width: 80px;">
					Jednotka
				</td>
				<td style="text-align: right; width: 100px;">
					Jedn.cena<br>(v Kč)
				</td>
				<td style="text-align: right; width: 100px;">
					Celk.cena<br>(v Kč)
				</td>
				<?
				if (!is_print_mod()){
					?>
					<td style="width: 40px;"></td>
					<td style="width: 40px;"></td>
					<td style="width: 40px;"></td>
					<td></td>
					<?
				}
				?>
			</tr>
			<?
			$i=0;
			while ($row=$sql->fetch_array($rows)){
				if (($row['prijate_mnozstvi']-$row['vydane_mnozstvi'])>0 || $_SESSION['filtr_skladu']['zobrazit_vse']==1){
					(($i % 2)==0) ? $color="#ffcccc" : $color="#fff5f5";
					$i++;
					$datum_editace = StrFTime("%d.%m.%Y %H:%M", $row['datum_editace']);
					
					if ($row['konsignacni']==0){
						$temp = $sql->query("SELECT mnozstvi, cena FROM skl_pri_materialy spm 
											JOIN skl_prijemky sp ON sp.id_skl_prijemky = spm.id_skl_prijemky
											WHERE sp.smazano=0 AND sp.rozpracovano=0 AND spm.id_skl_polozky=$row[id_skl_polozky]
											ORDER BY sp.id_skl_prijemky DESC");
						$cena=0;
						$mnozstvi=0;
						while ($prijemka=$sql->fetch_array($temp)){
							$mnozstvi+=$prijemka['mnozstvi'];
							if ($mnozstvi <= ($row['prijate_mnozstvi']-$row['vydane_mnozstvi'])){
								$cena+=$prijemka['cena']*$prijemka['mnozstvi'];
							} else {
								$cena+=($prijemka['cena'])*($row['prijate_mnozstvi']-$row['vydane_mnozstvi']-($mnozstvi-$prijemka['mnozstvi']));
								break;
							}
						}
					} else {
						$cena=0;
						$mnozstvi=0;
						$temp = $sql->query("SELECT cislo_prijemky, rok, poznamka, mnozstvi, cena, 
												IFNULL((SELECT SUM(mnozstvi) FROM skl_vyd_materialy svm 
													JOIN skl_vydejky sv ON sv.id_skl_vydejky = svm.id_skl_vydejky 
													WHERE sv.id_skl_prijemky=sp.id_skl_prijemky AND sv.smazano=0 AND sv.rozpracovano=0), 0) vydano_na_prijemku
											FROM skl_pri_materialy spm 
											JOIN skl_prijemky sp ON sp.id_skl_prijemky = spm.id_skl_prijemky
											WHERE sp.smazano=0 AND sp.rozpracovano=0 AND spm.id_skl_polozky=$row[id_skl_polozky]
											ORDER BY sp.id_skl_prijemky DESC");
						while ($prijemka=$sql->fetch_array($temp)){
							$cena+=$prijemka['cena']*($prijemka['mnozstvi']-$prijemka['vydano_na_prijemku']);
							$mnozstvi+=$prijemka['mnozstvi']-$prijemka['vydano_na_prijemku'];
						}
					}
					?>
					<tr style="background-color: <?echo $color;?>;">
						<td>
							<?echo $row['nazev_skl_polozky'];?>
						</td>
						<td>
							<?echo $row['popis_skl_polozky'];?>
						</td>
						<td style="text-align: right;">
							<?
							if ($row['konsignacni']==0){
								$pocet = number_format($row['prijate_mnozstvi']-$row['vydane_mnozstvi'], 0, '.', ' ');
							} else {
								$pocet = number_format($mnozstvi, 0, '.', ' ');
							}
							echo $pocet;
							?>
						</td>
						<td style="text-align: center;">
							<?echo $row['zkratka_jednotky'];?>
						</td>
						<td style="text-align: right;">
							<?
							if ($row['konsignacni']==0){
								$jedn_cena = @number_format($cena/($row['prijate_mnozstvi']-$row['vydane_mnozstvi']), 2, '.', ' ');
							} else {
								$jedn_cena = @number_format($cena/$mnozstvi, 2, '.', ' ');
							}
							echo $jedn_cena;
							?>
						</td>
						<td style="text-align: right;">
							<?
							$celkova_cena+=$cena;
							$cena = number_format($cena, 0, '.', ' ');
							echo $cena;
							?>
						</td>
						<?
						if (!is_print_mod()){
							?>
							<td style="text-align: center;">
								<?
								if (haveRight('SKLADY_POLOZKY_SJEDNOCENI')){
									?>
									<a href="?show=polozka_sjednoceni&id_skl_polozky=<?echo $row['id_skl_polozky'];?>" style="text-decoration: none;" title="Sjednotit položku"><img src="files/sjednotit.png" height="16px"></a>
									<?
								}
								?>
							</td>
							<td style="text-align: center;">
								<?
								if (haveRight('SKLADY_POLOZKY_EDITACE')){
									?>
									<a href="?show=polozka_edit&id_skl_polozky=<?echo $row['id_skl_polozky'];?>" style="text-decoration: none;" title="Naposledy editoval(a) <?echo $row['editoval'] . ' ' . $datum_editace;?>"><img src="files/edit.png" height="16px"></a>
									<?
								}
								?>
							</td>
							<td style="text-align: center;">
								<?
								if ($row['konsignacni']==0){
									?>
									<a href="?show=polozka_spotrebovano&id_skl_polozky=<?echo $row['id_skl_polozky'];?>" style="text-decoration: none;" title="Stav položky dle příjemek"><img src="files/spotrebovano.png" height="16px"></a>
									<?
								} else {
									?>
									<a href="?show=polozka_kons_spotrebovano&id_skl_polozky=<?echo $row['id_skl_polozky'];?>" style="text-decoration: none;" title="Stav položky dle příjemek"><img src="files/spotrebovano.png" height="16px"></a>
									<?
								}
								?>
							</td>
							<td style="width: 100px; text-align:center;">
								<?
								if (haveRight('SKLADY_POLOZKY_SMAZAT')){
									?>
									<span style="cursor: pointer;" id="odkaz_smazat_<?echo $row['id_skl_polozky'];?>"	onClick="ukaz_form_smazat(<?echo $row['id_skl_polozky'];?>)">
										<img src="files/smazat.png" height="16px">
									</span>
									<br />
									<span id="smazat_<?echo $row['id_skl_polozky'];?>" style="display: none;">
										<a href="?show=sklady_prehled&smaz_id=<?echo $row['id_skl_polozky'];?>">Ano</a>
										<a style="margin-left: 20px;" href="javascript:void(0)" onclick="skryj_form_smazat(<?echo $row['id_skl_polozky'];?>)">Ne</a>
									</span>
									<?
								}
								?>
							</td>
							<?
						}
						?>
					</tr>
					<?
				}
			}
			?>
			<tr style="background-color: #AF6; text-align: right; font-weight: bold;">
				<td colspan=5>Celková cena na skladě</td>
				<td>
					<?
					$celkova_cena = number_format($celkova_cena, 0, '.', ' ');
					echo $celkova_cena;
					?>
				</td>
				<td></td>
				<td></td>
				<td></td>
			</tr>
		</table>
		<?
	}
} else echo "<p class=\"chyba\">Na toto nemáte přiřazená práva.</p>";
?>
</div>