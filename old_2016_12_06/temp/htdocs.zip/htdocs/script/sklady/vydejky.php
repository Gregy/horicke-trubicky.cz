<div class="sklady">
<script src="js/tooltip_wz/wz_tooltip.js" type="text/javascript"></script>
<?
if (haveRight('SKLADY_VYDEJKY')){
	if (isset($_GET['cislo_vydejky'])){
		$_SESSION['filtr_vydejek']['cislo_vydejky'] = $_GET['cislo_vydejky'];
	}
	if (isset($_GET['rok'])){
		$_SESSION['filtr_vydejek']['rok'] = $_GET['rok'];
	}
	if (isset($_GET['id_skl_polozky'])){
		$_SESSION['filtr_vydejek']['id_skl_polozky'] = $_GET['id_skl_polozky'];
	}
	
	if (isset($_GET['zrus_filtr'])){
		unset($_SESSION['filtr_vydejek']);
	}
	
	include_once 'script/sklady/submenu.php';
	
	?>
	<div style="width: 100%; text-align:center; padding-bottom: 5px; font-size: 15px;">
		<div class="vydejky">
			<?
			if (haveRight('SKLADY_VYDEJKY')){
				?>
				<a href="?show=vydejka_new" style="margin: 0 25px">Nová výdejka</a>
				<a href="?show=vydejka_kons_new" style="margin: 0 25px">Nová výdejka z kons.</a>
				<?
			}
			?>
		</div>
	</div>
	<?
	if (isset($_GET['smaz_id']) && haveRight('SKLADY_VYDEJKY_SMAZAT')){
		$datum_editace = Time();
		$sql->query("UPDATE skl_vydejky SET smazano=1, editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace' WHERE id_skl_vydejky=$_GET[smaz_id]");
	}
	?>
	<div onclick="ukaz_skryj('filtr_vydejek');" style="cursor: pointer;">
		Zobraz / skryj filtr
		<?
		if (!empty($_SESSION['filtr_vydejek']['cislo_vydejky']) || !empty($_SESSION['filtr_vydejek']['rok']) || !empty($_SESSION['filtr_vydejek']['id_skl_polozky'])){
				?> 
				<span style="padding-left: 200px; color: #D55; font-weight: bold;">Filtr je AKTIVNÍ</span>
				<a href="?show=vydejky&zrus_filtr=1" style="margin-left: 200px; color: #555; font-weight: bold;">Zrušit filtr</a>
				<?
		}
		?>
	</div>
	<div id="filtr_vydejek" style="display: none;">
		<form action="" method="GET">
			<input type="hidden" name="show" value="vydejky">
			<table cellspacing="0" cellpadding="5" border="0" width="60%">
				<tr>
					<td>
						<b>Číslo výdejky / rok</b>
					</td>
					<td>
						<input id="cislo_vydejky" name="cislo_vydejky" type="text" value="<?echo $_SESSION['filtr_vydejek']['cislo_vydejky'];?>" size="5" maxlength="5" />
						/
						<input id="rok" name="rok" type="text" value="<?echo $_SESSION['filtr_vydejek']['rok'];?>" size="5" maxlength="5" />
					</td>
				</tr>
				<tr>
					<td>
						<b>Skladová položka</b>
					</td>
					<td>
						<select id="id_skl_polozky" name="id_skl_polozky">
							<OPTION value="0">Vyberte možnost...</OPTION>
							<?
							$result=$sql->query("SELECT id_skl_polozky, nazev_skl_polozky, popis_skl_polozky FROM skl_polozky 
												WHERE smazano=0
												ORDER BY nazev_skl_polozky, popis_skl_polozky
												");
							while ($row=$sql->fetch_array($result)){
								if ($row['id_skl_polozky'] == $_SESSION['filtr_vydejek']['id_skl_polozky']){
									?>
									<OPTION value="<?echo $row['id_skl_polozky'];?>" selected="selected"><?echo $row['nazev_skl_polozky'] . " (" . $row['popis_skl_polozky'] . ")";?></OPTION>
									<?
								} else {
									?>
									<OPTION value="<?echo $row['id_skl_polozky'];?>"><?echo $row['nazev_skl_polozky'] . " (" . $row['popis_skl_polozky'] . ")";?></OPTION>
									<?
								}
							}
							?>
						</select>
					</td>
				</tr>
			</table>
			<div style="padding: 5px;">
				<input type="submit" name="save" value="Použít filtr" id="inform" />
			</div>
		</form>
	</div>
	<?
	$prvni=false;
	if (isset($_SESSION['filtr_vydejek'])){
		if (!empty($_SESSION['filtr_vydejek']['cislo_vydejky'])){
			($prvni==false) ? $where .= " AND " : $where .= "";
			$where .= "cislo_vydejky=" . $_SESSION['filtr_vydejek']['cislo_vydejky'];
			$prvni=false;
		}
		if (!empty($_SESSION['filtr_vydejek']['rok'])){
			($prvni==false) ? $where .= " AND " : $where .= "";
			$where .= "sv.rok=" . $_SESSION['filtr_vydejek']['rok'];
			$prvni=false;
		}
		if (!empty($_SESSION['filtr_vydejek']['id_skl_polozky'])){
			($prvni==false) ? $where .= " AND " : $where .= "";
			$where .= "id_skl_polozky=" . $_SESSION['filtr_vydejek']['id_skl_polozky'];
			$prvni=false;
		}
	} else {
		$where = "";
		$limit = "LIMIT 20";
	}
	
	$where = " WHERE sv.smazano=0 " . $where;
	
	$rows = $sql->query("SELECT DISTINCT sv.id_skl_vydejky, sv.cislo_vydejky, sv.rok, sv.datum_editace, u.name editoval, sv.rozpracovano, z.cislo_zakazky, z.rok rok_zakazky, sv.id_skl_prijemky,
							sp.rok rok_prijemky, sp.cislo_prijemky
							FROM skl_vydejky sv
							LEFT JOIN skl_vyd_materialy svm ON svm.id_skl_vydejky = sv.id_skl_vydejky
							LEFT JOIN skl_prijemky sp ON sp.id_skl_prijemky = sv.id_skl_prijemky
							JOIN zak_vyrobky zv ON zv.id_zak_vyrobku = sv.id_zak_vyrobku
							JOIN zakazky z ON z.id_zakazky = zv.id_zakazky
							JOIN user u ON u.id_uzivatel = sv.editoval
						$where
						ORDER BY sv.rok DESC, sv.cislo_vydejky DESC
						$limit");
	?>
	<table cellspacing="0" cellpadding="5" border="0" width="60%" align="center">
		<tr style="font-size: 110%; font-weight: bold; vertical-align: bottom;">
			<td>
				Datum výdeje
			</td>
			<td>
				Č.výdejky
			</td>
			<td>
				Vydáno na zakázku
			</td>
			<td>
				Vydáno na příjemku
			</td>
			<td></td>
			<td></td>
			<td></td>
		</tr>
		<?
		$i=0;
		while ($row=$sql->fetch_array($rows)){
			(($i % 2)==0) ? $color="#baeeff" : $color="#fff5f5";
			$i++;
			$datum_editace = StrFTime("%d.%m.%Y", $row['datum_editace']);
			?>
			<tr style="background-color: <?echo $color;?>;">
				<td>
					<?echo $datum_editace;?>
				</td>
				<td>
					<?echo $row['cislo_vydejky'] . "/" . $row['rok'];?>
				</td>
				<td>
					<?echo cislo_rok($row['cislo_zakazky'], $row['rok_zakazky']);?>
				</td>
				<td>
					<?
						if (!empty($row['id_skl_prijemky'])){
							$materialy = $sql->query("SELECT nazev_skl_polozky, popis_skl_polozky, mj.zkratka_jednotky, mnozstvi FROM skl_pri_materialy spm 
													LEFT JOIN merna_jednotka mj ON mj.id_merna_jednotka = spm.id_merna_jednotka
													WHERE id_skl_prijemky=$row[id_skl_prijemky]");
							$seznam_materialu = "<b>Materiály zadané do příjemky " . $row['cislo_prijemky'] . "/" . $row['rok_prijemky'] . "</b>";
							while ($material=$sql->fetch_array($materialy)){
								$seznam_materialu .= "<br />" . $material['nazev_skl_polozky'] . " - " . $material['popis_skl_polozky'] . " - " . number_format($material['mnozstvi'], 0, '.', ' ') . " " . $material['zkratka_jednotky'];
							}
							?>
							<span onmouseover="Tip('<?echo $seznam_materialu;?>')" onmouseout="UnTip()">
								<?
								echo $row['cislo_prijemky'] . "/" . $row['rok_prijemky'];
								?>
							</span>
							<?
						}
					?>
				</td>
				<td>
					<?					
					if ($row['rozpracovano']==0){	
						$materialy = $sql->query("SELECT nazev_skl_polozky, popis_skl_polozky, mj.zkratka_jednotky, mnozstvi FROM skl_vyd_materialy svm 
												LEFT JOIN merna_jednotka mj ON mj.id_merna_jednotka = svm.id_merna_jednotka
												WHERE id_skl_vydejky=$row[id_skl_vydejky]");
						$seznam_materialu = "<b>Materiály zadané do výdejky " . $row['cislo_vydejky'] . "/" . $row['rok'] . "</b>";
						while ($material=$sql->fetch_array($materialy)){
							$seznam_materialu .= "<br />" . $material['nazev_skl_polozky'] . " - " . $material['popis_skl_polozky'] . " - " . number_format($material['mnozstvi'], 0, '.', ' ') . " " . $material['zkratka_jednotky'];
						}
						?>
						<a href="?show=vydejka_show&id_skl_vydejky=<?echo $row['id_skl_vydejky'];?>" style="text-decoration: none;">
							<span onmouseover="Tip('<?echo $seznam_materialu;?>')" onmouseout="UnTip()">
								<img src="files/lupa.gif" height="16px" />
							</span>
						</a>
						<?
					}
					?>
				</td>
				<td>
					<?
					if ($row['rozpracovano']==1){	
						if ($row['id_skl_prijemky']==0){
							?>
							<a href="?show=vydejka_edit&id_skl_vydejky=<?echo $row['id_skl_vydejky'];?>" style="text-decoration: none;" title="Naposledy editoval(a) <?echo $row['editoval'] . ' ' . $datum_editace;?>"><img src="files/edit.png" height="16px"></a>
							<?
						} else {
							?>
							<a href="?show=vydejka_kons_edit&id_skl_vydejky=<?echo $row['id_skl_vydejky'];?>" style="text-decoration: none;" title="Naposledy editoval(a) <?echo $row['editoval'] . ' ' . $datum_editace;?>"><img src="files/edit.png" height="16px"></a>
							<?
						}
					}
					?>
				</td>
				<td style="width: 100px; text-align:center;">
					<?
					if (haveRight('SKLADY_VYDEJKY_SMAZAT')){
						?>
						<span style="cursor: pointer;" id="odkaz_smazat_<?echo $row['id_skl_vydejky'];?>"	onClick="ukaz_form_smazat(<?echo $row['id_skl_vydejky'];?>)">
							<img src="files/smazat.png" height="16px">
						</span>
						<br />
						<span id="smazat_<?echo $row['id_skl_vydejky'];?>" style="display: none;">
							<a href="?show=vydejky&smaz_id=<?echo $row['id_skl_vydejky'];?>">Ano</a>
							<a style="margin-left: 20px;" href="javascript:void(0)" onclick="skryj_form_smazat(<?echo $row['id_skl_vydejky'];?>)">Ne</a>
						</span>
						<?
					}
					?>
				</td>
			</tr>
			<?
		}
		?>
	</table>
	<?
} else echo "<p class=\"chyba\">Na toto nemáte přiřazená práva.</p>";
?>
</div>