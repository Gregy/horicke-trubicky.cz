<div class="sklady">
<?
if (haveRight('SKLADY_EDITACE')){
	if (isset($_GET['id_skladu'])){
		global $sql;
		$temp = $sql->query_array("SELECT id_skladu, nazev_skladu, konsignacni FROM sklady WHERE id_skladu='$_GET[id_skladu]'");
		$id_skladu = $temp['id_skladu'];
		$nazev_skladu = $temp['nazev_skladu'];
		$konsignacni = $temp['konsignacni'];
	}
	
	if ($_POST['save']=="Uložit"){
		$error="";
		if (isset($_POST['id_skladu']))
			$id_skladu = $_POST['id_skladu'];
		$nazev_skladu = $_POST['nazev_skladu'];
		(isset($_POST['konsignacni'])) ? $konsignacni=1 : $konsignacni=0;
		
		$error.=(empty($nazev_skladu)) ? "<p class=\"chyba\">Nebyl zadán název skladu.</p>" : "";
	}
	
	if ($error=="" && $_POST['save']=="Uložit"){
		$nazev_skladu=check_input($nazev_skladu);
		$datum_editace = Time();
		if (isset($id_skladu)){
			$sql->query("UPDATE sklady SET nazev_skladu='$nazev_skladu', konsignacni='$konsignacni', editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace' 
						WHERE id_skladu=$id_skladu");
		} else {
			$sql->query("INSERT INTO sklady VALUES (NULL, '$nazev_skladu', '$konsignacni', '$_SESSION[ot_userId]', '$datum_editace', '0')");
			$id_skladu=$sql->insert_id();
		}
		
		$saved=1;
		echo "<p class=\"oznameni\">Sklad v pořádku uložen.</p>";
		
		$refresh_page=$page->_head_path . "?show=sklady";
		echo "<meta http-equiv=\"refresh\" content=\"1; url=$refresh_page\">";
		message_auto_forward($refresh_page);
	} else if ($error!=""){
		echo "<hr /><b>" . $error . "</b><hr />";
	}
	
	if (isset($_GET['smaz_id'])){
		$datum_editace = Time();
		$sql->query("UPDATE adresy SET smazano=1, editoval='$_SESSION[ot_userId]', datum_editace=$datum_editace WHERE id_adresy=$_GET[smaz_id]");
	}
		
	if ($saved==0){
		?>
		<form action="" method="post" name="firma">
			<div style="text-align: center; padding: 5px; border-bottom: #aaa 1px dashed;">
				<input type="submit" name="save" value="Uložit" id="ulozit" />
				<span style="padding-left: 100px">
					<a href="?show=sklady" class="zpet">Zpět na seznam skladů (bez uložení)</a>
				</span>
			</div>
			
			<?php
				if (isset($id_skladu)){
					?>
					<input type="hidden" name="id_skladu" value="<?echo $id_skladu;?>" />
					<?
				}
			?>
			<table cellspacing="0" cellpadding="5" border="0" width="100%" align="center">
				<tr>
					<td style="text-align: right;"><b>Název skladu</b> (*)</td>
					<td colspan=2><input id="nazev_skladu" type="text" size="30" maxlength="100" name="nazev_skladu" value="<?php echo "$nazev_skladu";?>" /></td>
				</tr>
				<tr>
					<td style="text-align: right;"><b>Konsignační sklad</b></td>
					<td style="text-align: left;">
					<?
					if ($konsignacni==0){
						?>
						<input type="checkbox" name="konsignacni" />
						<?
					} else {
						?>
						<input type="checkbox" name="konsignacni" checked="checked" />
						<?
					}
					?>
					</td>
				</tr>
			</table>
			<script type="text/javascript"> document.getElementById("nazev_skladu").focus(); </script>
		</form>
		<br /><br />(*) - povinné položky
		<?
	}
} else echo "<p class=\"chyba\">Na toto nemáte přiřazená práva.</p>";
?>
</div>