<div class="sklady">
<script src="js/tooltip_wz/wz_tooltip.js" type="text/javascript"></script>
<?
if (haveRight('SKLADY')){
	if (isset($_GET['id_skl_polozky'])){
		$datum_tisku = Time();
		$datum_tisku = StrFTime("%d.%m.%Y", $datum_tisku);
		
		if (!is_print_mod()){
			?>
			<div style="text-align: center; padding: 5px; border-bottom: #aaa 1px dashed;">
				<span>
					<a href="?show=sklady_prehled" class="zpet">Zpět na přehled skladů</a>
				</span>
			</div>
			<?
		}
		?>
		<span style="font-weight: bold; font-size: 120%;">
			Obal-tisk, s.r.o. - stav skladové položky a jejích příjemek ke dni <?echo $datum_tisku;?>
		</span>
		<div style="font-weight: bold; font-size: 120%; padding: 10px 0 5px 100px; color: #00F;">
			<?
			echo $sklad['nazev_skladu'];
			?>
		</div>

		<table cellspacing="0" cellpadding="5" border="0" width="99%" align="center">
			<tr style="font-size: 110%; font-weight: bold; vertical-align: bottom;">
				<td style="width: 200px;">
					Název položky
				</td>
				<td style="width: 300px;">
					Popis
				</td>
				<td style="text-align: right; width: 80px;">
					Počet
				</td>
				<?
				if (!is_print_mod()){
					?>
					<td></td>
					<td></td>
					<td></td>
					<?
				}
				?>
			</tr>
			<?
			$i=0;
			$row=$sql->query_array("SELECT sp.id_skl_polozky, sp.nazev_skl_polozky, sp.popis_skl_polozky, mj.zkratka_jednotky
									FROM skl_polozky sp
									LEFT JOIN merna_jednotka mj ON mj.id_merna_jednotka = sp.id_merna_jednotka
									WHERE sp.smazano = 0
									AND sp.id_skl_polozky=$_GET[id_skl_polozky]
									ORDER BY sp.nazev_skl_polozky, sp.popis_skl_polozky");
			$cena=0;
			$mnozstvi=0;
			$temp = $sql->query("SELECT cislo_prijemky, rok, poznamka, mnozstvi, cena, 
									IFNULL((SELECT SUM(mnozstvi) FROM skl_vyd_materialy svm 
											JOIN skl_vydejky sv ON sv.id_skl_vydejky = svm.id_skl_vydejky 
											WHERE sv.id_skl_prijemky=sp.id_skl_prijemky AND sv.smazano=0 AND sv.rozpracovano=0), 0) vydano_na_prijemku
								FROM skl_pri_materialy spm 
								JOIN skl_prijemky sp ON sp.id_skl_prijemky = spm.id_skl_prijemky
								WHERE sp.smazano=0 AND sp.rozpracovano=0 AND spm.id_skl_polozky=$row[id_skl_polozky]
								ORDER BY sp.id_skl_prijemky DESC");
						while ($prijemka=$sql->fetch_array($temp)){
							$cena+=$prijemka['cena']*($prijemka['mnozstvi']-$prijemka['vydano_na_prijemku']);
							$mnozstvi+=$prijemka['mnozstvi']-$prijemka['vydano_na_prijemku'];
						}
				?>
				<tr>
					<td>
						<?echo $row['nazev_skl_polozky'];?>
					</td>
					<td>
						<?echo $row['popis_skl_polozky'];?>
					</td>
					<td style="text-align: right;">
						<?
						$pocet = number_format($mnozstvi, 0, '.', ' ');
						echo $pocet . " " . $row['zkratka_jednotky'];
						?>
					</td>
				</tr>
		</table>
		<hr />
		<table cellspacing="0" cellpadding="5" border="0" width="99%" align="center">
			<tr style="font-size: 110%; font-weight: bold; vertical-align: bottom;">
				<td style="text-align: center;">
					Číslo příjemky / rok
				</td>
				<td>
					Poznámka
				</td>
				<td style="text-align: center; width: 80px;">
					Množství naskladněno <br />(<?echo $row['zkratka_jednotky'];?>)
				</td>
				<td style="text-align: center; width: 80px;">
					Množství zůstatek <br />(<?echo $row['zkratka_jednotky'];?>)
				</td>
				<td style="text-align: right; width: 80px;">
					Jedn.cena<br>(v Kč)
				</td>
				<td style="text-align: right; width: 80px;">
					Zůst.celk.cena<br>(v Kč)
				</td>
				<td></td>
			</tr>
			<?
			$prijemky = $sql->query("SELECT cislo_prijemky, rok, poznamka, mnozstvi, cena, sp.id_skl_prijemky,
												IFNULL((SELECT SUM(mnozstvi) FROM skl_vyd_materialy svm 
													JOIN skl_vydejky sv ON sv.id_skl_vydejky = svm.id_skl_vydejky 
													WHERE sv.id_skl_prijemky=sp.id_skl_prijemky AND sv.smazano=0 AND sv.rozpracovano=0), 0) vydano_na_prijemku
											FROM skl_pri_materialy spm 
											JOIN skl_prijemky sp ON sp.id_skl_prijemky = spm.id_skl_prijemky
											WHERE sp.smazano=0 AND sp.rozpracovano=0 AND spm.id_skl_polozky=$row[id_skl_polozky]
											ORDER BY sp.id_skl_prijemky DESC");
			while ($prijemka=$sql->fetch_array($prijemky)){
				?>
				<tr>
					<td style="text-align: center;"><?echo $prijemka['cislo_prijemky'] . "/" . $prijemka['rok'];?></td>
					<td><?echo $prijemka['poznamka'];?></td>
					<td style="text-align: center;">
						<?
						$temp = number_format($prijemka['mnozstvi'], 0, '.', ' ');
						echo $temp;
						?>
					</td>
					<td style="text-align: center;">
						<?
						$temp = number_format($prijemka['mnozstvi']-$prijemka['vydano_na_prijemku'], 0, '.', ' ');
						echo $temp;
						?>
					</td>
					<td style="text-align: right;">
						<?
						$temp = number_format($prijemka['cena'], 2, '.', ' ');
						echo $temp;
						?>
					</td>
					<td style="text-align: right;">
						<?
						$temp = number_format($prijemka['cena']*($prijemka['mnozstvi']-$prijemka['vydano_na_prijemku']), 2, '.', ' ');
						echo $temp;
						?>
					</td>
				
				<?
				if (($prijemka['mnozstvi']-$prijemka['vydano_na_prijemku'])==0){
					$text="vyskladněno";
				} else if (($prijemka['mnozstvi']-$prijemka['vydano_na_prijemku']) < $prijemka['mnozstvi']){
					$text="částečně vyskladněno";
				} else {
					$text="na skladě";
				}
				
				$vydejky = $sql->query("SELECT cislo_vydejky, rok FROM skl_vydejky sv 
										JOIN skl_vyd_materialy svm ON svm.id_skl_vydejky = sv.id_skl_vydejky
										WHERE id_skl_polozky=$row[id_skl_polozky] AND sv.id_skl_prijemky=$prijemka[id_skl_prijemky] AND sv.smazano=0");
				
				?>
					<td>
						<?
						if ($sql->num_rows($vydejky)>0){
							$seznam_vydejek = "<b>Příjemka vydaná na výdejkách:</b>";
							while ($material=$sql->fetch_array($vydejky)){
								$seznam_vydejek .= "<br />" . $material['cislo_vydejky'] . "/" . $material['rok'];
							}
							?>
							<span onmouseover="Tip('<?echo $seznam_vydejek;?>')" onmouseout="UnTip()">
								<?
								echo $text;
								?>
							</span>
							<?
						} else {
							echo $text;
						}
						?>
					</td>
				</tr>
				<?
			}
			?>
			
		</table>
			<?
	}
} else echo "<p class=\"chyba\">Na toto nemáte přiřazená práva.</p>";
?>
</div>