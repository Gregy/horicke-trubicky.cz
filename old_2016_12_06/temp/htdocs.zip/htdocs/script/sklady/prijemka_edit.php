<div class="sklady">
<?
if (haveRight('SKLADY_PRIJEMKY')){
	
	if (isset($_GET['id_skl_prijemky'])){
		global $sql;
		$temp=$sql->query_array("SELECT id_skl_prijemky, s.id_skladu, cislo_prijemky, rok, nazev_firmy, sp.smazano, rozpracovano, poznamka, s.konsignacni
								FROM skl_prijemky sp
								JOIN sklady s ON s.id_skladu = sp.id_skladu
								WHERE id_skl_prijemky='$_GET[id_skl_prijemky]'");
		$id_skladu = $temp['id_skladu'];
		$id_skl_prijemky = $temp['id_skl_prijemky'];
		$cislo_prijemky = $temp['cislo_prijemky'];
		$rok = $temp['rok'];
		$nazev_firmy = $temp['nazev_firmy'];
		$smazano = $temp['smazano'];
		$rozpracovano = $temp['rozpracovano'];
		$poznamka = $temp['poznamka'];
		$konsignacni = $temp['konsignacni'];
		
		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		//uložení nového materiálu
		if (isset($_POST['save_new_material'])){
			$error_under="";
			if (isset($_POST['id_skl_prijemky']))
				$id_skl_prijemky = $_POST['id_skl_prijemky'];
			$id_materialu = $_POST['id_materialu'];
			
			$hodnota = $_POST['hodnota'];
			if (!isset($hodnota)){
				$hodnota=0;
			}
			$hodnota = str_replace(",", ".", $hodnota);
			
			$atributy = $sql->query("SELECT a.id_atributu, a.nazev_atributu FROM atributy a
									WHERE a.id_materialu=$id_materialu and a.smazano=0");
			if ($sql->num_rows($atributy)){
				while ($atribut=$sql->fetch_array($atributy)){
					$hodnoty_atributu[$atribut['id_atributu']] = $_POST["atribut$atribut[id_atributu]"];
				}
			}
			
			$error_under.=($id_materialu==0) ? "<p class=\"chyba\">Vyberte materiál.</p>" : "";
		}
		
		if ($error_under=="" && isset($_POST['save_new_material'])){
			$datum_editace = Time();
			
			$atributy = $sql->query("SELECT a.id_atributu, a.nazev_atributu, mj.zkratka_jednotky FROM atributy a
									LEFT JOIN merna_jednotka mj ON mj.id_merna_jednotka = a.id_merna_jednotka
									WHERE a.id_materialu=$id_materialu and a.smazano=0");
			if ($sql->num_rows($atributy)){
				$popis_materialu = "";
				$prvni=true;
				while ($atribut=$sql->fetch_array($atributy)){
					($prvni==false) ? $popis_materialu.=", " : $prvni=false;
					$hodnota_temp = $hodnoty_atributu[$atribut['id_atributu']];
					$popis_materialu.=$hodnota_temp . " " . $atribut['zkratka_jednotky'];
				}
			}
			$temp = $sql->query_array("SELECT nazev_materialu, id_merna_jednotka FROM materialy WHERE id_materialu=$id_materialu");
			$nazev_materialu = $temp['nazev_materialu'];
			$material_id_merna_jednotka = $temp['id_merna_jednotka'];
			
			$sql->query("INSERT INTO skl_polozky VALUES (NULL, '$id_skladu', '$nazev_materialu', '$popis_materialu', '$material_id_merna_jednotka', '$_SESSION[ot_userId]', $datum_editace, 0)");
			$id_skl_polozky = $sql->insert_id();
			$sql->query("INSERT INTO skl_pri_materialy VALUES (NULL, $id_skl_prijemky,  $id_skl_polozky,  '$nazev_materialu',  '$popis_materialu', '$material_id_merna_jednotka', 0, 0)");
			
			unset($atributy);
			unset($hodnoty_atributu);
			unset($id_materialu);
		} else if ($error_under!=""){
			echo "<hr /><b>" . $error_under . "</b><hr />";
		}
		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		//uložení existujícího materiálu
		if (isset($_POST['save_old_material'])){
			$error_under="";
			if ($_POST['old_id_skl_polozky']!=0)
				$old_id_skl_polozky = $_POST['old_id_skl_polozky'];
			else 
				$error_under.="<p class=\"chyba\">Vyberte skladovou položku.</p>";
		}
		
		if ($error_under=="" && isset($_POST['save_old_material'])){
			$sql->query("INSERT INTO skl_pri_materialy
						SELECT NULL, $id_skl_prijemky, id_skl_polozky, nazev_skl_polozky, popis_skl_polozky,id_merna_jednotka, 0, 0
						FROM skl_polozky WHERE id_skl_polozky=$old_id_skl_polozky");
		} else if ($error_under!=""){
			echo "<hr /><b>" . $error_under . "</b><hr />";
		}
		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		
		$skladove_polozky = $sql->query("SELECT id_skl_pri_materialu, mnozstvi, cena FROM skl_pri_materialy
											WHERE id_skl_prijemky=$id_skl_prijemky");
		if ($sql->num_rows($skladove_polozky)){
			while ($skladova_polozka=$sql->fetch_array($skladove_polozky)){
				$hodnoty_mnozstvi[$skladova_polozka['id_skl_pri_materialu']] = $skladova_polozka['mnozstvi'];
				$hodnoty_ceny[$skladova_polozka['id_skl_pri_materialu']] = $skladova_polozka['cena'];
			}
		}
	}
	
	if ($smazano==0 && $rozpracovano==1){
		if (isset($_POST['save']) || isset($_POST['save_half'])){
			$error="";
			$poznamka = $_POST['poznamka'];
			$skladove_polozky = $sql->query("SELECT id_skl_pri_materialu, nazev_skl_polozky, popis_skl_polozky FROM skl_pri_materialy
												WHERE id_skl_prijemky=$id_skl_prijemky");
			if ($sql->num_rows($skladove_polozky)){
				while ($skladova_polozka=$sql->fetch_array($skladove_polozky)){
					$mnozstvi_temp = $_POST["mnozstvi$skladova_polozka[id_skl_pri_materialu]"];
					$mnozstvi_temp = str_replace(",", ".", $mnozstvi_temp);
					$hodnoty_mnozstvi[$skladova_polozka['id_skl_pri_materialu']] = $mnozstvi_temp;
					if (isset($_POST['save']))
						$error.=(empty($mnozstvi_temp) || !is_numeric($mnozstvi_temp) || $mnozstvi_temp==0) ? "<p class=\"chyba\">U položky $skladova_polozka[nazev_skl_polozky] ($skladova_polozka[popis_skl_polozky]) je zadané špatné množství.</p>" : "";
					
					$cena_temp = $_POST["cena$skladova_polozka[id_skl_pri_materialu]"];
					$cena_temp = str_replace(",", ".", $cena_temp);
					$hodnoty_ceny[$skladova_polozka['id_skl_pri_materialu']] = $cena_temp;
					if (isset($_POST['save']))
						$error.=(empty($cena_temp) || !is_numeric($cena_temp)) ? "<p class=\"chyba\">U položky $skladova_polozka[nazev_skl_polozky] ($skladova_polozka[popis_skl_polozky]) je zadaná špatná cena.</p>" : "";
				}
			}
		}
		
		if ($error=="" && isset($_POST['save_half'])){
			$datum_editace = Time();
			$skladove_polozky = $sql->query("SELECT id_skl_pri_materialu, nazev_skl_polozky, popis_skl_polozky FROM skl_pri_materialy
												WHERE id_skl_prijemky=$id_skl_prijemky");
			if ($sql->num_rows($skladove_polozky)){
				while ($skladova_polozka=$sql->fetch_array($skladove_polozky)){
					$mnozstvi_temp = $hodnoty_mnozstvi[$skladova_polozka['id_skl_pri_materialu']];
					$cena_temp = $hodnoty_ceny[$skladova_polozka['id_skl_pri_materialu']];
					$sql->query("UPDATE skl_pri_materialy SET mnozstvi='$mnozstvi_temp', cena='$cena_temp' WHERE id_skl_pri_materialu=$skladova_polozka[id_skl_pri_materialu]");
				}
				$sql->query("UPDATE skl_prijemky SET poznamka='$poznamka', editoval='$_SESSION[ot_userId]', datum_editace=$datum_editace, rozpracovano=1 WHERE id_skl_prijemky=$id_skl_prijemky");
			}
			
			$saved=1;
			echo "<p class=\"oznameni\">Příjemka uložena jako rozpracovaná.</p>";
			$refresh_page=$page->_head_path . "?show=prijemky";
			echo "<meta http-equiv=\"refresh\" content=\"1; url=$refresh_page\">";
			message_auto_forward($refresh_page);
		}
		
		if ($error=="" && isset($_POST['save'])){
			$datum_editace = Time();
			$skladove_polozky = $sql->query("SELECT id_skl_pri_materialu, nazev_skl_polozky, popis_skl_polozky FROM skl_pri_materialy
												WHERE id_skl_prijemky=$id_skl_prijemky");
			if ($sql->num_rows($skladove_polozky)){
				while ($skladova_polozka=$sql->fetch_array($skladove_polozky)){
					$mnozstvi_temp = $hodnoty_mnozstvi[$skladova_polozka['id_skl_pri_materialu']];
					$cena_temp = $hodnoty_ceny[$skladova_polozka['id_skl_pri_materialu']];
					$sql->query("UPDATE skl_pri_materialy SET mnozstvi='$mnozstvi_temp', cena='$cena_temp' WHERE id_skl_pri_materialu=$skladova_polozka[id_skl_pri_materialu]");
				}
				$sql->query("UPDATE skl_prijemky SET poznamka='$poznamka', editoval='$_SESSION[ot_userId]', datum_editace=$datum_editace, rozpracovano=0 WHERE id_skl_prijemky=$id_skl_prijemky");
			}
			
			$saved=1;
			echo "<p class=\"oznameni\">Příjemka uložena jako hotová.</p>";
			$refresh_page=$page->_head_path . "?show=prijemka_show&id_skl_prijemky=$id_skl_prijemky";
			echo "<meta http-equiv=\"refresh\" content=\"1; url=$refresh_page\">";
			message_auto_forward($refresh_page);
		} else if ($error!=""){
			echo "<hr /><b>" . $error . "</b><hr />";
		}
		
		if (isset($_POST['cancel'])){
			$datum_editace = Time();
			$sql->query("DELETE FROM skl_pri_materialy WHERE id_skl_prijemky=$id_skl_prijemky");
			$sql->query("DELETE FROM skl_prijemky WHERE id_skl_prijemky=$id_skl_prijemky");
			
			$saved=1;
			echo "<p class=\"oznameni\">Příjemka zrušena.</p>";
			$refresh_page=$page->_head_path . "?show=prijemky";
			echo "<meta http-equiv=\"refresh\" content=\"1; url=$refresh_page\">";
			message_auto_forward($refresh_page);
		}
		
		if (isset($_GET['smaz_id'])){
			$datum_editace = Time();
			$sql->query("DELETE FROM skl_pri_materialy WHERE id_skl_pri_materialu=$_GET[smaz_id]");
		}
			
		if ($saved==0){
			?>
			<form action="" method="post" name="pri_skl_polozky">
				<div style="text-align: center; padding: 5px;">
					<input type="submit" name="save_half" value="Uložit rozpracované" id="ulozit-half" />
					<?
					if (isset($id_skl_prijemky)){
						?>
						<input type="submit" name="save" value="Uložit jako hotové" id="ulozit" />
						<?
					}
					if (isset($id_skl_prijemky)){
						?>
						<input type="submit" name="cancel" value="Zrušit příjemku" class="zpet" />
						<?
					}
					?>
				</div>
				<div style="font-weight: bold; font-size: 120%; text-align: left; padding: 5px; border-bottom: #aaa 1px dashed;">
					<?
					echo $nazev_firmy . " - číslo příjemky: " . $cislo_prijemky . "/" . $rok;
					?>
				</div>
				<div>
					Poznámka: <input type="text" size="50" maxlength="100" name="poznamka" id="poznamka"
						value="<?echo $poznamka?>"
						onblur="ajax('script/sklady/aj_poznamka.php?id_skl_prijemky=<?echo $id_skl_prijemky;?>&poznamka='+document.getElementById('poznamka').value,'poznamka_result');" />
					<span id="poznamka_result" style="width: 16px"></span>
				</td>
				<?
				if (isset($id_skl_prijemky)){
					$rows = $sql->query("SELECT spm. id_skl_pri_materialu, spm.id_skl_prijemky, spm.id_skl_polozky, spm.nazev_skl_polozky, spm.popis_skl_polozky, mj.zkratka_jednotky
										FROM skl_pri_materialy spm
										LEFT JOIN merna_jednotka mj ON mj.id_merna_jednotka = spm.id_merna_jednotka
										WHERE spm.id_skl_prijemky=$id_skl_prijemky");
					if ($sql->num_rows($rows)>0){
						?>
						
						<table cellspacing="0" cellpadding="5" border="0" width="95%" align="center">
							<tr style="text-align:center; background-color: <?echo $color;?>;">
									<td style="font-weight: bold;">
										Název materiálu
									</td>
									<td style="font-weight: bold;">
										Popis materiálu
									</td>
									<td style="font-weight: bold;">
										Jednotka
									</td>
									<td style="font-weight: bold; width: 90px;">
										Množství
									</td>
									<td style="font-weight: bold; width: 90px;">
										Jedn.cena (Kč)
									</td>
									<td style="width: 100px;">
										
									</td>
								</tr>
							<?
							$i=0;
							while ($row=$sql->fetch_array($rows)){
								(($i % 2)==0) ? $color="#DDD" : $color="#FFF";
								$i++;
								$datum_editace = StrFTime("%d.%m.%Y %H:%M", $row['datum_editace']);
								?>
								<tr style="text-align:center; background-color: <?echo $color;?>;">
									<td>
										<?echo $row['nazev_skl_polozky'];?>
									</td>
									<td>
										<?echo $row['popis_skl_polozky'];?>
									</td>
									<td>
										<?echo $row['zkratka_jednotky'];?>
									</td>
									<td style="text-align: left;">
										<input type="text" size="5" maxlength="9" name="mnozstvi<?echo $row['id_skl_pri_materialu'];?>" id="mnozstvi<?echo $row['id_skl_pri_materialu'];?>"
											value="<?echo $hodnoty_mnozstvi[$row['id_skl_pri_materialu']];?>"
											onblur="ajax('script/sklady/aj_mnozstvi.php?id_skl_pri_materialu=<?echo $row['id_skl_pri_materialu'];?>&mnozstvi='+document.getElementById('<?echo "mnozstvi" . $row['id_skl_pri_materialu'];?>').value,'mnozstvi_result<?echo $row['id_skl_pri_materialu'];?>');" />
										<span id="mnozstvi_result<?echo $row['id_skl_pri_materialu'];?>" style="width: 16px"></span>
									</td>
									<td style="text-align: left;">
										<input type="text" size="5" maxlength="9" name="cena<?echo $row['id_skl_pri_materialu'];?>" id="cena<?echo $row['id_skl_pri_materialu'];?>"
											value="<?echo $hodnoty_ceny[$row['id_skl_pri_materialu']];?>"
											onblur="ajax('script/sklady/aj_cena.php?id_skl_pri_materialu=<?echo $row['id_skl_pri_materialu'];?>&cena='+document.getElementById('<?echo "cena" . $row['id_skl_pri_materialu'];?>').value,'cena_result<?echo $row['id_skl_pri_materialu'];?>');" />
										<span id="cena_result<?echo $row['id_skl_pri_materialu'];?>" style="width: 16px"></span>
									</td>
									<td style="width: 100px;">
										<span style="cursor: pointer;" id="odkaz_smazat_<?echo $row['id_skl_pri_materialu'];?>"	onClick="ukaz_form_smazat(<?echo $row['id_skl_pri_materialu'];?>)"
										title="Vytvořil(a) <?echo $row['editoval'] . ' ' . $datum_editace;?>">
											<img src="files/smazat.png" height="16px">
										</span>
										<br />
										<span id="smazat_<?echo $row['id_skl_pri_materialu'];?>" style="display: none;">
											<a href="?show=prijemka_edit&id_skl_prijemky=<?echo $id_skl_prijemky;?>&smaz_id=<?echo $row['id_skl_pri_materialu'];?>">Ano</a>
											<a style="margin-left: 20px;" href="javascript:void(0)" onclick="skryj_form_smazat(<?echo $row['id_skl_pri_materialu'];?>)">Ne</a>
										</span>
									</td>
								</tr>
								<?
							}
							?>
						</table>
						<?
					}
				}
				?>
			</form>
			<?
			if (isset($id_skl_prijemky) && ($konsignacni==0 || $i==0)){
				?>
				<table>
					<tr>
						<td style="vertical-align: top">
							<form action="" method="post" name="novy_skl_material">
								<?
								if (isset($id_skl_prijemky)){
									?>
									<input type="hidden" name="id_skl_prijemky" value="<?echo $id_skl_prijemky;?>" />
									<?
								}
								?>
								<div style="text-align: left; margin-top: 20px; padding: 5px; border-bottom: #aaa 1px dashed;border-top: #aaa 1px dashed; width: 400px">
									<b>Založit novou skladovou položku<br />
									<select id="id_materialu" name="id_materialu" onchange="ajax('script/vyrobky/aj_nacist_atributy.php?id_materialu='+document.getElementById('id_materialu').value,'formular');">
										<OPTION value="0">Vyberte možnost...</OPTION>
										<?
										$result=$sql->query("SELECT m.id_materialu, m.nazev_materialu, mj.zkratka_jednotky FROM materialy m
															JOIN merna_jednotka mj ON m.id_merna_jednotka = mj.id_merna_jednotka
															WHERE m.smazano=0
															ORDER BY m.nazev_materialu");
										while ($row=$sql->fetch_array($result)){
											if ($row['id_materialu'] == $id_materialu){
												?>
												<OPTION value="<?echo $row['id_materialu'];?>" selected="selected"><?echo $row['nazev_materialu'] . ' (' . $row['zkratka_jednotky'] . ')';?></OPTION>
												<?
											} else {
												?>
												<OPTION value="<?echo $row['id_materialu'];?>"><?echo $row['nazev_materialu'] . ' (' . $row['zkratka_jednotky'] . ')';?></OPTION>
												<?
											}
										}
										?>
									</select>
									<div id="formular">
										<?
										if (isset($id_materialu)){
											$atributy = $sql->query("SELECT a.id_atributu, a.nazev_atributu, mj.zkratka_jednotky FROM atributy a
																	LEFT JOIN merna_jednotka mj ON mj.id_merna_jednotka=a.id_merna_jednotka
																	WHERE a.id_materialu=$id_materialu AND a.smazano=0");
											if ($sql->num_rows($atributy)){
												while ($atribut=$sql->fetch_array($atributy)){
													?>
													<table cellspacing="0" cellpadding="5" border="0" width="70%">
														<tr>
															<td style="font-weight: bold; width: 200px;">
																<?
																echo $atribut['nazev_atributu'];
																if (!empty($atribut['zkratka_jednotky'])) echo " (" . $atribut['zkratka_jednotky'] . ")";
																?>
																
															</td>
															<td style="text-align: left;">
																<?
																$hodnoty = $sql->query("SELECT id_hodnoty_atributu, hodnota_atributu FROM hodnoty_atributu
																						WHERE id_atributu=$atribut[id_atributu]");
																if ($sql->num_rows($hodnoty)>0){
																	?>
																	<select name="atribut<?echo $atribut['id_atributu'];?>">
																		<OPTION value="0">Vyberte možnost...</OPTION>
																		<?
																		while ($hodnota=$sql->fetch_array($hodnoty)){
																			if ($hodnota['hodnota_atributu'] == $hodnoty_atributu[$atribut['id_atributu']]){
																				?>
																				<OPTION value="<?echo $hodnota['hodnota_atributu'];?>" selected="selected"><?echo $hodnota['hodnota_atributu'];?></OPTION>
																				<?
																			} else {
																				?>
																				<OPTION value="<?echo $hodnota['hodnota_atributu'];?>"><?echo $hodnota['hodnota_atributu'];?></OPTION>
																				<?

																			}
																		}
																		?>
																	</select>
																	<?
																} else {
																	?>
																	<input type="text" size="20" maxlength="100" name="atribut<?echo $atribut['id_atributu'];?>" value="<?echo $hodnoty_atributu[$atribut['id_atributu']];?>" />
																	<?
																}
																?>
															</td>
														</tr>
													</table>
													<?
												}
											}
										}
										?>
									</div>
									<div>
										<input type="submit" name="save_new_material" value="Vložit materiál" id="ulozit" />
									</div>
								</div>
							</form>
						</td>
						<td style="vertical-align: top">
							<form action="" method="post" name="stavajici_skl_material">
								<div style="text-align: left; margin-top: 20px; padding: 5px; border-bottom: #aaa 1px dashed;border-top: #aaa 1px dashed;">
									<b>Existující skladové položky<br />
									<select name="old_id_skl_polozky" >
										<OPTION value="0">Vyberte možnost...</OPTION>
										<?
										$result=$sql->query("SELECT sp.id_skl_polozky, sp.nazev_skl_polozky, sp.popis_skl_polozky, mj.zkratka_jednotky FROM skl_polozky sp 
															JOIN merna_jednotka mj ON mj.id_merna_jednotka=sp.id_merna_jednotka
															WHERE id_skladu=$id_skladu and smazano=0 and id_skl_polozky NOT IN (SELECT id_skl_polozky FROM skl_pri_materialy WHERE id_skl_prijemky=$id_skl_prijemky)
															ORDER BY sp.nazev_skl_polozky, sp.popis_skl_polozky");
										while ($row=$sql->fetch_array($result)){
											?>
											<OPTION value="<?echo $row['id_skl_polozky'];?>"><?echo $row['nazev_skl_polozky'] . " (" . $row['popis_skl_polozky'] . ")";?></OPTION>
											<?
										}
										?>
									</select>
								<div>
								<input type="submit" name="save_old_material" value="Vložit materiál" id="ulozit" />
							</form>
						</td>
					</tr>
				</table>
				<?
			}
			?>
			(*) - povinné položky
			<script type="text/javascript"> document.getElementById("nazev_vyrobku").focus(); </script>
			<?php
		}
	} else {
		include_once 'script/sklady/submenu.php';
		echo "<p class=\"chyba\">Tato příjemka už nelze editovat.</p>";	
		$refresh_page=$page->_head_path . "?show=prijemka_show&id_skl_prijemky=$id_skl_prijemky";
		echo "<meta http-equiv=\"refresh\" content=\"1; url=$refresh_page\">";
	}
} else echo "<p class=\"chyba\">Na toto nemáte přiřazená práva.</p>";
?>
</div>