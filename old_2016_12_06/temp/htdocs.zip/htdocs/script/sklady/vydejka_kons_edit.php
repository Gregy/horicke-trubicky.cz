<div class="sklady">
<?
if (haveRight('SKLADY_VYDEJKY')){
	if (isset($_GET['id_skl_vydejky'])){
		global $sql;
		$temp=$sql->query_array("SELECT sv.id_skl_vydejky, sv.cislo_vydejky, sv.rok, sv.smazano, sv.rozpracovano, zv.nazev_vyrobku, z.nazev_firmy, z.cislo_zakazky, z.rok rok_z, sv.id_skl_prijemky
								FROM skl_vydejky sv
								JOIN zak_vyrobky zv ON zv.id_zak_vyrobku = sv.id_zak_vyrobku
								JOIN zakazky z ON z.id_zakazky = zv.id_zakazky
								WHERE id_skl_vydejky='$_GET[id_skl_vydejky]'");

		$id_skl_vydejky = $temp['id_skl_vydejky'];
		$cislo_vydejky = $temp['cislo_vydejky'];
		$rok_z = $temp['rok_z'];
		$smazano = $temp['smazano'];
		$rozpracovano = $temp['rozpracovano'];
		$nazev_vyrobku = $temp['nazev_vyrobku'];
		$nazev_firmy = $temp['nazev_firmy'];
		$cislo_zakazky = $temp['cislo_zakazky'];
		$rok = $temp['rok'];
		$id_skl_prijemky = $temp['id_skl_prijemky'];
		
		$skladove_polozky = $sql->query("SELECT id_skl_vyd_materialu, mnozstvi FROM skl_vyd_materialy
											WHERE id_skl_vydejky=$id_skl_vydejky");
		if ($sql->num_rows($skladove_polozky)){
			while ($skladova_polozka=$sql->fetch_array($skladove_polozky)){
				$hodnoty_mnozstvi[$skladova_polozka['id_skl_vyd_materialu']] = $skladova_polozka['mnozstvi'];
			}
		}
	}
	if ($smazano==0 && $rozpracovano==1){
		if (isset($_POST['save']) || isset($_POST['save_half'])){
			$error="";
			$skladove_polozky = $sql->query("SELECT id_skl_vyd_materialu, nazev_skl_polozky, popis_skl_polozky,
											IFNULL((SELECT SUM(mnozstvi) FROM skl_pri_materialy spm1 
												JOIN skl_prijemky sp1 ON sp1.id_skl_prijemky = spm1.id_skl_prijemky
												WHERE sp1.id_skl_prijemky = $id_skl_prijemky AND sp1.smazano = 0 AND sp1.rozpracovano = 0), 0) prijate_mnozstvi, 
											IFNULL((SELECT SUM( mnozstvi ) FROM skl_vyd_materialy svm1 
												JOIN skl_vydejky sv1 ON sv1.id_skl_vydejky = svm1.id_skl_vydejky 
												WHERE sv1.id_skl_prijemky = $id_skl_prijemky AND sv1.smazano = 0 AND sv1.rozpracovano = 0), 0) vydane_mnozstvi
											FROM skl_vyd_materialy spm
												WHERE id_skl_vydejky=$id_skl_vydejky");
			if ($sql->num_rows($skladove_polozky)){
				while ($skladova_polozka=$sql->fetch_array($skladove_polozky)){
					$mnozstvi_temp = $_POST["mnozstvi$skladova_polozka[id_skl_vyd_materialu]"];
					$mnozstvi_temp = str_replace(",", ".", $mnozstvi_temp);
					$hodnoty_mnozstvi[$skladova_polozka['id_skl_vyd_materialu']] = $mnozstvi_temp;
					if (isset($_POST['save'])){
						$error.=(empty($mnozstvi_temp) || !is_numeric($mnozstvi_temp) || $mnozstvi_temp==0) ? "<p class=\"chyba\">U položky $skladova_polozka[nazev_skl_polozky] ($skladova_polozka[popis_skl_polozky]) je zadané špatné množství.</p>" : "";
						$error.=($mnozstvi_temp>($skladova_polozka['prijate_mnozstvi'] - $skladova_polozka['vydane_mnozstvi'])) ? "<p class=\"chyba\">U položky $skladova_polozka[nazev_skl_polozky] ($skladova_polozka[popis_skl_polozky]) se snažíte vydat více, než je na příjemce.</p>" : "";
					}
				}
			}
		}
		
		if ($error=="" && isset($_POST['save_half'])){
			$datum_editace = Time();
			$skladove_polozky = $sql->query("SELECT id_skl_vyd_materialu, nazev_skl_polozky, popis_skl_polozky
											FROM skl_vyd_materialy 
												WHERE id_skl_vydejky=$id_skl_vydejky");
			if ($sql->num_rows($skladove_polozky)){
				while ($skladova_polozka=$sql->fetch_array($skladove_polozky)){
					$mnozstvi_temp = $hodnoty_mnozstvi[$skladova_polozka['id_skl_vyd_materialu']];
					$sql->query("UPDATE skl_vyd_materialy SET mnozstvi='$mnozstvi_temp' WHERE id_skl_vyd_materialu=$skladova_polozka[id_skl_vyd_materialu]");
				}
				$sql->query("UPDATE skl_vydejky SET editoval='$_SESSION[ot_userId]', datum_editace=$datum_editace, rozpracovano=1 WHERE id_skl_vydejky=$id_skl_vydejky");
			}
			
			$saved=1;
			echo "<p class=\"oznameni\">Výdejka uložena jako rozpracovaná.</p>";
			$refresh_page=$page->_head_path . "?show=vydejky";
			echo "<meta http-equiv=\"refresh\" content=\"1; url=$refresh_page\">";
			message_auto_forward($refresh_page);
		}
		
		if ($error=="" && isset($_POST['save'])){
			$datum_editace = Time();
			$skladove_polozky = $sql->query("SELECT id_skl_vyd_materialu, nazev_skl_polozky, popis_skl_polozky
											FROM skl_vyd_materialy 
												WHERE id_skl_vydejky=$id_skl_vydejky");
			if ($sql->num_rows($skladove_polozky)){
				while ($skladova_polozka=$sql->fetch_array($skladove_polozky)){
					$mnozstvi_temp = $hodnoty_mnozstvi[$skladova_polozka['id_skl_vyd_materialu']];
					$sql->query("UPDATE skl_vyd_materialy SET mnozstvi='$mnozstvi_temp' WHERE id_skl_vyd_materialu=$skladova_polozka[id_skl_vyd_materialu]");
				}
				$sql->query("UPDATE skl_vydejky SET editoval='$_SESSION[ot_userId]', datum_editace=$datum_editace, rozpracovano=0 WHERE id_skl_vydejky=$id_skl_vydejky");
			}
			
			$saved=1;
			echo "<p class=\"oznameni\">Výdejka uložena jako hotová.</p>";
			$refresh_page=$page->_head_path . "?show=vydejka_show&id_skl_vydejky=$id_skl_vydejky";
			echo "<meta http-equiv=\"refresh\" content=\"1; url=$refresh_page\">";
			message_auto_forward($refresh_page);
		} else if ($error!=""){
			echo "<hr /><b>" . $error . "</b><hr />";
		}
		
		if (isset($_POST['cancel'])){
			$datum_editace = Time();
			$sql->query("UPDATE skl_vydejky SET editoval='$_SESSION[ot_userId]', datum_editace=$datum_editace, smazano=1 WHERE id_skl_vydejky=$id_skl_vydejky");
			
			$saved=1;
			echo "<p class=\"oznameni\">Výdejka zrušena.</p>";
			$refresh_page=$page->_head_path . "?show=vydejky";
			echo "<meta http-equiv=\"refresh\" content=\"1; url=$refresh_page\">";
			message_auto_forward($refresh_page);
		}
		
		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		//uložení existujícího materiálu
		if (isset($_POST['save_old_material'])){
			$error_under="";
			if ($_POST['old_id_skl_polozky']!=0)
				$old_id_skl_polozky = $_POST['old_id_skl_polozky'];
			else 
				$error_under.="<p class=\"chyba\">Vyberte skladovou položku.</p>";
		}
		
		if ($error_under=="" && isset($_POST['save_old_material'])){
			$sql->query("INSERT INTO skl_vyd_materialy
						SELECT NULL, $id_skl_vydejky, id_skl_polozky, nazev_skl_polozky, popis_skl_polozky, id_merna_jednotka, 0
						FROM skl_polozky WHERE id_skl_polozky=$old_id_skl_polozky");
		} else if ($error_under!=""){
			echo "<hr /><b>" . $error_under . "</b><hr />";
		}
		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		
		if (isset($_GET['smaz_id'])){
			$datum_editace = Time();
			$sql->query("DELETE FROM skl_vyd_materialy WHERE id_skl_vyd_materialu=$_GET[smaz_id]");
		}
			
		if ($saved==0){
			?>
			<form action="" method="post" name="vyd_skl_polozky">
				<div style="text-align: center; padding: 5px;">
					<input type="submit" name="save_half" value="Uložit rozpracované" id="ulozit-half" />
					<?
					if (isset($id_skl_vydejky)){
						?>
						<input type="submit" name="save" value="Uložit jako hotové" id="ulozit" />
						<?
					}
					if (isset($id_skl_vydejky)){
						?>
						<input type="submit" name="cancel" value="Zrušit příjemku" class="zpet" />
						<?
					}
					?>
				</div>
				<div style="font-weight: bold; font-size: 120%; text-align: left; padding: 5px; border-bottom: #aaa 1px dashed;">
					<?
					echo $nazev_firmy . " - č.zak.: " . cislo_rok($cislo_zakazky, $rok_z) . " - číslo výdejky: " . $cislo_vydejky . "/" . $rok;
					?>
				</div>
				<?
				if (isset($id_skl_vydejky)){
					$rows = $sql->query("SELECT spm. id_skl_vyd_materialu, spm.id_skl_vydejky, spm.id_skl_polozky, spm.nazev_skl_polozky, spm.popis_skl_polozky, mj.zkratka_jednotky,
										IFNULL((SELECT SUM(mnozstvi) FROM skl_pri_materialy spm1 
										JOIN skl_prijemky sp1 ON sp1.id_skl_prijemky = spm1.id_skl_prijemky
										WHERE sp1.id_skl_prijemky = $id_skl_prijemky AND sp1.smazano = 0 AND sp1.rozpracovano = 0), 0) prijate_mnozstvi, 
										IFNULL((SELECT SUM( mnozstvi ) FROM skl_vyd_materialy svm1 
										JOIN skl_vydejky sv1 ON sv1.id_skl_vydejky = svm1.id_skl_vydejky 
										WHERE sv1.id_skl_prijemky = $id_skl_prijemky AND sv1.smazano = 0 AND sv1.rozpracovano = 0), 0) vydane_mnozstvi
										FROM skl_vyd_materialy spm
										LEFT JOIN merna_jednotka mj ON mj.id_merna_jednotka = spm.id_merna_jednotka
										WHERE spm.id_skl_vydejky=$id_skl_vydejky");
					if ($sql->num_rows($rows)>0){
						?>
						<table cellspacing="0" cellpadding="5" border="0" width="90%" align="center">
							<tr style="text-align:center; background-color: <?echo $color;?>;">
									<td style="font-weight: bold;">
										Název materiálu
									</td>
									<td style="font-weight: bold;">
										Popis materiálu
									</td>
									<td style="font-weight: bold;">
										Jednotka
									</td>
									<td style="font-weight: bold;">
										Na příjemce
									</td>
									<td style="font-weight: bold; width: 90px;">
										Množství
									</td>
									<td style="width: 100px;">
										
									</td>
								</tr>
							<?
							$i=0;
							while ($row=$sql->fetch_array($rows)){
								(($i % 2)==0) ? $color="#DDD" : $color="#FFF";
								$i++;
								$datum_editace = StrFTime("%d.%m.%Y %H:%M", $row['datum_editace']);
								?>
								<tr style="text-align:center; background-color: <?echo $color;?>;">
									<td>
										<?echo $row['nazev_skl_polozky'];?>
									</td>
									<td>
										<?echo $row['popis_skl_polozky'];?>
									</td>
									<td>
										<?echo $row['zkratka_jednotky'];?>
									</td>
									<td>
										<?echo $row['prijate_mnozstvi']-$row['vydane_mnozstvi'];?>
									</td>
									<td style="text-align: left;">
										<input type="text" size="5" maxlength="9" name="mnozstvi<?echo $row['id_skl_vyd_materialu'];?>" id="mnozstvi<?echo $row['id_skl_vyd_materialu'];?>"
											value="<?echo $hodnoty_mnozstvi[$row['id_skl_vyd_materialu']];?>"
											onchange="ajax('script/sklady/aj_mnozstvi_vyd.php?id_skl_vyd_materialu=<?echo $row['id_skl_vyd_materialu'];?>&mnozstvi='+document.getElementById('<?echo "mnozstvi" . $row['id_skl_vyd_materialu'];?>').value,'mnozstvi_result<?echo $row['id_skl_vyd_materialu'];?>');" />
										<span id="mnozstvi_result<?echo $row['id_skl_vyd_materialu'];?>" style="width: 16px"></span>
									</td>
									<td style="width: 100px;">
										<span style="cursor: pointer;" id="odkaz_smazat_<?echo $row['id_skl_vyd_materialu'];?>"	onClick="ukaz_form_smazat(<?echo $row['id_skl_vyd_materialu'];?>)"
										title="Vytvořil(a) <?echo $row['editoval'] . ' ' . $datum_editace;?>">
											<img src="files/smazat.png" height="16px">
										</span>
										<br />
										<span id="smazat_<?echo $row['id_skl_vyd_materialu'];?>" style="display: none;">
											<a href="?show=vydejka_kons_edit&id_skl_vydejky=<?echo $id_skl_vydejky;?>&smaz_id=<?echo $row['id_skl_vyd_materialu'];?>">Ano</a>
											<a style="margin-left: 20px;" href="javascript:void(0)" onclick="skryj_form_smazat(<?echo $row['id_skl_vyd_materialu'];?>)">Ne</a>
										</span>
									</td>
								</tr>
								<?
							}
							?>
						</table>
						<?
					}
				}
				?>
			</form>
			<?
			if (isset($id_skl_vydejky)){
				$result=$sql->query("SELECT sp.id_skl_polozky, sp.nazev_skl_polozky, sp.popis_skl_polozky, mj.zkratka_jednotky
									FROM skl_polozky sp 
									LEFT JOIN merna_jednotka mj ON mj.id_merna_jednotka=sp.id_merna_jednotka
									WHERE smazano=0 
									AND id_skl_polozky NOT IN (SELECT id_skl_polozky FROM skl_vyd_materialy WHERE id_skl_vydejky=$id_skl_vydejky)
									AND id_skl_polozky IN (SELECT id_skl_polozky FROM skl_pri_materialy WHERE id_skl_prijemky=$id_skl_prijemky)");
				
				if ($sql->num_rows($result)>0){
					?>
					<div style="text-align: left; margin-top: 20px; padding: 5px; border-bottom: #aaa 1px dashed;border-top: #aaa 1px dashed;">
						<form action="" method="post" name="stavajici_skl_material">						
								<b>Existující skladové položky<br />
								<select name="old_id_skl_polozky" >
									<OPTION value="0">Vyberte možnost...</OPTION>
									<?
									while ($row=$sql->fetch_array($result)){
										?>
										<OPTION value="<?echo $row['id_skl_polozky'];?>"><?echo $row['nazev_skl_polozky'] . " (" . $row['popis_skl_polozky'] . ")";?></OPTION>
										<?
									}
									?>
								</select>
								<br/>
							<input type="submit" name="save_old_material" value="Vložit materiál" id="ulozit" />
						</form>
					</div>
					<?
				}
			}
			?>
			(*) - povinné položky
			<script type="text/javascript"> document.getElementById("nazev_vyrobku").focus(); </script>
			<?php
		}
	} else {
		include_once 'script/sklady/submenu.php';
		echo "<p class=\"chyba\">Tato výdejka už nelze editovat.</p>";	
		$refresh_page=$page->_head_path . "?show=vydejka_show&id_skl_vydejky=$id_skl_vydejky";
		echo "<meta http-equiv=\"refresh\" content=\"1; url=$refresh_page\">";
	}
} else echo "<p class=\"chyba\">Na toto nemáte přiřazená práva.</p>";
?>
</div>