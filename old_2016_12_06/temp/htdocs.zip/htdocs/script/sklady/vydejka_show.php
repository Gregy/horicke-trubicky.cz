<?
if (haveRight('SKLADY_VYDEJKY')){
	if (isset($_GET['id_skl_vydejky'])){
		global $sql;
		$temp=$sql->query_array("SELECT sv.id_skl_vydejky, sv.cislo_vydejky, sv.rok, sv.smazano, sv.rozpracovano, zv.nazev_vyrobku, z.nazev_firmy, z.cislo_zakazky, z.rok rok_z, sv.datum_editace, u.name editoval, z.id_zakazky
								FROM skl_vydejky sv
								LEFT JOIN zak_vyrobky zv ON zv.id_zak_vyrobku = sv.id_zak_vyrobku
								LEFT JOIN zakazky z ON z.id_zakazky = zv.id_zakazky
								JOIN user u ON u.id_uzivatel = sv.editoval
								WHERE id_skl_vydejky='$_GET[id_skl_vydejky]'");
		$smazano = $temp['smazano'];
		$rozpracovano = $temp['rozpracovano'];
	}
	$datum_editace = StrFTime("%d.%m.%Y", $temp['datum_editace']);
	if ($smazano==0 && $rozpracovano==0){
		if (!is_print_mod()){
			?>
			<div style="text-align: center; padding: 5px; border-bottom: #aaa 1px dashed;">
				<span>
					<a href="?show=vydejky" class="zpet">Do výdejek</a>
				</span>
				<span style="padding-left: 100px">
					<a href="?show=zakazka_show&id_zakazky=<?echo $temp['id_zakazky'];?>" class="zpet">Do zakázky</a>
				</span>
			</div>
			<?
		}
		?>
		<table cellspacing="0" cellpadding="5" border="1" width="95%" align="center">
			<tr style="text-align: center; font-size: 22px; font-weigt: bold;">
				<td colspan=4>
					<img src="files/logo_velke.png" height="100px" /><br />
					<span style="padding-right: 200px;">Výdejka</span>
					<span>Číslo: <?echo $temp['cislo_vydejky'] . "/" . $temp['rok']; ?></span>
				</td>
			</tr>
			<tr style="font-size: 14px; vertical-align: top;">
				<td style="font-weight: bold;">
					Zakázka, pro firmu, výrobek:
				</td>
				<td colspan=3>
					<?
					echo $temp['nazev_firmy'] . " - č.zak.: " . cislo_rok($temp['cislo_zakazky'], $temp['rok_z']) . " - číslo výdejky: " . $temp['cislo_vydejky'] . "/" . $temp['rok'];
					?>
				</td>
			</tr>
			
			<tr>
				<td colspan=4>
				</td>
			</tr>
			<tr style="font-size: 12px; vertical-align: top; font-weight: bold;">
				<td>
					Položka č.
				</td>
				<td>
					Název materiálu
				</td>
				<td>
					Množství
				</td>
				<td>
					Ze skladu
				</td>
			</tr>
			<?
			$pocet_polozek = 1;
			$materialy = $sql->query("SELECT svm.nazev_skl_polozky, svm.popis_skl_polozky, mj.zkratka_jednotky, svm.mnozstvi, s.nazev_skladu FROM skl_vyd_materialy svm
									LEFT JOIN merna_jednotka mj ON mj.id_merna_jednotka=svm.id_merna_jednotka
									JOIN skl_polozky sp on sp.id_skl_polozky = svm.id_skl_polozky
									JOIN sklady s ON s.id_skladu = sp.id_skladu
									WHERE id_skl_vydejky='$_GET[id_skl_vydejky]'");
			while ($material = $sql->fetch_array($materialy)){
				?>
				<tr style="font-size: 12px; vertical-align: top;">
					<td>
						<?echo $pocet_polozek;?>
					</td>
					<td>
						<?
						echo $material['nazev_skl_polozky'] . " - " . $material['popis_skl_polozky'];
						?>
					</td>
					<td>
						<?
						echo $material['mnozstvi'] . " " . $material['zkratka_jednotky'];
						?>
					</td>
					<td>
						<?echo $material['nazev_skladu'];?>
					</td>
				</tr>
				<?
				$pocet_polozek++;
			}
			if ($temp['pocet_europalet']>0){
				?>
				<tr style="font-size: 12px; vertical-align: top;">
					<td>
						<?echo $pocet_polozek;?>
					</td>
					<td>
						Europalet
					</td>
					<td>
						<?echo $temp['pocet_europalet'];?>
					</td>
					<td>
						
					</td>
				</tr>
				<?
				$pocet_polozek++;
			}
			?>
			<tr>
				<td colspan=4>
				</td>
			</tr>
			<tr style="font-size: 12px; vertical-align: top;">
				<td>
					Datum vystavení:
				</td>
				<td>
					<?
					echo $datum_editace;
					?>
				</td>
				<td>
					Vystavil(a):
				</td>
				<td>
					<?
					echo $temp['editoval'];
					?>
				</td>
			</tr>
		</table>
		<?
	} else {
		include_once 'script/sklady/submenu.php';
		echo "<p class=\"chyba\">Tato výdejka je rozpracovaná.</p>";	
		$refresh_page=$page->_head_path . "?show=vydejka_edit&id_skl_vydejky=$id_skl_vydejky";
		echo "<meta http-equiv=\"refresh\" content=\"1; url=$refresh_page\">";
	}
}
?>