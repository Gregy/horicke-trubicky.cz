<?
	require_once '../../classes/class_mysql.php';
		$sql=new mysql;

	require_once '../../classes/class_user.php';
		$user=new classUser;
	
	require_once "../../includes/common.php";

	if (isset($_GET['poznamka']) && isset($_GET['id_skl_prijemky']) && haveRight('SKLADY_PRIJEMKY')){
		$sql->query("UPDATE skl_prijemky SET poznamka='$_GET[poznamka]' WHERE id_skl_prijemky=$_GET[id_skl_prijemky]");
		?>
		<img src="../../files/ok.png" height="13px" />
		<?
	}
?>