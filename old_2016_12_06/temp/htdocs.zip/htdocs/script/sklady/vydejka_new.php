<div class="sklady">
<?
if (haveRight('SKLADY_VYDEJKY')){
	if (isset($_GET['id_zakazky'])){
		$temp = $sql->query("SELECT id_zakazky FROM zakazky
							WHERE id_stavu<600");
		if ($sql->num_rows($temp)>0){
			$temp = $sql->fetch_array($temp);
			$id_zakazky = $temp['id_zakazky'];
		}
	}
	if (isset($_GET['id_zak_vyrobku'])){
		$temp = $sql->query("SELECT zv.id_zakazky, zv.id_zak_vyrobku FROM zak_vyrobky zv
							JOIN zakazky z ON z.id_zakazky = zv.id_zakazky
							WHERE zv.id_zak_vyrobku=$_GET[id_zak_vyrobku] AND id_stavu<600");
		if ($sql->num_rows($temp)>0){
			$temp = $sql->fetch_array($temp);
			$id_zak_vyrobku = $temp['id_zak_vyrobku'];
			$id_zakazky = $temp['id_zakazky'];
		}
	}
	if (isset($_POST['save'])){
		$error="";
		if ($_POST['id_zakazky']!=0){
			$id_zakazky = $_POST['id_zakazky'];
			$id_zak_vyrobku = 0;
		} else 
			$error.="<p class=\"chyba\">Vyberte zakázku, pro kterou chcete vytvořit výdejku.</p>";
		
		if ($_POST['id_zak_vyrobku']!=0)
			$id_zak_vyrobku = $_POST['id_zak_vyrobku'];
		else 
			$error.="<p class=\"chyba\">Vyberte výrobek, pro který chcete vytvořit výdejku.</p>";
	}
	
	if ($error=="" && isset($_POST['save'])){
		$datum_editace = Time();
		$rok = date('Y');
		$max_cislo_vydejky = $sql->query_array("SELECT max(cislo_vydejky) cislo FROM skl_vydejky WHERE rok=$rok");
		if ($max_cislo_vydejky['cislo']>0) 
			$max_cislo_vydejky = $max_cislo_vydejky['cislo']+1;
		else
			$max_cislo_vydejky = 1;
		$sql->query("INSERT INTO skl_vydejky VALUES (NULL, $id_zak_vyrobku, '$max_cislo_vydejky', '$rok', 0, '$_SESSION[ot_userId]', $datum_editace, 0, 1)");
		$id_skl_vydejky = $sql->insert_id();
		
		$saved=1;
		echo "<p class=\"oznameni\">Nová výdejka vytvořena.</p>";
		
		$refresh_page=$page->_head_path . "?show=vydejka_edit&id_skl_vydejky=$id_skl_vydejky";
		echo "<meta http-equiv=\"refresh\" content=\"0; url=$refresh_page\">";
		message_auto_forward($refresh_page);
	} else if ($error!=""){
		echo "<hr /><b>" . $error . "</b><hr />";
	}
		
	if ($saved==0){
		?>
		<form action="" method="post" name="vydejka">
			<div style="text-align: center; padding: 5px; border-bottom: #aaa 1px dashed;">
				<input type="submit" name="save" value="Uložit rozpracované" id="ulozit-half" />
				<span style="padding-left: 100px">
					<a href="?show=vydejky" class="zpet">Zpět na výdejky (bez uložení)</a>
				</span>
			</div>
			<h3>Výdejka z normálních skladů</h3>
			<table cellspacing="0" cellpadding="5" border="0" width="100%" align="center">
				<tr>
					<td style="text-align: right"><b>Výdejka pro zakázku</b> (*)</td>
					<td>
						<select id="id_zakazky" name="id_zakazky" onchange="ajax('script/sklady/aj_nacist_vyrobky.php?id_zakazky='+document.getElementById('id_zakazky').value,'vyrobky');">
							<OPTION value="0">Vyberte možnost...</OPTION>
							<?
							$result=$sql->query("SELECT id_zakazky, cislo_zakazky, rok, nazev_firmy FROM zakazky 
												WHERE id_stavu<600
												ORDER BY nazev_firmy");
							while ($row=$sql->fetch_array($result)){
								if ($row['id_zakazky'] == $id_zakazky){
									?>
									<OPTION value="<?echo $row['id_zakazky'];?>" selected="selected"><?echo $row['nazev_firmy'] . " - č.z." . cislo_rok($row['cislo_zakazky'], $row['rok']);;?></OPTION>
									<?
								} else {
									?>
									<OPTION value="<?echo $row['id_zakazky'];?>"><?echo $row['nazev_firmy'] . " - č.z." . cislo_rok($row['cislo_zakazky'], $row['rok']);;?></OPTION>
									<?
								}
							}
							?>
						</select>
					</td>
				</tr>
				<tr>
					<td style="text-align: right"><b>Výrobek ze zakázky</b> (*)</td>
					<td id="vyrobky">
						<select name="id_zak_vyrobku" >
							<OPTION value="0">Vyberte možnost...</OPTION>
							<?
							$result=$sql->query("SELECT id_zak_vyrobku, nazev_vyrobku
												FROM zak_vyrobky
												WHERE smazano=0 and id_zakazky=$id_zakazky
												ORDER BY nazev_vyrobku");
							while ($row=$sql->fetch_array($result)){
								if ($row['id_zak_vyrobku'] == $id_zak_vyrobku){
									?>
									<OPTION value="<?echo $row['id_zak_vyrobku'];?>" selected="selected"><?echo $row['nazev_vyrobku'];?></OPTION>
									<?
								} else {
									?>
									<OPTION value="<?echo $row['id_zak_vyrobku'];?>"><?echo $row['nazev_vyrobku'];?></OPTION>
									<?
								}
							}
							?>
						</select>
					</td>
				</tr>
			</table>
		</form>
		<br /><br />(*) - povinné položky
		<?
	}
} else echo "<p class=\"chyba\">Na toto nemáte přiřazená práva.</p>";
?>
</div>