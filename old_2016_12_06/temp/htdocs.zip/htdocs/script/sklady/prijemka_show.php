<?
if (haveRight('SKLADY_PRIJEMKY')){
	if (isset($_GET['id_skl_prijemky'])){
		global $sql;
		$temp=$sql->query_array("SELECT sp.cislo_prijemky, sp.rok, sp.datum_editace, sp.nazev_firmy, u.name editoval, s.nazev_skladu,
									fd.nazev_firmy, fd.ulice, fd.mesto, fd.psc, fd.stat, fd.telefon, fd.email, fd.ic, fd.dic, fd.bank_uc_pred, fd.bank_uc_za, fd.spec_symb, fd.kontaktni_osoba,
									sp.poznamka
								FROM skl_prijemky sp
								JOIN firmy_dodavatelu fd ON fd.id_firmy = sp.id_firmy
								JOIN sklady s ON s.id_skladu = sp.id_skladu
								JOIN user u ON u.id_uzivatel = sp.editoval
								WHERE sp.id_skl_prijemky = '$_GET[id_skl_prijemky]'");
		$smazano = $temp['smazano'];
		$rozpracovano = $temp['rozpracovano'];
	}
	if ($smazano==0 && $rozpracovano==0){
		$datum_editace = StrFTime("%d.%m.%Y", $temp['datum_editace']);
		
		if (!is_print_mod()){
			?>
			<div style="text-align: center; padding: 5px; border-bottom: #aaa 1px dashed;">
				<span style="padding-left: 100px">
					<a href="?show=prijemky" class="zpet">Zpět do příjemek</a>
				</span>
			</div>
			<?
		}
		?>
		<table cellspacing="0" cellpadding="5" border="1" width="95%" align="center">
			<tr style="text-align: center; font-size: 22px; font-weigt: bold;">
				<td colspan="4">
					<img src="files/logo_velke.png" height="100px" /><br />
					<span style="padding-right: 200px;">Příjemka</span>
					<span>Číslo: <?echo $temp['cislo_prijemky'] . "/" . $temp['rok']; ?></span>
				</td>
			</tr>
			<tr style="font-size: 14px; vertical-align: top;">
				<td style="font-weight: bold;">
					Dodavatel:
				</td>
				<td colspan=3>
					<?
					echo $temp['nazev_firmy'] . "<br />";
					echo $temp['ulice'] . "<br />" . $temp['mesto'] . ", " . $temp['psc'] . "<br />" . $temp['stat'];
					if (!empty($temp['kontaktni_osoba'])) echo "<br /><br />Kontaktní osoba: <br />" . $temp['kontaktni_osoba'];
					?>
				</td>
			</tr>
			<tr style="font-size: 14px; vertical-align: top;">
				<td style="font-weight: bold;">
					IČO:
				</td>
				<td>
					<?
					echo $temp['ic'];
					?>
				</td>
				<td style="font-weight: bold;">
					DIČ:
				</td>
				<td>
					<?
					echo $temp['dic'];
					?>
				</td>
			</tr>
			<tr>
				<td colspan=4>
				</td>
			</tr>
			<tr style="font-size: 14px; vertical-align: top;">
				<td style="font-weight: bold;">
					Do skladu:
				</td>
				<td colspan=3>
					<?
					echo $temp['nazev_skladu'];
					?>
				</td>
			</tr>
			<tr>
				<td colspan=4>
				</td>
			</tr>
			<tr style="font-size: 12px; vertical-align: top;">
				<td style="font-weight: bold;">
					Poznámka:
				</td>
				<td colspan=3>
					<?
					echo $temp['poznamka'];
					?>
				</td>
			</tr>
			<tr style="font-size: 12px; vertical-align: top; font-weight: bold;">
				<td>
					Položka č.
				</td>
				<td>
					Název materiálu
				</td>
				<td>
					Množství
				</td>
				<td>
					<?
					if (!is_print_mod()){
						?>
						Celková cena (Kč)
						<?
					}
					?>
				</td>
			</tr>
			<?
			$pocet_polozek = 1;
			$materialy = $sql->query("SELECT spm.nazev_skl_polozky, spm.popis_skl_polozky, mj.zkratka_jednotky, spm.mnozstvi, spm.cena FROM skl_pri_materialy spm
									LEFT JOIN merna_jednotka mj ON mj.id_merna_jednotka=spm.id_merna_jednotka
									WHERE id_skl_prijemky='$_GET[id_skl_prijemky]'");
			while ($material = $sql->fetch_array($materialy)){
				?>
				<tr style="font-size: 12px; vertical-align: top;">
					<td>
						<?echo $pocet_polozek;?>
					</td>
					<td>
						<?
						echo $material['nazev_skl_polozky'] . " - " . $material['popis_skl_polozky'];
						?>
					</td>
					<td>
						<?
						$pocet = number_format($material['mnozstvi'], 0, '.', ' ');
						echo $pocet . " " . $material['zkratka_jednotky'];
						?>
					</td>
					<td>
						<?
						if (!is_print_mod()){
							$cena = number_format($material['cena'] * $material['mnozstvi'], 0, '.', ' ');
							echo $cena;
						}
						?>
					</td>
				</tr>
				<?
				$pocet_polozek++;
			}
			if ($temp['pocet_europalet']>0){
				?>
				<tr style="font-size: 12px; vertical-align: top;">
					<td>
						<?echo $pocet_polozek;?>
					</td>
					<td>
						Europalet
					</td>
					<td>
						<?echo $temp['pocet_europalet'];?>
					</td>
					<td>
						
					</td>
				</tr>
				<?
				$pocet_polozek++;
			}
			?>
			<tr>
				<td colspan=4>
				</td>
			</tr>
			<tr style="font-size: 12px; vertical-align: top;">
				<td>
					Datum vystavení:
				</td>
				<td>
					<?
					echo $datum_editace;
					?>
				</td>
				<td>
					Vystavil(a):
				</td>
				<td>
					<?
					echo $temp['editoval'];
					?>
				</td>
			</tr>
		</table>
		<?
	} else {
		include_once 'script/sklady/submenu.php';
		echo "<p class=\"chyba\">Tato příjemka je rozpracovaná.</p>";	
		$refresh_page=$page->_head_path . "?show=prijemka_edit&id_skl_prijemky=$id_skl_prijemky";
		echo "<meta http-equiv=\"refresh\" content=\"1; url=$refresh_page\">";
	}
}
?>