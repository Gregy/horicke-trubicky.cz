<div class="definice">
<?
if (haveRight('MATERIALY')){
	include_once 'script/main/submenu.php';
	if (isset($_GET['smaz_id'])){
		$datum_editace = Time();
		$sql->query("UPDATE materialy SET smazano=1, editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace' WHERE id_materialu=$_GET[smaz_id]");
		echo "<p class=\"oznameni\">Materiál je smazán. Ve stávajících výrobcích bude ale stále viditelný.</p>";
	}
	?>
	<div style="width: 100%; text-align:center; padding-bottom: 5px; font-size: 15px;">
		<div class="hlavicka"><a href="?show=material_edit">Nový materiál</a></div>
	</div>
	<?
	$rows = $sql->query("SELECT m.id_materialu, m.nazev_materialu, m.datum_editace, u.name editoval, mj.zkratka_jednotky FROM `materialy` m
							JOIN `user` u ON u.id_uzivatel = m.editoval
							JOIN `merna_jednotka` mj ON mj.id_merna_jednotka = m.id_merna_jednotka
						WHERE m.smazano=0
						ORDER BY m.nazev_materialu");
						
	?>
	<table cellspacing="0" cellpadding="5" border="0" width="50%" align="center">
		<?
		$i=0;
		while ($row=$sql->fetch_array($rows)){
			(($i % 2)==0) ? $color="#c2ffc2" : $color="#EEE";
			$i++;
			$datum_editace = StrFTime("%d.%m.%Y %H:%M", $row['datum_editace']);
			?>
			<tr style="text-align:center; background-color: <?echo $color;?>;">
				<td style="text-align:left;">
					<?echo $row['nazev_materialu'];?>
				</td>
				<td>
					<?echo $row['zkratka_jednotky'];?>
				</td>
				<td>
					<a href="?show=material_edit&id_materialu=<?echo $row['id_materialu'];?>" style="text-decoration: none;" title="Naposledy editoval(a) <?echo $row['editoval'] . ' ' . $datum_editace;?>"><img src="files/edit.png" height="16px"></a>
				</td>
				<td style="width: 100px;">
					<span style="cursor: pointer;" id="odkaz_smazat_<?echo $row['id_materialu'];?>"	onClick="ukaz_form_smazat(<?echo $row['id_materialu'];?>)">
						<img src="files/smazat.png" height="16px">
					</span>
					<br />
					<span id="smazat_<?echo $row['id_materialu'];?>" style="display: none;">
						<a href="?show=materialy&smaz_id=<?echo $row['id_materialu'];?>">Ano</a>
						<a style="margin-left: 20px;" href="javascript:void(0)" onclick="skryj_form_smazat(<?echo $row['id_materialu'];?>)">Ne</a>
					</span>
				</td>
			</tr>
			<?
		}
		?>
	</table>
	<?
} else echo "<p class=\"chyba\">Na toto nemáte přiřazená práva.</p>";
?>
</div>