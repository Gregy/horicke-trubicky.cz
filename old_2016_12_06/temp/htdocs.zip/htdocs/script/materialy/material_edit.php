<div class="definice">
<?
if (haveRight('MATERIALY')){
	if (isset($_GET['id_materialu'])){
		global $sql;
		$temp=$sql->query_array("SELECT id_materialu, nazev_materialu, id_merna_jednotka FROM materialy WHERE id_materialu='$_GET[id_materialu]'");
		$id_materialu = $temp['id_materialu'];
		$nazev_materialu = $temp['nazev_materialu'];
		$id_merna_jednotka = $temp['id_merna_jednotka'];
	}
	
	if ($_POST['save']=="Uložit"){
		$error="";
		if (isset($_POST['id_materialu']))
			$id_materialu = $_POST['id_materialu'];
		$nazev_materialu = $_POST['nazev_materialu'];
		$id_merna_jednotka = $_POST['id_merna_jednotka'];
		
		$error.=(empty($nazev_materialu)) ? "<p class=\"chyba\">Nebyl zadán název materiálu.</p>" : "";
		$error.=($id_merna_jednotka==0) ? "<p class=\"chyba\">Vyberte jednotku.</p>" : "";
	}
	
		if ($error=="" && $_POST['save']=="Uložit"){
			$nazev_materialu=check_input($nazev_materialu);
			$datum_editace = Time();
			if (isset($id_materialu)){
				$sql->query("UPDATE materialy SET nazev_materialu='$nazev_materialu', id_merna_jednotka='$id_merna_jednotka', editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace' WHERE id_materialu=$id_materialu");
			} else {
					$sql->query("INSERT INTO materialy VALUES (NULL, '$nazev_materialu', '$id_merna_jednotka', '$_SESSION[ot_userId]', '$datum_editace', '0')");
					$id_materialu=$sql->insert_id();
			}
			
			$saved=1;
			echo "<p class=\"oznameni\">Materiál v pořádku uložen.</p>";
			$refresh_page=$page->_head_path . "?show=materialy";
			echo "<meta http-equiv=\"refresh\" content=\"1; url=$refresh_page\">";
			message_auto_forward($refresh_page);
		} else if ($error!=""){
			echo "<hr /><b>" . $error . "</b><hr />";
		}
		
		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		if ($_POST['save_atribut']=="Vložit atribut"){
			$error_under="";
			if (isset($_POST['id_materialu']))
				$id_materialu = $_POST['id_materialu'];
			$nazev_atributu = $_POST['nazev_atributu'];
			$id_merna_jednotka_atr = $_POST['id_merna_jednotka_atr'];
			
			$error_under.=(empty($nazev_atributu)) ? "<p class=\"chyba\">Zadejte název atributu.</p>" : "";
		}
		
		if ($error_under=="" && $_POST['save_atribut']=="Vložit atribut"){
			$nazev_atributu=check_input($nazev_atributu);
			$datum_editace = Time();
			
			$temp = $sql->query_array("SELECT max(razeni) razeni FROM atributy WHERE id_materialu='$id_materialu'");
			$razeni = $temp['razeni'] + 100;
			
			$sql->query("UPDATE materialy SET editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace' WHERE id_materialu=$id_materialu");
			$sql->query("INSERT INTO atributy VALUES (NULL, '$id_materialu', '$nazev_atributu', '$id_merna_jednotka_atr', '$razeni', '$_SESSION[ot_userId]', $datum_editace, '0')");
			
			unset($nazev_atributu);
			unset($id_merna_jednotka_atr);
			unset($razeni);			
		} else if ($error_under!=""){
			echo "<hr /><b>" . $error_under . "</b><hr />";
		}
		
		if (isset($_GET['smaz_id'])){
			$datum_editace = Time();
			$sql->query("UPDATE atributy SET smazano=1, editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace' WHERE id_atributu=$_GET[smaz_id]");
			echo "<p class=\"oznameni\">Atribut byl odstraněn z tohoto materiálu.</p>";
		}
		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		
		
		if ($saved==0){
?>
		<form action="" method="post" name="material">
			<div style="text-align: center; padding: 5px; border-bottom: #aaa 1px dashed;">
				<input type="submit" name="save" value="Uložit" id="ulozit" />
				<span style="padding-left: 100px">
					<a href="?show=materialy" class="zpet">Zpět na seznam materiálů (bez uložení)</a>
				</span>
			</div>
			
			<?php
				if (isset($id_materialu)){
					?>
					<input type="hidden" name="id_materialu" value="<?echo $id_materialu;?>" />
					<?
				}
			?>
			<table cellspacing="0" cellpadding="5" border="0" width="50%" align="center">
				<tr>
					<td><b>Název materiálu</b> (*)</td>
					<td><input id="nazev_materialu" type="text" size="30" maxlength="100" name="nazev_materialu" value="<?php echo "$nazev_materialu";?>" /></td>
				</tr>
				<tr>
					<td><b>Jednotka</b> (*)</td>
					<td>
						<select name="id_merna_jednotka" >
							<OPTION value="0">Vyberte možnost...</OPTION>
							<?
							$result=$sql->query("SELECT * FROM merna_jednotka");
							while ($row=$sql->fetch_array($result)){
								if ($row['id_merna_jednotka'] == $id_merna_jednotka){
									?>
									<OPTION value="<?echo $row['id_merna_jednotka'];?>" selected="selected"><?echo $row['zkratka_jednotky'];?></OPTION>
									<?
								} else {
									?>
									<OPTION value="<?echo $row['id_merna_jednotka'];?>"><?echo $row['zkratka_jednotky'];?></OPTION>
									<?
								}
							}
							?>
						</select>
					</td>
				</tr>
				<tr>
					<td>(*) - povinné položky</td>
					<td></td>
				</tr>
			</table>
		</form>
		
		
		
		
		
		
		
		<?
		if (isset($id_materialu)){
			$rows = $sql->query("SELECT a.id_atributu, a.nazev_atributu, a.datum_editace, u.name editoval, mj.zkratka_jednotky FROM `atributy` a
								JOIN `user` u ON u.id_uzivatel = a.editoval
								LEFT JOIN merna_jednotka mj ON mj.id_merna_jednotka = a.id_merna_jednotka
									WHERE id_materialu=$id_materialu and smazano=0");
			?>
			<table cellspacing="0" cellpadding="5" border="0" width="90%" align="center">
				<tr style="text-align:center; background-color: <?echo $color;?>;">
						<td style="font-weight: bold;">
							Název atributu
						</td>
						<td style="font-weight: bold;">
							Jednotka
						</td>
						<td style="font-weight: bold;">
							Číselník
						</td>
						<td style="width: 100px;">
							
						</td>
					</tr>
				<?
				$i=0;
				while ($row=$sql->fetch_array($rows)){
					(($i % 2)==0) ? $color="#ddd" : $color="#FFF";
					$i++;
					$datum_editace = StrFTime("%d.%m.%Y %H:%M", $row['datum_editace']);
					?>
					<tr style="text-align:center; background-color: <?echo $color;?>;">
						<td>
							<?echo $row['nazev_atributu'];?>
						</td>
						<td>
							<?echo $row['zkratka_jednotky'];?>
						</td>
						<td>
							<a href="?show=hodnoty_atributu&id_atributu=<?echo $row['id_atributu'];?>"><img src="files/ciselnik.png" height="16px" title="Definovat hodnoty atributu" /></a>
						</td>
						<td style="width: 100px;">
							<span style="cursor: pointer;" id="odkaz_smazat_<?echo $row['id_atributu'];?>"	onClick="ukaz_form_smazat(<?echo $row['id_atributu'];?>)"
							title="Vytvořil(a) <?echo $row['editoval'] . ' ' . $datum_editace;?>">
								<img src="files/smazat.png" height="16px" />
							</span>
							<br />
							<span id="smazat_<?echo $row['id_atributu'];?>" style="display: none;">
								<a href="?show=material_edit&id_materialu=<?echo $id_materialu;?>&smaz_id=<?echo $row['id_atributu'];?>">Ano</a>
								<a style="margin-left: 20px;" href="javascript:void(0)" onclick="skryj_form_smazat(<?echo $row['id_atributu'];?>)">Ne</a>
							</span>
						</td>
					</tr>
					<?
				}
				?>
			</table>
		
			<form action="" method="post" name="vyrobek_material_atribut">
				<?
					if (isset($id_materialu)){
						?>
						<input type="hidden" name="id_materialu" value="<?echo $id_materialu;?>" />
						<?
					}
				?>
				<div style="text-align: left; margin-top: 20px; padding: 5px; border-bottom: #aaa 1px dashed;border-top: #aaa 1px dashed;">
					<table cellspacing="0" cellpadding="5" border="0" width="50%">
						<tr>
							<td><b>Název atributu</b></td>
							<td><input id="nazev_atributu" type="text" size="30" maxlength="100" name="nazev_atributu" value="<? echo "$nazev_atributu";?>" /></td>
						</tr>
						<tr>
							<td><b>Jednotka</b></td>
							<td>
								<select name="id_merna_jednotka_atr" >
									<OPTION value="0">Vyberte možnost...</OPTION>
									<?
									$result=$sql->query("SELECT id_merna_jednotka, zkratka_jednotky FROM merna_jednotka
														ORDER BY zkratka_jednotky");
									while ($row=$sql->fetch_array($result)){
										if ($row['id_merna_jednotka'] == $id_merna_jednotka_atr){
											?>
											<OPTION value="<?echo $row['id_merna_jednotka'];?>" selected="selected"><?echo $row['zkratka_jednotky'];?></OPTION>
											<?
										} else {
											?>
											<OPTION value="<?echo $row['id_merna_jednotka'];?>"><?echo $row['zkratka_jednotky'];?></OPTION>
											<?
										}
									}
									?>
								</select>
							</td>
						</tr>
					<div>
						<input type="submit" name="save_atribut" value="Vložit atribut" id="ulozit" />
					</div>
				</div>
			</form>
			<?
		}
		?>
		
		
		
		
		
		
		
		<script type="text/javascript"> document.getElementById("nazev_materialu").focus(); </script>
		<?php
		}
} else echo "<p class=\"chyba\">Na toto nemáte přiřazená práva.</p>";
?>
</div>