<div class="definice">
<?
if (haveRight('VYSEKOVE_FORMY')){
	if (isset($_GET['id_vysekove_formy'])){
		global $sql;
		$temp=$sql->query_array("SELECT id_vysekove_formy, id_firmy, cislo_vysekove_formy, nazev_vysekove_formy, ks_na_arch, min_rozmer_sirka, min_rozmer_delka, 
										rozmer_obalu_sirka, rozmer_obalu_delka, rozmer_obalu_vyska, poznamka
									FROM vysekove_formy 
								WHERE id_vysekove_formy='$_GET[id_vysekove_formy]'");
		$id_vysekove_formy = $temp['id_vysekove_formy'];
		$id_firmy = $temp['id_firmy'];
		$cislo_vysekove_formy = $temp['cislo_vysekove_formy'];
		$nazev_vysekove_formy = $temp['nazev_vysekove_formy'];
		$ks_na_arch = $temp['ks_na_arch'];
		$min_rozmer_sirka = $temp['min_rozmer_sirka'];
		$min_rozmer_delka = $temp['min_rozmer_delka'];
		$rozmer_obalu_sirka = $temp['rozmer_obalu_sirka'];
		$rozmer_obalu_delka = $temp['rozmer_obalu_delka'];
		$rozmer_obalu_vyska = $temp['rozmer_obalu_vyska'];
		$poznamka = $temp['poznamka'];
	}
	
	if ($_POST['save']=="Uložit"){
		$error="";
		if (isset($_POST['id_vysekove_formy']))
			$id_vysekove_formy = $_POST['id_vysekove_formy'];
		$id_firmy = $_POST['id_firmy'];
		$cislo_vysekove_formy = $_POST['cislo_vysekove_formy'];
		$nazev_vysekove_formy = $_POST['nazev_vysekove_formy'];
		$ks_na_arch = $_POST['ks_na_arch'];
		$min_rozmer_sirka = $_POST['min_rozmer_sirka'];
		$min_rozmer_delka = $_POST['min_rozmer_delka'];
		$rozmer_obalu_sirka = $_POST['rozmer_obalu_sirka'];
		$rozmer_obalu_delka = $_POST['rozmer_obalu_delka'];
		$rozmer_obalu_vyska = $_POST['rozmer_obalu_vyska'];
		$poznamka = $_POST['poznamka'];
		
		$error.=(empty($id_firmy)) ? "<p class=\"chyba\">Nebyla zadána firma.</p>" : "";
		$error.=(empty($cislo_vysekove_formy)) ? "<p class=\"chyba\">Nebylo zadáno číslo výsekové formy.</p>" : "";
		$error.=(empty($nazev_vysekove_formy)) ? "<p class=\"chyba\">Nebyl zadán název výsekové formy.</p>" : "";
		$error.=(empty($ks_na_arch)) ? "<p class=\"chyba\">Nebylo zadáno ks/arch.</p>" : "";
		$error.=(empty($min_rozmer_sirka) || empty($min_rozmer_delka)) ? "<p class=\"chyba\">Nebyly zadány minimální rozměry.</p>" : "";
		//$error.=(empty($rozmer_obalu_sirka) || empty($rozmer_obalu_delka) || empty($rozmer_obalu_vyska)) ? "<p class=\"chyba\">Nebyly zadány rozměry obalu.</p>" : "";
	}
	
		if ($error=="" && $_POST['save']=="Uložit"){
			$nazev_vysekove_formy=check_input($nazev_vysekove_formy);
			$datum_editace = Time();
			if (isset($id_vysekove_formy)){
				$sql->query("UPDATE vysekove_formy SET id_firmy='$id_firmy', cislo_vysekove_formy='$cislo_vysekove_formy', nazev_vysekove_formy='$nazev_vysekove_formy', ks_na_arch='$ks_na_arch', 
								min_rozmer_sirka='$min_rozmer_sirka', min_rozmer_delka='$min_rozmer_delka', rozmer_obalu_sirka='$rozmer_obalu_sirka', rozmer_obalu_delka='$rozmer_obalu_delka', 
								rozmer_obalu_vyska='$rozmer_obalu_vyska', editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace', poznamka='$poznamka'
							WHERE id_vysekove_formy=$id_vysekove_formy");
			} else {
					$sql->query("INSERT INTO vysekove_formy VALUES (NULL, '$id_firmy', '$cislo_vysekove_formy', '$nazev_vysekove_formy', '$ks_na_arch', '$min_rozmer_sirka', '$min_rozmer_delka', 
								'$rozmer_obalu_sirka', '$rozmer_obalu_delka', '$rozmer_obalu_vyska', '$_SESSION[ot_userId]', '$datum_editace', '0', '$poznamka')");
					$id_vysekove_formy=$sql->insert_id();
			}
			
			$saved=1;
			echo "<p class=\"oznameni\">Výseková forma je v pořádku uložena.</p>";
			$refresh_page=$page->_head_path . "?show=vysekove_formy&id_firmy=$id_firmy";
			echo "<meta http-equiv=\"refresh\" content=\"1; url=$refresh_page\">";
			message_auto_forward($refresh_page);
		} else if ($error!=""){
			echo "<hr /><b>" . $error . "</b><hr />";
		}
		if ($saved==0){
?>
		<form action="" method="post" name="vysekove_formy">
			<div style="text-align: center; padding: 5px; border-bottom: #aaa 1px dashed;">
				<input type="submit" name="save" value="Uložit" id="ulozit" />
				<span style="padding-left: 100px">
					<a href="?show=vysekove_formy&id_firmy=<? echo $id_firmy;?>" class="zpet">Zpět na seznam výsekových forem (bez uložení)</a>
				</span>
			</div>
			
			<?php
				if (isset($id_vysekove_formy)){
					?>
					<input type="hidden" name="id_vysekove_formy" value="<?echo $id_vysekove_formy;?>" />
					<?
				}
			?>
			<table cellspacing="0" cellpadding="5" border="0" width="70%" align="center">
				<tr>
					<td><b>Pro firmu</b> (*)</td>
					<td>
						<select name="id_firmy" >
							<OPTION value="0">Vyberte možnost...</OPTION>
							<?
							$result=$sql->query("SELECT f.id_firmy, f.nazev_firmy FROM firmy f
												WHERE smazano=0
												ORDER BY f.nazev_firmy");
							while ($row=$sql->fetch_array($result)){
								if ($row['id_firmy'] == $id_firmy){
									?>
									<OPTION value="<?echo $row['id_firmy'];?>" selected="selected"><?echo $row['nazev_firmy'];?></OPTION>
									<?
								} else {
									?>
									<OPTION value="<?echo $row['id_firmy'];?>"><?echo $row['nazev_firmy'];?></OPTION>
									<?
								}
							}
							?>
						</select>
					</td>
				</tr>
				<tr>
					<td><b>Číslo výsekové formy</b> (*)</td>
					<td><input id="cislo_vysekove_formy" type="text" size="10" maxlength="20" name="cislo_vysekove_formy" value="<?php echo "$cislo_vysekove_formy";?>" /></td>
				</tr>
				<tr>
					<td><b>Název výsekové formy</b> (*)</td>
					<td><input id="nazev_vysekove_formy" type="text" size="30" maxlength="100" name="nazev_vysekove_formy" value="<?php echo "$nazev_vysekove_formy";?>" /></td>
				</tr>
				<tr>
					<td><b>ks/TA</b> (*)</td>
					<td><input id="ks_na_arch" type="text" size="5" maxlength="5" name="ks_na_arch" value="<?php echo "$ks_na_arch";?>" /></td>
				</tr>
				<tr>
					<td><b>Minimální rozměr - Š x D (mm)</b> (*)</td>
					<td>
						<input id="min_rozmer_sirka" type="text" size="5" maxlength="5" name="min_rozmer_sirka" value="<?php echo "$min_rozmer_sirka";?>" />
						x
						<input id="min_rozmer_delka" type="text" size="5" maxlength="5" name="min_rozmer_delka" value="<?php echo "$min_rozmer_delka";?>" />
					</td>
				</tr>
				<tr>
					<td><b>Rozměry obalu - D x Š x V (mm)</b> (*)</td>
					<td>
						<input id="rozmer_obalu_delka" type="text" size="5" maxlength="5" name="rozmer_obalu_delka" value="<?php echo "$rozmer_obalu_delka";?>" />
						x
						<input id="rozmer_obalu_sirka" type="text" size="5" maxlength="5" name="rozmer_obalu_sirka" value="<?php echo "$rozmer_obalu_sirka";?>" />
						x
						<input id="rozmer_obalu_vyska" type="text" size="5" maxlength="5" name="rozmer_obalu_vyska" value="<?php echo "$rozmer_obalu_vyska";?>" />
					</td>
				</tr>
				<tr>
					<td colspan=2>
						<b>Poznámka</b><br />
						<input id="poznamka" type="text" size="80" maxlength="100" name="poznamka" value="<?php echo "$poznamka";?>" />
					</td>
				</tr>
			</table>
			<br />(*) - povinné položky
		</form>
		<script type="text/javascript"> document.getElementById("cislo_vysekove_formy").focus(); </script>
		<?php
		}
} else echo "<p class=\"chyba\">Na toto nemáte přiřazená práva.</p>";
?>
</div>