<div class="definice">
<?
if (haveRight('VYSEKOVE_FORMY')){
	include_once 'script/main/submenu.php';
	
	if (isset($_GET['smaz_id'])){
		$datum_editace = Time();
		$temp = $sql->query("SELECT v.nazev_vyrobku, f.nazev_firmy FROM vyrobky v 
							JOIN firmy f ON f.id_firmy = v.id_firmy
							WHERE v.id_vysekove_formy=$_GET[smaz_id]");
		if ($sql->num_rows($temp)>0){
			echo "<p class=\"chyba\">Výseková forma nelze smazat. Je použitá v definici následujících výrobků.</p>";
			while ($row=$sql->fetch_array($temp)){	
				echo "<p class=\"chyba\">$row[nazev_firmy] - $row[nazev_vyrobku].</p>";
			}
		} else {
			$sql->query("UPDATE vysekove_formy SET smazano=1, editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace' WHERE id_vysekove_formy=$_GET[smaz_id]");
		}
	}
	?>
	<div style="width: 100%; text-align:center; padding-bottom: 5px; font-size: 15px;">
		<div class="hlavicka"><a href="?show=vysekove_formy_edit">Nová výseková forma</a></div>
	</div>
	<?
	$rows = $sql->query("SELECT f.id_firmy, f.nazev_firmy, f.datum_editace, u.name editoval FROM `firmy` f
							JOIN `user` u ON u.id_uzivatel = f.editoval
						WHERE f.smazano=0
						ORDER BY nazev_firmy");
						
	?>
	<table cellspacing="0" cellpadding="5" border="0" width="50%" align="center">
		<?
		$i=0;
		while ($row=$sql->fetch_array($rows)){
			(($i % 2)==0) ? $color="#fbc1ff" : $color="#fff5f5";
			$i++;
			$datum_editace = StrFTime("%d.%m.%Y %H:%M", $row['datum_editace']);
			?>
			<tr style="background-color: <?echo $color;?>; cursor: pointer;">
				<td>
					<span onclick="ukaz_skryj('trow<?echo $row['id_firmy'];?>');" title="kliknutím zobrazíte/skryjete detail" style="cursor: pointer; font-weight: bold;">
						<?echo $row['nazev_firmy'];?>
					</span>
				</td>
			</tr>
			<tr style="background-color: <?echo $color;?>;" >
				<td>
					<?
					if ($_GET['id_firmy'] == $row['id_firmy']){
						$display="block";
					} else {
						$display="none";
					}
					?>
					<table cellspacing="0" cellpadding="5" style="display: <?echo $display;?>;" id="trow<?echo $row['id_firmy'];?>">
						<?
						$vysekove_formy = $sql->query("SELECT vf.id_vysekove_formy, vf.cislo_vysekove_formy, vf.nazev_vysekove_formy, vf.datum_editace, u.name editoval 
													FROM `vysekove_formy` vf
													JOIN `user` u ON u.id_uzivatel = vf.editoval
												WHERE vf.smazano=0 AND id_firmy=$row[id_firmy]
												ORDER BY vf.nazev_vysekove_formy");
						$j=0;
						while ($vf=$sql->fetch_array($vysekove_formy)){
							(($j % 2)==0) ? $color="#CCC" : $color="#EEE";
							$j++;
							$datum_editace = StrFTime("%d.%m.%Y %H:%M", $vf['datum_editace']);
							?>
							<tr style="background-color: <?echo $color;?>;">
								<td style="width: 400px;">
									<?
									echo $vf['cislo_vysekove_formy'] . ' - ' . $vf['nazev_vysekove_formy'];
									?>
								</td>
								<td>
									<a href="?show=vysekove_formy_edit&id_vysekove_formy=<?echo $vf['id_vysekove_formy'];?>" style="text-decoration: none;" title="Naposledy editoval(a) <?echo $vf['editoval'] . ' ' . $datum_editace;?>"><img src="files/edit.png" height="16px"></a>
								</td>
								<td>
									<a href="?show=vys_for_soubory&id_vysekove_formy=<?echo $vf['id_vysekove_formy'];?>" style="text-decoration: none;"><img src="files/files.png" height="16px" title="Soubory k výsekové formě" /></a>
								</td>
								<td style="width: 100px; text-align:center;">
									<span style="cursor: pointer;" id="odkaz_smazat_<?echo $vf['id_vysekove_formy'];?>"	onClick="ukaz_form_smazat_vf(<?echo $vf['id_vysekove_formy'];?>)">
										<img src="files/smazat.png" height="16px">
									</span>
									<br />
									<span id="smazat_vf_<?echo $vf['id_vysekove_formy'];?>" style="display: none;">
										<a href="?show=vysekove_formy&id_firmy=<?echo $row['id_firmy'];?>&smaz_id=<?echo $vf['id_vysekove_formy'];?>">Ano</a>
										<a style="margin-left: 20px;" href="javascript:void(0)" onclick="skryj_form_smazat_vf(<?echo $vf['id_vysekove_formy'];?>)">Ne</a>
									</span>
								</td>
							</tr>
							<?
						}
						?>
					</table>
				</td>
			</tr>
			<?
		}
		?>
	</table>
	<?
} else echo "<p class=\"chyba\">Na toto nemáte přiřazená práva.</p>";
?>
</div>