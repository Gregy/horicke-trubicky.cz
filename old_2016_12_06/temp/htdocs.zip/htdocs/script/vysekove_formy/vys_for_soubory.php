<div class="definice">
<?
if (haveRight("VYSEKOVE_FORMY")){
	if (isset($_GET['smaz_id']) && haveRight('ZAKAZKY_SOUBORY')){
		$datum_editace = Time();
		$sql->query("UPDATE vys_for_soubory SET smazano=1, editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace' WHERE id_vys_for_souboru=$_GET[smaz_id]");
	}
	
	if (isset($_GET['id_vysekove_formy'])){
		global $sql;
		$temp=$sql->query_array("SELECT id_vysekove_formy, id_firmy, cislo_vysekove_formy, nazev_vysekove_formy, ks_na_arch, min_rozmer_sirka, min_rozmer_delka, 
										rozmer_obalu_sirka, rozmer_obalu_delka, rozmer_obalu_vyska, poznamka
									FROM vysekove_formy 
								WHERE id_vysekove_formy='$_GET[id_vysekove_formy]'");
		$id_vysekove_formy = $temp['id_vysekove_formy'];
		$id_firmy = $temp['id_firmy'];
		$cislo_vysekove_formy = $temp['cislo_vysekove_formy'];
		$nazev_vysekove_formy = $temp['nazev_vysekove_formy'];
		$ks_na_arch = $temp['ks_na_arch'];
		$min_rozmer_sirka = $temp['min_rozmer_sirka'];
		$min_rozmer_delka = $temp['min_rozmer_delka'];
		$rozmer_obalu_sirka = $temp['rozmer_obalu_sirka'];
		$rozmer_obalu_delka = $temp['rozmer_obalu_delka'];
		$rozmer_obalu_vyska = $temp['rozmer_obalu_vyska'];
		$poznamka = $temp['poznamka'];
	}
	
	$rows = $sql->query("SELECT vs.id_vys_for_souboru, vs.nazev_souboru, vs.cesta, u.name editoval, vs.datum_editace
						FROM vys_for_soubory vs
						JOIN user u ON u.id_uzivatel = vs.editoval
						WHERE vs.id_vysekove_formy=$id_vysekove_formy AND vs.smazano=0
						ORDER BY vs.id_vys_for_souboru");
	?>
	<div style="text-align: center; padding: 5px;">
		<span>
			<a href="?show=vysekove_formy&id_firmy=<? echo $id_firmy;?>" class="zpet">Zpět na seznam výsekových forem</a>
		</span>
	</div>

	<div style="width: 100%; text-align:center; padding-bottom: 5px; font-size: 15px;">
		<div class="hlavicka">
			<a href="?show=vys_for_soubory_edit&id_vysekove_formy=<?echo $id_vysekove_formy;?>" style="margin: 0 25px">Nový soubor</a>
		</div>
	</div>

	<h3>
	Soubory k výsekové formě 
	<?
	echo $cislo_vysekove_formy . ' - ' . $nazev_vysekove_formy . ' - ' . $ks_na_arch . ' ks/arch (min.rozměr: ' . $min_rozmer_sirka . 'x'
							. $min_rozmer_delka . ', rozměry obalu: ' . $rozmer_obalu_sirka . 'x' . $rozmer_obalu_delka . 'x' . $rozmer_obalu_vyska . ')';
	?>
	</h3>
	<?
	if ($sql->num_rows($rows)){
		?>
		<table cellspacing="0" cellpadding="5" border="0" width="50%" align="center">
			<tr style="font-size: 110%; font-weight: bold; vertical-align: bottom;">
				<td style="width: 300px;">
					Název
				</td>
				<td>
					
				</td>
				<td></td>
				<td></td>
			</tr>
			<?
			$i=0;
			while ($row=$sql->fetch_array($rows)){
				(($i % 2)==0) ? $color="#ffe684" : $color="#fff5f5";
				$i++;
				$datum_editace = StrFTime("%d.%m.%Y", $row['datum_editace']);
				?>
				<tr style="background-color: <?echo $color;?>;">
					<td>
						<?echo $row['nazev_souboru'];?>
					</td>
					<td>
						<a href="<?echo $row['cesta'];?>"><img src="files/download.png" height="18px" title="Klikněte pro stažení" /></a>
					</td>
					<td>
						<a href="?show=vys_for_soubory_edit&id_vysekove_formy=<?echo $id_vysekove_formy;?>&id_vys_for_souboru=<?echo $row['id_vys_for_souboru'];?>" style="text-decoration: none;" title="Naposledy editoval(a) <?echo $row['editoval'] . ' ' . $datum_editace;?>"><img src="files/edit.png" height="16px"></a>
					</td>
					<td style="width: 100px; text-align:center;">
						<span style="cursor: pointer;" id="odkaz_smazat_<?echo $row['id_vys_for_souboru'];?>"	onClick="ukaz_form_smazat(<?echo $row['id_vys_for_souboru'];?>)">
							<img src="files/smazat.png" height="16px">
						</span>
						<br />
						<span id="smazat_<?echo $row['id_vys_for_souboru'];?>" style="display: none;">
							<a href="?show=vys_for_soubory&id_vysekove_formy=<?echo $id_vysekove_formy;?>&smaz_id=<?echo $row['id_vys_for_souboru'];?>">Ano</a>
							<a style="margin-left: 20px;" href="javascript:void(0)" onclick="skryj_form_smazat(<?echo $row['id_vys_for_souboru'];?>)">Ne</a>
						</span>
					</td>
				</tr>
				<?
			}
			?>
		</table>
		<?
	} else {
		echo "K této zakázce zatím nejsou přiřazené žádné soubory.";
	}
}
?>
</div>