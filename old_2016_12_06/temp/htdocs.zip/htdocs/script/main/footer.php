			</div>
			<?content_footer();?>
			</div>
		</div>
	
<?php
		$cas=getdate();
		$dnes=date('Y-m-d',$cas[0]);
		$rok=substr($dnes,0,4);
		$zacatek='2014';
		echo "<div class=\"textinfo\">";
		$hour = StrFTime("%H", Time());
		$minute = StrFTime("%M", Time());
		$second = StrFTime("%S", Time());
		echo "<div style=\"background-color: #FFF; height: 24px; padding: 5px 0;\">";
		echo "<span style=\"padding-right:200px; padding-left: 170px;\">";
			
			echo "<span id=\"ClockHour\">$hour</span>:<span id=\"ClockMinute\">$minute</span>:<span id=\"ClockSecond\">$second</span>";
		echo "</span>";
		echo "© <a href=\"mailto:lubhor@gmail.com\">Luboš Horák</a> ";
		echo ($rok>$zacatek)? "($zacatek - $rok)" : "($zacatek)";
		echo "</div>";
?>
		</div>
		</div>
	</body>
</html>
<?
	//include_once ("promotion.php");
?>