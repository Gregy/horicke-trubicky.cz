<style type="text/css">
	.fir{
		padding: 5px 20px 5px 20px ;
		margin: 0px 15px 0px 15px;
		-webkit-border-radius: 6px;
		-moz-border-radius: 6px;
		-border-radius: 6px;
		background-color: #ffc2c2;
		font-weight: bold;
		text-decoration: none;
	}
	
	.fird{
		padding: 5px 20px 5px 20px ;
		margin: 0px 15px 0px 15px;
		-webkit-border-radius: 6px;
		-moz-border-radius: 6px;
		-border-radius: 6px;
		background-color: #ffd0fa;
		font-weight: bold;
		text-decoration: none;
	}
	
	.mat{
		padding: 5px 20px 5px 20px ;
		margin: 0px 15px 0px 15px;
		-webkit-border-radius: 6px;
		-moz-border-radius: 6px;
		-border-radius: 6px;
		background-color: #c2ffc2;
		font-weight: bold;
		text-decoration: none;
	}
	
	.bal{
		padding: 5px 20px 5px 20px ;
		margin: 0px 15px 0px 15px;
		-webkit-border-radius: 6px;
		-moz-border-radius: 6px;
		-border-radius: 6px;
		background-color: #c2c2ff;
		font-weight: bold;
		text-decoration: none;
	}
	
	.lak{
		padding: 5px 20px 5px 20px ;
		margin: 0px 15px 0px 15px;
		-webkit-border-radius: 6px;
		-moz-border-radius: 6px;
		-border-radius: 6px;
		background-color: #ffe684;
		font-weight: bold;
		text-decoration: none;
	}
	
	.ope{
		padding: 5px 20px 5px 20px ;
		margin: 0px 15px 0px 15px;
		-webkit-border-radius: 6px;
		-moz-border-radius: 6px;
		-border-radius: 6px;
		background-color: #baeeff;
		font-weight: bold;
		text-decoration: none;
	}
	
	.opevn{
		padding: 5px 20px 5px 20px ;
		margin: 0px 15px 0px 15px;
		-webkit-border-radius: 6px;
		-moz-border-radius: 6px;
		-border-radius: 6px;
		background-color: #ffe1ba;
		font-weight: bold;
		text-decoration: none;
	}
	
	.vf{
		padding: 5px 20px 5px 20px ;
		margin: 0px 15px 0px 15px;
		-webkit-border-radius: 6px;
		-moz-border-radius: 6px;
		-border-radius: 6px;
		background-color: #fbc1ff;
		font-weight: bold;
		text-decoration: none;
	}
</style>
<div style="padding-top: 10px; margin-bottom: 10px; padding-bottom: 3px; width: 1150px; text-align: center">
<?
if (haveRight('FIRMY')){
	?>
	<a href="?show=firmy" class="fir">Odběratelé a výrobky</a>
	<?
}
if (haveRight('FIRMY_DODAVATELU')){
	?>
	<a href="?show=firmy_dodavatelu" class="fird">Dodavatelé</a>
	<?
}
?>
</div>
<div style="margin-bottom: 10px; width: 1150px; text-align: center">
<?
if (haveRight('MATERIALY')){
	?>
	<a href="?show=materialy" class="mat">Materiály</a>
	<?
}
if (haveRight('BALENI')){
	?>
	<a href="?show=baleni" class="bal">Balení</a>
	<?
}
if (haveRight('LAKOVANI')){
	?>
	<a href="?show=lakovani" class="lak">Lakování</a>
	<?
}
if (haveRight('OPERACE_VNITRNI')){
	?>
	<a href="?show=operace_vnitrni" class="ope">Vnitřní operace</a>
	<?
}
if (haveRight('OPERACE_VNEJSI')){
	?>
	<a href="?show=operace_vnejsi" class="opevn">Kooperace</a>
	<?
}
if (haveRight('VYSEKOVE_FORMY')){
	?>
	<a href="?show=vysekove_formy" class="vf">Výsekové formy</a>
	<?
}
?>
</div>
