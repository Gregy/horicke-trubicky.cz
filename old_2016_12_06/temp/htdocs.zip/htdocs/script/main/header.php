<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" lang="cs">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
	<meta name="robots" content="all,follow" />
	<meta name="author" content="Lubos Horak" />
	<meta name="keywords" content="<?php echo keywords;?>" lang="cs" />
	
	<link rel="stylesheet" href="css/main.css" type="text/css" media="screen" />
	<link rel="stylesheet" href="css/menu.css" type="text/css" media="screen" />
	<link rel="stylesheet" href="css/diskuze.css" type="text/css" media="screen" />
	<link rel="stylesheet" type="text/css" href="css/calendar.css" />
	
	<script src="js/clock.js" type="text/javascript"></script>
	<script src="js/common.js" type="text/javascript"></script>
	<script src="js/calendar.js" type="text/javascript"></script>
	
	<title><?php global $page; echo "$page->_title";?></title>
</head>
<body>

<script type="text/javascript">ClockStart();</script>

<div id="hlavni">
	<div id="horni">
		<table border=0>
			<tr>
				<td>
					<a href="<?echo "../";?>"/><img src="files/logo.png" width="420px" alt="logo" /></a>
				</td>
				<td>
					<?
					if (isset($_SESSION['ot_userId'])) {
						$row = $sql->query_array("SELECT name FROM user WHERE id_uzivatel=$_SESSION[ot_userId]");
						echo "Přihlášený uživatel:<br />";
						echo "<b>" . $row['name'] . "</b>";
					}
					?>
				</td>
			</tr>
		</table>
	</div>	
	
	<div id="menu">
		<div class="submenu">
			<?
				generate_menu();
			?>
		</div>
	</div>
	
	<div id="obsah">
		<div style="background-color: #FFF;">
		<?content_header();?>
		<div style="padding-left:10px; padding-right:10px;">