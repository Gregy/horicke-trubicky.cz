<div class="definice">
<?
if (haveRight('MATERIALY')){
	if (isset($_GET['id_atributu'])){
		global $sql;
		$temp=$sql->query_array("SELECT id_atributu, id_materialu, nazev_atributu, id_merna_jednotka FROM atributy WHERE id_atributu='$_GET[id_atributu]'");
		$id_atributu = $temp['id_atributu'];
		$id_materialu = $temp['id_materialu'];
		$nazev_atributu = $temp['nazev_atributu'];
		$id_merna_jednotka = $temp['id_merna_jednotka'];
	}
	
	if ($_POST['save']=="Uložit"){
		$error="";
		if (isset($_POST['id_atributu']))
			$id_atributu = $_POST['id_atributu'];
		$nazev_atributu = $_POST['nazev_atributu'];
		$id_merna_jednotka = $_POST['id_merna_jednotka'];
		
		$error.=(empty($nazev_atributu)) ? "<p class=\"chyba\">Nebyl zadán název atributu.</p>" : "";
	}
	
	if ($error=="" && $_POST['save']=="Uložit"){
		$nazev_atributu=check_input($nazev_atributu);
		$datum_editace = Time();
		if (isset($id_atributu)){
			$sql->query("UPDATE atributy SET nazev_atributu='$nazev_atributu', id_merna_jednotka='$id_merna_jednotka', editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace' WHERE id_atributu=$id_atributu");
		} else {
				$sql->query("INSERT INTO atributy VALUES (NULL, '$nazev_atributu', '$id_merna_jednotka', '$_SESSION[ot_userId]', '$datum_editace', '0')");
				$id_atributu=$sql->insert_id();
		}
		
		$saved=1;
		echo "<p class=\"oznameni\">Atribut v pořádku uložen.</p>";
		$refresh_page=$page->_head_path . "?show=material_edit&id_materialu=" . $id_materialu;
		echo "<meta http-equiv=\"refresh\" content=\"1; url=$refresh_page\">";
		message_auto_forward($refresh_page);
	} else if ($error!=""){
		echo "<hr /><b>" . $error . "</b><hr />";
	}
		
		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		if (isset($_POST['save_hodnota'])){
			$error_under="";
			if (isset($_POST['id_atributu']))
				$id_atributu = $_POST['id_atributu'];
			$hodnota_atributu = $_POST['hodnota_atributu'];
			
			$error_under.=(empty($hodnota_atributu)) ? "<p class=\"chyba\">Zadejte hodnotu atributu.</p>" : "";
		}
		
		if ($error_under=="" && isset($_POST['save_hodnota'])){
			$hodnota_atributu=check_input($hodnota_atributu);
			$datum_editace = Time();
			
			$sql->query("UPDATE atributy SET editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace' WHERE id_atributu=$id_atributu");
			$sql->query("INSERT INTO hodnoty_atributu VALUES (NULL, '$id_atributu', '$hodnota_atributu', '$_SESSION[ot_userId]', $datum_editace, '0')");
			
			unset($hodnota_atributu);
		} else if ($error_under!=""){
			echo "<hr /><b>" . $error_under . "</b><hr />";
		}
		
		if (isset($_GET['smaz_id'])){
			$datum_editace = Time();
			$sql->query("UPDATE hodnoty_atributu SET smazano=1, editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace' WHERE id_hodnoty_atributu=$_GET[smaz_id]");
			echo "<p class=\"oznameni\">Hodnota atributu byla odstraněna.</p>";
		}
		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		
		
		if ($saved==0){
?>
		<form action="" method="post" name="material">
			<div style="text-align: center; padding: 5px; border-bottom: #aaa 1px dashed;">
				<input type="submit" name="save" value="Uložit" id="ulozit" />
				<span style="padding-left: 100px">
					<a href="?show=material_edit&id_materialu=<?echo $id_materialu;?>" class="zpet">Zpět na editaci materiálu (bez uložení)</a>
				</span>
			</div>
			
			<?php
				if (isset($id_atributu)){
					?>
					<input type="hidden" name="id_atributu" value="<?echo $id_atributu;?>" />
					<input type="hidden" name="id_materialu" value="<?echo $id_materialu;?>" />
					<?
				}
			?>
			<table cellspacing="0" cellpadding="5" border="0" width="50%" align="center">
				<tr>
					<td><b>Název atributu</b> (*)</td>
					<td><input id="nazev_atributu" type="text" size="30" maxlength="100" name="nazev_atributu" value="<?php echo "$nazev_atributu";?>" /></td>
				</tr>
				<tr>
					<td><b>Jednotka</b></td>
					<td>
						<select name="id_merna_jednotka" >
							<OPTION value="0">Vyberte možnost...</OPTION>
							<?
							$result=$sql->query("SELECT * FROM merna_jednotka");
							while ($row=$sql->fetch_array($result)){
								if ($row['id_merna_jednotka'] == $id_merna_jednotka){
									?>
									<OPTION value="<?echo $row['id_merna_jednotka'];?>" selected="selected"><?echo $row['zkratka_jednotky'];?></OPTION>
									<?
								} else {
									?>
									<OPTION value="<?echo $row['id_merna_jednotka'];?>"><?echo $row['zkratka_jednotky'];?></OPTION>
									<?
								}
							}
							?>
						</select>
					</td>
				</tr>
				<tr>
					<td>(*) - povinné položky</td>
					<td></td>
				</tr>
			</table>
		</form>
		
		<?
		if (isset($id_atributu)){
			$rows = $sql->query("SELECT h.id_hodnoty_atributu, h.hodnota_atributu, h.datum_editace, u.name editoval FROM `hodnoty_atributu` h
								JOIN `user` u ON u.id_uzivatel = h.editoval
									WHERE id_atributu=$id_atributu and smazano=0
								ORDER BY h.hodnota_atributu");
			
			if ($sql->num_rows($rows)>0){
				?>
				<table cellspacing="0" cellpadding="5" border="0" width="50%" align="center">
					<tr style="text-align:center; background-color: <?echo $color;?>;">
							<td style="font-weight: bold;">
								Hodnota
							</td>
							<td style="width: 100px;">
								
							</td>
						</tr>
					<?
					$i=0;
					while ($row=$sql->fetch_array($rows)){
						(($i % 2)==0) ? $color="#ddd" : $color="#FFF";
						$i++;
						$datum_editace = StrFTime("%d.%m.%Y %H:%M", $row['datum_editace']);
						?>
						<tr style="text-align:center; background-color: <?echo $color;?>;">
							<td>
								<?echo $row['hodnota_atributu'];?>
							</td>
							<td style="width: 100px;">
								<span style="cursor: pointer;" id="odkaz_smazat_<?echo $row['id_hodnoty_atributu'];?>"	onClick="ukaz_form_smazat(<?echo $row['id_hodnoty_atributu'];?>)"
								title="Vytvořil(a) <?echo $row['editoval'] . ' ' . $datum_editace;?>">
									<img src="files/smazat.png" height="16px" />
								</span>
								<br />
								<span id="smazat_<?echo $row['id_hodnoty_atributu'];?>" style="display: none;">
									<a href="?show=hodnoty_atributu&id_atributu=<?echo $id_atributu;?>&smaz_id=<?echo $row['id_hodnoty_atributu'];?>">Ano</a>
									<a style="margin-left: 20px;" href="javascript:void(0)" onclick="skryj_form_smazat(<?echo $row['id_hodnoty_atributu'];?>)">Ne</a>
								</span>
							</td>
						</tr>
						<?
					}
					?>
				</table>
				<?
			} else {
				echo "<p class=\"oznameni\">K tomuto atributu nejsou definované žádné hodnoty.</p>";
			}
			?>
		
			<form action="" method="post" name="vyrobek_material_atribut">
				<?
					if (isset($id_atributu)){
						?>
						<input type="hidden" name="id_atributu" value="<?echo $id_atributu;?>" />
						<?
					}
				?>
				<div style="text-align: left; margin-top: 20px; padding: 5px; border-bottom: #aaa 1px dashed;border-top: #aaa 1px dashed;">
					<table cellspacing="0" cellpadding="5" border="0" width="50%">
						<tr>
							<td><b>Hodnota atributu</b></td>
							<td><input id="hodnota_atributu" type="text" size="30" maxlength="100" name="hodnota_atributu" value="<? echo "$hodnota_atributu";?>" /></td>
						</tr>
					<div>
						<input type="submit" name="save_hodnota" value="Vložit hodnotu" id="ulozit" />
					</div>
				</div>
			</form>
			<?
		}
		?>
		
		<script type="text/javascript"> document.getElementById("hodnota_atributu").focus(); </script>
		<?php
		}
} else echo "<p class=\"chyba\">Na toto nemáte přiřazená práva.</p>";
?>
</div>