<?
if (haveRight('DODACI_LISTY')){
	if (isset($_GET['id_dodaciho_listu'])){
		global $sql;
		$temp=$sql->query_array("SELECT distinct dl.cislo_dodaciho_listu, dl.rok, dl.pocet_europalet, dl.datum_editace, u.name editoval, 
									z.nazev_firmy, z.ulice, z.mesto, z.psc, z.stat, z.telefon, z.email, z.ic, z.dic, z.bank_uc_pred, z.bank_uc_za, z.spec_symb, z.kontaktni_osoba, z.id_zakazky
								FROM dodaci_listy dl
								JOIN dod_lis_vyrobky dlv ON dlv.id_dodaciho_listu = dl.id_dodaciho_listu
								JOIN zak_vyrobky zv ON zv.id_zak_vyrobku = dlv.id_zak_vyrobku
								JOIN zakazky z ON z.id_zakazky = zv.id_zakazky
								JOIN user u ON u.id_uzivatel = dl.editoval
								WHERE dl.id_dodaciho_listu = '$_GET[id_dodaciho_listu]'
								LIMIT 1");
								
		$id_zakazky = $temp['id_zakazky'];
	}
	$datum_editace = StrFTime("%d.%m.%Y", $temp['datum_editace']);
	
	if (!is_print_mod()){
		?>
		<div style="text-align: center; padding: 5px; border-bottom: #aaa 1px dashed;">
			<span>
				<a href="?show=zakazky" class="zpet">Do zakázek</a>
			</span>
			<span style="padding-left: 100px">
				<a href="?show=dodaci_listy" class="zpet">Do expedice</a>
			</span>
		</div>
		<?
	}
	?>
	<table cellspacing="0" cellpadding="5" border="1" width="95%" align="center">
		<tr style="text-align: center; font-size: 22px; font-weigt: bold;">
			<td colspan="4">
				<img src="files/logo_velke.png" height="100px" /><br />
				<span style="padding-right: 200px;">Dodací list</span>
				<span>Číslo: <?echo cislo_rok($temp['cislo_dodaciho_listu'], $temp['rok']); ?></span>
			</td>
		</tr>
		<tr style="font-size: 14px; vertical-align: top;">
			<td style="font-weight: bold;">
				Odběratel:
			</td>
			<td>
				<?
				echo $temp['nazev_firmy'] . "<br />";
				echo $temp['ulice'] . "<br />" . $temp['mesto'] . ", " . $temp['psc'] . "<br />" . $temp['stat'];
				if (!empty($temp['kontaktni_osoba'])) echo "<br /><br />Kontaktní osoba: <br />" . $temp['kontaktni_osoba'];
				?>
			</td>
			<td style="font-weight: bold;">
				Místo dodání:
			</td>
			<td>
				<?
				$dod_adresa=$sql->query("SELECT jmeno, prijmeni, nazev_adresy, ulice, mesto, psc, stat, poznamka, email, telefon
										FROM dod_lis_dodaci_adresy 
										WHERE id_dodaciho_listu = '$_GET[id_dodaciho_listu]'");
				if ($sql->num_rows($dod_adresa)>0){
					$dod_adresa = $sql->fetch_array($dod_adresa);
					echo $dod_adresa['nazev_adresy'] . "<br />";
					if (!empty($dod_adresa['jmeno']) || $dod_adresa['prijmeni'])
						echo $dod_adresa['jmeno'] . " " . $dod_adresa['prijmeni'] . "<br />";
					echo $dod_adresa['ulice'] . "<br />" . $dod_adresa['mesto'] . "<br />" . $dod_adresa['psc'] . "<br />" . $dod_adresa['stat'] . "<br />";
				} else {
					echo $temp['nazev_firmy'] . "<br />";
				echo $temp['ulice'] . "<br />" . $temp['mesto'] . ", " . $temp['psc'] . "<br />" . $temp['stat'];
				}
				?>
			</td>
		</tr>
		<tr style="font-size: 16px; vertical-align: top;">
			<td style="font-weight: bold;">
				IČO:
			</td>
			<td>
				<?
				echo $temp['ic'];
				?>
			</td>
			<td style="font-weight: bold;">
				DIČ:
			</td>
			<td>
				<?
				echo $temp['dic'];
				?>
			</td>
		</tr>
		<tr style="font-size: 16px; vertical-align: top;">
			<td colspan=2 style="font-weight: bold; text-align: center; padding: 20px;">
				Datum vystavení:
			</td>
			<td colspan=2 style="font-weight: bold; padding: 20px;">
				<?
				echo $datum_editace;
				?>
			</td>
		</tr>
		<tr style="font-size: 12px; vertical-align: top; font-weight: bold;">
			<td>
				Položka č.
			</td>
			<td>
				Druh výrobku
			</td>
			<td>
				Množství (ks)
			</td>
			<td>
				Poznámka
			</td>
		</tr>
		<?
		$pocet_polozek = 1;
		$vyrobky = $sql->query("SELECT nazev_vyrobku, dlv.pocet, dlv.poznamka, z.cislo_zakazky, z.rok rok_z FROM dod_lis_vyrobky dlv
								JOIN zak_vyrobky zv ON zv.id_zak_vyrobku = dlv.id_zak_vyrobku
								LEFT JOIN zakazky z ON z.id_zakazky = zv.id_zakazky
								WHERE id_dodaciho_listu='$_GET[id_dodaciho_listu]'");
		while ($vyrobek = $sql->fetch_array($vyrobky)){
			?>
			<tr style="font-size: 12px; vertical-align: top;">
				<td>
					<?echo $pocet_polozek;?>
				</td>
				<td>
					<?
					echo $vyrobek['nazev_vyrobku'];
					echo " - č.z. " . $vyrobek['cislo_zakazky'] . "/" . $vyrobek['rok_z'];
					?>
				</td>
				<td>
					<?
					$pocet = number_format($vyrobek['pocet'], 0, '.', ' ');
					echo $pocet;
					?>
				</td>
				<td>
					<?echo $vyrobek['poznamka'];?>
				</td>
			</tr>
			<?
			$pocet_polozek++;
		}
		if ($temp['pocet_europalet']>0){
			?>
			<tr style="font-size: 12px; vertical-align: top;">
				<td>
					<?echo $pocet_polozek;?>
				</td>
				<td>
					Europalet
				</td>
				<td>
					<?echo $temp['pocet_europalet'];?>
				</td>
				<td>
					
				</td>
			</tr>
			<?
			$pocet_polozek++;
		}
		while ($pocet_polozek<13){
			?>
			<tr style="font-size: 12px; vertical-align: top;">
				<td>
					<?echo $pocet_polozek;?>
				</td>
				<td>
					---
				</td>
				<td>
					---
				</td>
				<td>
					---
				</td>
			</tr>
			<?
			$pocet_polozek++;
		}
		?>
		<tr style="font-size: 14px; vertical-align: top; font-weight: bold;">
			<td colspan=2 rowspan=2 style="padding-bottom: 150px;">
				Razítko, podpis dodavatele
			</td>
			<td colspan=2 style="padding-bottom: 130px;">
				Podpis odběratele
			</td>
		</tr>
		<tr style="font-size: 14px; vertical-align: top; font-weight: bold;">
			<td colspan=2>
				Datum převzetí: 
			</td>
		</tr>
	</table>
	<?
}
?>