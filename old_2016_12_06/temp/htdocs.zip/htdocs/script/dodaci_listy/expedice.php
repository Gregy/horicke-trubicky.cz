<?
if (haveRight('DODACI_LISTY_EDITACE')){
	if (isset($_GET['id_firmy'])){
		$id_firmy = $_GET['id_firmy'];
		global $sql;
		
		if (isset($_GET['smaz_id'])){
			$datum_editace = Time();
			$sql->query("UPDATE dodaci_listy SET smazano=1, editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace' WHERE id_dodaciho_listu=$_GET[smaz_id]");
		}
		
		$temp=$sql->query_array("SELECT f.id_firmy, f.nazev_firmy FROM firmy f
								WHERE f.id_firmy = '$_GET[id_firmy]'");
		$id_firmy = $temp['id_firmy'];
		$nazev_firmy = $temp['nazev_firmy'];
	
		if (isset($_POST['save'])){
			$error="";
			$id_adresy = $_POST['id_adresy'];
			$pocet_europalet = $_POST['pocet_europalet'];
			
			$rows = $sql->query("SELECT zv.id_zak_vyrobku
								FROM zak_vyrobky zv
								JOIN zakazky z ON z.id_zakazky = zv.id_zakazky
								WHERE z.id_firmy=$id_firmy and zv.smazano=0 and z.id_stavu<600");
			$pocet_zadan=0;
			while ($row=$sql->fetch_array($rows)){
				if (!empty($_POST["pocet_$row[id_zak_vyrobku]"]) && (is_numeric($_POST["pocet_$row[id_zak_vyrobku]"]))){
					$pocet_zadan=1;
				}
			}
			if ($pocet_zadan==0){
				$error.="<p class=\"chyba\">Někde musí být zadán počet ks k expedici, nebo to není číslo.</p>";
			}
		}
		
		if ($error=="" && isset($_POST['save'])){
			$rows = $sql->query("SELECT id_zak_vyrobku, zv.id_zakazky FROM zak_vyrobky zv
								JOIN zakazky z ON z.id_zakazky = zv.id_zakazky
								WHERE z.id_firmy=$id_firmy and zv.smazano=0 and z.id_stavu<600");
			$datum_editace = Time();
			$rok = date('Y');
			$temp = $sql->query("SELECT cislo_dodaciho_listu max_cislo FROM dodaci_listy d WHERE d.smazano=1 AND NOT EXISTS (SELECT * FROM dodaci_listy WHERE rok = d.rok AND cislo_dodaciho_listu = d.cislo_dodaciho_listu AND smazano=0) ORDER BY cislo_dodaciho_listu DESC");
			if ($sql->num_rows($temp)>0){
				$temp = $sql->fetch_array($temp);
				$cislo = $temp['max_cislo'];
			} else {
				$cislo = $sql->query_array("SELECT max(cislo_dodaciho_listu) max_cislo FROM dodaci_listy WHERE rok=$rok");
				if ($cislo['max_cislo']>0){
					$cislo = $cislo['max_cislo']+1;
				} else {
					$cislo = 1;
				}
			}
			$sql->query("INSERT INTO dodaci_listy VALUES (NULL, '$id_firmy', '$cislo', '$rok', '$pocet_europalet', '$_SESSION[ot_userId]', '$datum_editace', 0)");
			$id_dodaciho_listu = $sql->insert_id();
			
			if ($id_adresy>0){
				$sql->query("INSERT INTO dod_lis_dodaci_adresy
							SELECT $id_dodaciho_listu, jmeno, prijmeni, nazev_adresy, ulice, mesto, psc, stat, poznamka, email, telefon
								FROM adresy 
							WHERE id_adresy=$id_adresy");
			}
			
			while ($row = $sql->fetch_array($rows)){
				$pocet = $_POST["pocet_$row[id_zak_vyrobku]"];
				$poznamka = $_POST["poznamka_$row[id_zak_vyrobku]"];
				if ($pocet>0){
					$sql->query("INSERT INTO dod_lis_vyrobky VALUES ('$id_dodaciho_listu', '$row[id_zak_vyrobku]', '$pocet', '$poznamka')");
					$temp = $sql->query_array("SELECT id_stavu FROM zakazky WHERE id_zakazky=$row[id_zakazky]");
					if ($temp['id_stavu']<500){
						$sql->query("UPDATE zakazky SET id_stavu=500, editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace' WHERE id_zakazky=$row[id_zakazky]");
					}
				}
			}
			
			$saved=1;
			echo "<p class=\"oznameni\">Dodací list v pořádku uložen.</p>";
			$refresh_page=$page->_head_path . "?show=dodaci_list&id_dodaciho_listu=$id_dodaciho_listu";
			echo "<meta http-equiv=\"refresh\" content=\"1; url=$refresh_page\">";
			message_auto_forward($refresh_page);
		} else if ($error!=""){
			echo "<hr /><b>" . $error . "</b><hr />";
		}

		if ($saved==0){
			?>
			<div style="text-align: center; padding: 5px; border-bottom: #aaa 1px dashed;">
				<span>
					<a href="?show=dodaci_listy" class="zpet">Na dodací listy</a>
				</span>
				<span style="padding-left: 100px">
					<a href="?show=zakazky" class="zpet">Na seznam zakázek</a>
				</span>
			</div>
			<div style="text-align: center; padding: 5px; border-bottom: #aaa 1px dashed;">
				<table cellspacing="0" cellpadding="1" border="0" width="100%" align="center">
					<tr>
						<td>Název firmy</td>
					</tr>
					<tr>
						<td style="vertical-align: top;">
							<b><?php echo $nazev_firmy;?></b>
						</td>
					</tr>
				</table>
			</div>
			<?
			$rows = $sql->query("SELECT zv.id_zak_vyrobku, zv.nazev_vyrobku, zv.pocet, z.cislo_zakazky, z.rok
								FROM zak_vyrobky zv
								JOIN zakazky z ON z.id_zakazky = zv.id_zakazky
								WHERE z.id_firmy=$id_firmy and zv.smazano=0 and z.id_stavu<600 AND z.rodic_zakazka=0");
			if ($sql->num_rows($rows)>0){
				$dodaci_adresy = $sql->query("SELECT id_adresy, jmeno, prijmeni, nazev_adresy, ulice, mesto, psc, stat, poznamka, email, telefon
												FROM adresy
											WHERE id_firmy=$id_firmy AND smazano=0");
				
				?>
				<div style="padding: 5px; border-bottom: #aaa 1px dashed; background-color: #eee;">
					<div style="font-size: 14px; font-weight: bold; color: #00F;">Nový dodací list</div>
					<form action="" method="post" name="zakazky">
						<table cellspacing="0" cellpadding="5" border="0" width="99%" align="center">
							<tr>
								<td><b>Dodací adresa</b></td>
								<td style="text-align: left;">
									<select name="id_adresy" >
										<OPTION value="0">Stejná jako fakturační.</OPTION>
										<?
										$dodaci_adresy = $sql->query("SELECT id_adresy, jmeno, prijmeni, nazev_adresy, ulice, mesto, psc, stat, poznamka, email, telefon
																		FROM adresy
																		WHERE id_firmy=$id_firmy AND smazano=0");
										while ($adresa=$sql->fetch_array($dodaci_adresy)){
											$text = $adresa['nazev_adresy'] . ' - ' . $adresa['jmeno'] . ' ' . $adresa['prijmeni'] . ', ' . $adresa['ulice'] . ', ' . $adresa['mesto'] 
													. ', ' . $adresa['psc'] . ', ' . $adresa['stat'];
											if ($adresa['id_adresy'] == $id_adresy){
												?>
												<OPTION value="<?echo $adresa['id_adresy'];?>" selected="selected"><?echo $text;?></OPTION>
												<?
											} else {
												?>
												<OPTION value="<?echo $adresa['id_adresy'];?>"><?echo $text;?></OPTION>
												<?
											}
										}
										?>
									</select>
								</td>
							</tr>
							<tr>
								<td><b>Počet europalet</b></td>
								<td style="text-align: left;">
									<input type="text" size="3" maxlength="5" autocomplete="off" name="pocet_europalet" value="<?echo $pocet_europalet;?>" />
								</td>
							</tr>
						<table cellspacing="0" cellpadding="5" border="0" width="99%" align="center">
							<tr>
								<td><b>Název výrobku</b></td>
								<td style="text-align: center;"><b>Číslo zakázky</b></td>
								<td style="text-align: center;"><b>Počet ks ve výrobě</b></td>
								<td style="text-align: center;"><b>Zadáno do výroby</b></td>
								<td style="text-align: center;"><b>Už vyexpedováno</b></td>
								<td style="text-align: center;"><b>Poznámka</b></td>
							</tr>
							<?
							$i=0;
							while ($row=$sql->fetch_array($rows)){
								(($i % 2)==0) ? $color="#CFC" : $color="#FFC";
								$i++;
								$datum_editace = StrFTime("%d.%m.%Y %H:%M", $row['datum_editace']);
								?>
								<tr style="background-color: <?echo $color;?>;">
									<td>
										<? echo $row['nazev_vyrobku'];?>
									</td>
									<td style="text-align: center;">
										<?echo $row['cislo_zakazky'] . "/" . $row['rok'];?>
									</td>
									<td style="text-align: center; width: 120px;">
										<?
										if (!empty($_POST["pocet_$row[id_zak_vyrobku]"])){
											$pocet=$_POST["pocet_$row[id_zak_vyrobku]"];
										} else {
											$pocet='';
										}
										$cislo = $sql->query_array("SELECT sum(dlv.pocet) pocet FROM dodaci_listy dl
																	JOIN dod_lis_vyrobky dlv ON dlv.id_dodaciho_listu = dl.id_dodaciho_listu
																	WHERE dl.smazano=0 AND dlv.id_zak_vyrobku=$row[id_zak_vyrobku]");
										$expedovano = $cislo['pocet'];
										?>
										<input type="text" size="4" maxlength="7" autocomplete="off" name="pocet_<?echo $row['id_zak_vyrobku'];?>" id="pocet_<?echo $row['id_zak_vyrobku'];?>" value="<?echo $pocet;?>" onkeyup="pocet_exp(<?echo $row['pocet']-$expedovano;?>, <?echo $row['id_zak_vyrobku'];?>)" />
										<div id="pocet_div_<?echo $row['id_zak_vyrobku'];?>"></div>
									</td>
									<td style="text-align: center;">
										<?
										$pocet = number_format($row['pocet'], 0, '.', ' ');
										echo $pocet;
										?>
									</td>
									<td style="text-align: center;">
										<?
										$expedovano = number_format($expedovano, 0, '.', ' ');
										echo $expedovano;
										?>
									</td>
									<td style="text-align: center;">
										<?
										if (!empty($_POST["poznamka_$row[id_zak_vyrobku]"])){
											$poznamka=$_POST["poznamka_$row[id_zak_vyrobku]"];
										} else {
											$poznamka='';
										}
										?>
										<input type="text" size="20" maxlength="100" name="poznamka_<?echo $row['id_zak_vyrobku'];?>" value="<?echo $poznamka;?>" />
									</td>
								</tr>
								<?
							}
							?>
						</table>
						<input type="submit" name="save" value="Vytvořit dodací list" id="ulozit" />
					</form>
				</div>
				<?php
			} else echo "<p class=\"oznameni\">Tato firma nemá žádné výrobky k expedici.</p>";
		}
	} else {
		?>
		<form action="" method="get" name="expedice">
			<div style="text-align: center; padding: 5px; border-bottom: #aaa 1px dashed;">
				<span>
					<a href="?show=dodaci_listy" class="zpet">Zpět na dodací listy</a>
				</span>
			</div>
			<input type="hidden" name="show" value="expedice">
			<table cellspacing="0" cellpadding="5" border="0" width="50%" align="center">
				<tr>
					<td><b>Pro firmu</b> (*)</td>
					<td>
						<select id="id_firmy" name="id_firmy" onchange="ajax('script/vyrobky/aj_nacist_vys_formy.php?id_firmy='+document.getElementById('id_firmy').value,'vys_formy');">
							<OPTION value="0">Vyberte možnost...</OPTION>
							<?
							$result=$sql->query("SELECT f.id_firmy, f.nazev_firmy FROM firmy f
												WHERE smazano=0
												ORDER BY f.nazev_firmy");
							while ($row=$sql->fetch_array($result)){
								if ($row['id_firmy'] == $id_firmy){
									?>
									<OPTION value="<?echo $row['id_firmy'];?>" selected="selected"><?echo $row['nazev_firmy'];?></OPTION>
									<?
								} else {
									?>
									<OPTION value="<?echo $row['id_firmy'];?>"><?echo $row['nazev_firmy'];?></OPTION>
									<?
								}
							}
							?>
						</select>
					</td>
				</tr>
				<tr>
					<td></td>
					<td><input type="submit" name="save" value="Potvrdit firmu" id="ulozit" /></td>
				</tr>
			</table>
		</form>
		<?
	}
} else echo "<p class=\"chyba\">Na toto nemáte přiřazená práva.</p>";