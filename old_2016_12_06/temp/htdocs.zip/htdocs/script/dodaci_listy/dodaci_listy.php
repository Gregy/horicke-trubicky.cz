<?
if (haveRight("DODACI_LISTY")){
	$datum_editace = Time();
	
	if (isset($_GET['dl_cislo_zakazky'])){
		$_SESSION['filtr_dod_listu']['dl_cislo_zakazky'] = $_GET['dl_cislo_zakazky'];
	}
	if (isset($_GET['rok_z'])){
		$_SESSION['filtr_dod_listu']['rok_z'] = $_GET['rok_z'];
	}
	if (isset($_GET['id_firmy'])){
		$_SESSION['filtr_dod_listu']['filtr_id_firmy'] = $_GET['id_firmy'];
	}
	if (isset($_GET['cislo_dodaciho_listu'])){
		$_SESSION['filtr_dod_listu']['cislo_dodaciho_listu'] = $_GET['cislo_dodaciho_listu'];
	}
	if (isset($_GET['rok_dl'])){
		$_SESSION['filtr_dod_listu']['rok_dl'] = $_GET['rok_dl'];
	}
	if (isset($_GET['nazev_vyrobku'])){
		$_SESSION['filtr_dod_listu']['nazev_vyrobku'] = $_GET['nazev_vyrobku'];
	}
	
	if (isset($_GET['zrus_filtr'])){
		unset($_SESSION['filtr_dod_listu']);
	}
	
	if (haveRight("DODACI_LISTY_EDITACE")){
		if (isset($_GET['smaz_id'])){
			$sql->query("UPDATE dodaci_listy SET smazano=1, editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace' WHERE id_dodaciho_listu=$_GET[smaz_id]");
		}
	}
	
	if (haveRight("DODACI_LISTY_EDITACE")){
		?>
		<div style="width: 100%; text-align:center; padding-bottom: 5px; margin-bottom: 5px; font-size: 15px; border-bottom: 1px dashed;">
			<a href="?show=expedice">Nový dodací list</a>
		</div>
		<?
	}
	?>
	<div onclick="ukaz_skryj('filtr_dod_listu');" style="cursor: pointer;">
		Zobraz / skryj filtr
		<?
		if (!empty($_SESSION['filtr_dod_listu']['dl_cislo_zakazky']) || !empty($_SESSION['filtr_dod_listu']['rok_z']) || !empty($_SESSION['filtr_dod_listu']['filtr_id_firmy'])
			|| !empty($_SESSION['filtr_dod_listu']['cislo_dodaciho_listu']) || !empty($_SESSION['filtr_dod_listu']['rok_dl']) || !empty($_SESSION['filtr_dod_listu']['nazev_vyrobku'])){
				?> 
				<span style="padding-left: 200px; color: #D55; font-weight: bold;">Filtr je AKTIVNÍ</span>
				<a href="?show=dodaci_listy&zrus_filtr=1" style="margin-left: 200px; color: #555; font-weight: bold;">Zrušit filtr</a>
				<?
		}
		?>
	</div>
	<div id="filtr_dod_listu" style="display: none;">
		<form action="" method="GET">
			<input type="hidden" name="show" value="dodaci_listy">
			<table cellspacing="0" cellpadding="5" border="0" width="60%">
				<tr>
					<td>
						<b>Číslo dodacího listu / rok</b>
					</td>
					<td>
						<input id="cislo_dodaciho_listu" name="cislo_dodaciho_listu" type="text" value="<?echo $_SESSION['filtr_dod_listu']['cislo_dodaciho_listu'];?>" size="5" maxlength="5" />
						/
						<input id="rok_dl" name="rok_dl" type="text" value="<?echo $_SESSION['filtr_dod_listu']['rok_dl'];?>" size="5" maxlength="5" />
					</td>
				</tr>
				<tr>
					<td>
						<b>Pro firmu</b>
					</td>
					<td>
						<select id="id_firmy" name="id_firmy" onchange="ajax('script/dodaci_listy/aj_nacist_vyrobky.php?id_firmy='+document.getElementById('id_firmy').value,'filtr_id_vyrobku');">
							<OPTION value="0">Vyberte možnost...</OPTION>
							<?
							$result=$sql->query("SELECT id_firmy, nazev_firmy FROM firmy
												ORDER BY nazev_firmy");
							while ($row=$sql->fetch_array($result)){
								if ($row['id_firmy'] == $_SESSION['filtr_dod_listu']['filtr_id_firmy']){
									?>
									<OPTION value="<?echo $row['id_firmy'];?>" selected="selected"><?echo $row['nazev_firmy'];?></OPTION>
									<?
								} else {
									?>
									<OPTION value="<?echo $row['id_firmy'];?>"><?echo $row['nazev_firmy'];?></OPTION>
									<?
								}
							}
							?>
						</select>
					</td>
				</tr>
				<tr>
					<td><b>S výrobkem</b> (*)</td>
					<td>
						<div id="filtr_id_vyrobku">
							<select id="nazev_vyrobku" name="nazev_vyrobku">
								<OPTION value="0">Vyberte možnost...</OPTION>
								<?
								$temp_id_firmy =  $_SESSION['filtr_dod_listu']['filtr_id_firmy'];
								$result=$sql->query("SELECT distinct nazev_vyrobku FROM zak_vyrobky zv 
													JOIN zakazky z ON z.id_zakazky=zv.id_zakazky
													WHERE zv.smazano=0 AND id_firmy=$temp_id_firmy");
								while ($row=$sql->fetch_array($result)){
									?>
									<OPTION value="<?echo $row['nazev_vyrobku'];?>"><?echo $row['nazev_vyrobku'];?></OPTION>
									<?
								}
								?>
							</select>
						</div>
					</td>
				</tr>
			</table>
			<div style="padding: 5px;">
				<input type="submit" name="save" value="Použít filtr" id="inform" />
			</div>
		</form>
	</div>
	<?
	//$prvni=true;
	if (isset($_SESSION['filtr_dod_listu'])){
		if (!empty($_SESSION['filtr_dod_listu']['dl_cislo_zakazky'])){
			($prvni==false) ? $where .= " AND " : $where .= "";
			$where .= "z.cislo_zakazky=" . $_SESSION['filtr_dod_listu']['dl_cislo_zakazky'];
			$prvni=false;
		}
		if (!empty($_SESSION['filtr_dod_listu']['rok_z'])){
			($prvni==false) ? $where .= " AND " : $where .= "";
			$where .= "z.rok=" . $_SESSION['filtr_dod_listu']['rok_z'];
			$prvni=false;
		}
		if (!empty($_SESSION['filtr_dod_listu']['filtr_id_firmy'])){
			($prvni==false) ? $where .= " AND " : $where .= "";
			$where .= "z.id_firmy=" . $_SESSION['filtr_dod_listu']['filtr_id_firmy'];
			$prvni=false;
		}
		if (!empty($_SESSION['filtr_dod_listu']['cislo_dodaciho_listu'])){
			($prvni==false) ? $where .= " AND " : $where .= "";
			$where .= "dl.cislo_dodaciho_listu=" . $_SESSION['filtr_dod_listu']['cislo_dodaciho_listu'];
			$prvni=false;
		}
		if (!empty($_SESSION['filtr_dod_listu']['rok_dl'])){
			($prvni==false) ? $where .= " AND " : $where .= "";
			$aktualni_cas=Time();
			$where .= "dl.rok=" . $_SESSION['filtr_dod_listu']['rok_dl'];
			$prvni=false;
		}
		if (!empty($_SESSION['filtr_dod_listu']['nazev_vyrobku'])){
			($prvni==false) ? $where .= " AND " : $where .= "";
			$where .= "zv.nazev_vyrobku='" . $_SESSION['filtr_dod_listu']['nazev_vyrobku'] . "'";
			$prvni=false;
		}
	} else {
		$where = "AND dl.datum_editace>$datum_editace-2592000";
	}
	
	$where = " WHERE dl.smazano = 0 " . $where;
	
	$rows = $sql->query("SELECT distinct dl.id_dodaciho_listu, dl.cislo_dodaciho_listu, dl.rok rok_dl, z.nazev_firmy, dl.datum_editace FROM dodaci_listy dl
						JOIN dod_lis_vyrobky dlv ON dlv.id_dodaciho_listu = dl.id_dodaciho_listu
						JOIN zak_vyrobky zv ON zv.id_zak_vyrobku = dlv.id_zak_vyrobku
						JOIN zakazky z ON z.id_zakazky = zv.id_zakazky
						$where
						ORDER BY rok_dl DESC, dl.cislo_dodaciho_listu DESC");
	?>
	<table cellspacing="0" cellpadding="5" border="0" width="60%" align="center">
		<tr style="text-align:center; font-weight:bold; border-bottom: 1px solid #555;">
			<td style="width: 90px;">Číslo dod.listu</td>
			<td style="width: 50px;">Datum</td>
			<td style="width: 150px;">Název firmy</td>
			<td style="width: 50px;"></td>
			<td></td>
		</tr>
		<?
		$i=0;
		while ($row=$sql->fetch_array($rows)){
			(($i % 2)==0) ? $color="#b0ffb0" : $color="#FFF";
			$i++;
			$datum_editace = StrFTime("%d.%m.%Y", $row['datum_editace']);
			?>
			<tr style="text-align:center; background-color: <?echo $color;?>;">
				<td><?echo $row['cislo_dodaciho_listu'] . "/" . $row['rok_dl'];?></td>
				<td><?echo $datum_editace;?></td>
				<td><?echo $row['nazev_firmy'];?></td>
				<td>
					<a style="text-decoration: none;" href="?show=dodaci_list&id_zakazky=<?echo $row['id_zakazky'];?>&id_dodaciho_listu=<?echo $row['id_dodaciho_listu'];?>"><img src="files/show.png" title="Náhled na dodací list" height="18px" /></a>
				</td>
				<td style="width: 100px; text-align:center;">
					<?
					if (haveRight("DODACI_LISTY_EDITACE")){
						?>
						<span style="cursor: pointer;" id="odkaz_smazat_<?echo $row['id_dodaciho_listu'];?>"	onClick="ukaz_form_smazat(<?echo $row['id_dodaciho_listu'];?>)">
							<img src="files/smazat.png" height="16px">
						</span>
						<br />
						<span id="smazat_<?echo $row['id_dodaciho_listu'];?>" style="display: none;">
							<a href="?show=dodaci_listy&smaz_id=<?echo $row['id_dodaciho_listu'];?>">Ano</a>
							<a style="margin-left: 20px;" href="javascript:void(0)" onclick="skryj_form_smazat(<?echo $row['id_dodaciho_listu'];?>)">Ne</a>
						</span>
						<?
					}
					?>
				</td>
			</tr>
			<?
		}
		?>
	</table>
	<?
}
?>