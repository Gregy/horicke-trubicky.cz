<?
	require_once '../../classes/class_mysql.php';
	$sql=new mysql;
		
?>
	<select id="nazev_vyrobku" name="nazev_vyrobku">
		<OPTION value="0">Vyberte možnost...</OPTION>
		<?
		$temp_id_firmy =  $_GET['id_firmy'];
		$result=$sql->query("SELECT distinct nazev_vyrobku FROM zak_vyrobky zv 
							JOIN zakazky z ON z.id_zakazky=zv.id_zakazky
							WHERE zv.smazano=0 AND id_firmy=$temp_id_firmy");
		while ($row=$sql->fetch_array($result)){
			?>
			<OPTION value="<?echo $row['nazev_vyrobku'];?>"><?echo $row['nazev_vyrobku'];?></OPTION>
			<?
		}
		?>
	</select>
	