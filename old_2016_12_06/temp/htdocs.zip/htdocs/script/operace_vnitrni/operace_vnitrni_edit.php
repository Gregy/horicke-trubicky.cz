<div class="definice">
<?
if (haveRight('OPERACE_VNITRNI')){
	if (isset($_GET['id_operace_vnitrni'])){
		global $sql;
		$temp=$sql->query_array("SELECT id_operace_vnitrni, nazev_operace_vnitrni, pocet_radku FROM operace_vnitrni WHERE id_operace_vnitrni='$_GET[id_operace_vnitrni]'");
		$id_operace_vnitrni = $temp['id_operace_vnitrni'];
		$nazev_operace_vnitrni = $temp['nazev_operace_vnitrni'];
		$pocet_radku = $temp['pocet_radku'];
	}
	
	if ($_POST['save']=="Uložit"){
		$error="";
		if (isset($_POST['id_operace_vnitrni']))
			$id_operace_vnitrni = $_POST['id_operace_vnitrni'];
		$nazev_operace_vnitrni = $_POST['nazev_operace_vnitrni'];
		$pocet_radku = $_POST['pocet_radku'];
		
		$error.=(empty($nazev_operace_vnitrni)) ? "<p class=\"chyba\">Nebyl zadán název operace.</p>" : "";
		//$error.=(empty($pocet_radku)) ? "<p class=\"chyba\">Nebyl zadán počet řádků.</p>" : "";
	}
	
		if ($error=="" && $_POST['save']=="Uložit"){
			$nazev_operace_vnitrni=check_input($nazev_operace_vnitrni);
			$datum_editace = Time();
			if (isset($id_operace_vnitrni)){
				$sql->query("UPDATE operace_vnitrni SET nazev_operace_vnitrni='$nazev_operace_vnitrni', pocet_radku='$pocet_radku', editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace' WHERE id_operace_vnitrni=$id_operace_vnitrni");
			} else {
				$temp = $sql->query_array("SELECT max(poradi) max_poradi FROM operace_vnitrni");
				$max_poradi = $temp['max_poradi']+100;
				$sql->query("INSERT INTO operace_vnitrni VALUES (NULL, '$nazev_operace_vnitrni', $max_poradi, '$_SESSION[ot_userId]', '$datum_editace', '0', '$pocet_radku')");
				$id_operace_vnitrni=$sql->insert_id();
			}
			
			$saved=1;
			echo "<p class=\"oznameni\">Vnitřní operace v pořádku uložena.</p>";
			$refresh_page=$page->_head_path . "?show=operace_vnitrni";
			echo "<meta http-equiv=\"refresh\" content=\"1; url=$refresh_page\">";
			message_auto_forward($refresh_page);
		} else if ($error!=""){
			echo "<hr /><b>" . $error . "</b><hr />";
		}
		if ($saved==0){
			?>
			<form action="" method="post" name="operace_vnitrni">
				<div style="text-align: center; padding: 5px; border-bottom: #aaa 1px dashed;">
					<input type="submit" name="save" value="Uložit" id="ulozit" />
					<span style="padding-left: 100px">
						<a href="?show=operace_vnitrni" class="zpet">Zpět na seznam vnitřních operací (bez uložení)</a>
					</span>
				</div>
				
				<?php
					if (isset($id_operace_vnitrni)){
						?>
						<input type="hidden" name="id_operace_vnitrni" value="<?echo $id_operace_vnitrni;?>" />
						<?
					}
				?>
				<table cellspacing="0" cellpadding="5" border="0" width="50%" align="center">
					<tr>
						<td><b>Název vnitřní operace</b> (*)</td>
						<td><input id="nazev_operace_vnitrni" type="text" size="30" maxlength="100" name="nazev_operace_vnitrni" value="<?php echo "$nazev_operace_vnitrni";?>" /></td>
					</tr>
					<tr>
						<td><b>Počet řádků</b> (*)</td>
						<td><input id="pocet_radku" type="text" size="3" maxlength="5" name="pocet_radku" value="<?php echo "$pocet_radku";?>" /></td>
					</tr>
				</table>
				<br />(*) - povinné položky
			</form>
			<script type="text/javascript"> document.getElementById("nazev_operace_vnitrni").focus(); </script>
			<?php
		}
} else echo "<p class=\"chyba\">Na toto nemáte přiřazená práva.</p>";
?>
</div>