<div class="definice">
<?
if (haveRight('OPERACE_VNITRNI')){
	include_once 'script/main/submenu.php';
	if (isset($_GET['smaz_id'])){
		$datum_editace = Time();
		$temp = $sql->query("SELECT v.nazev_vyrobku, f.nazev_firmy FROM vyrobek_operace_vnitrni vo
							JOIN vyrobky v ON v.id_vyrobku = vo.id_vyrobku
							JOIN firmy f ON f.id_firmy = v.id_firmy
							WHERE vo.id_operace_vnitrni=$_GET[smaz_id]");
		if ($sql->num_rows($temp)>0){
			echo "<p class=\"chyba\">Operace nelze smazat. Je použita v definici následujících výrobků.</p>";
			while ($row=$sql->fetch_array($temp)){	
				echo "<p class=\"chyba\">$row[nazev_firmy] - $row[nazev_vyrobku].</p>";
			}
		} else {
			$sql->query("UPDATE operace_vnitrni SET smazano=1, editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace' WHERE id_operace_vnitrni=$_GET[smaz_id]");
		}
	}
	
	//posouvani operaci ZACATEK
	if (isset($_GET['posun_nahoru'])){
		$datum_editace = Time();
		$temp = $sql->query_array("select id_operace_vnitrni, poradi from operace_vnitrni where id_operace_vnitrni=$_GET[posun_nahoru]");
		$id_operace_vnitrni = $temp['id_operace_vnitrni'];
		$poradi_old = $temp['poradi'];
		
		$rows = $sql->query("SELECT poradi FROM operace_vnitrni 
							WHERE poradi<$poradi_old
							ORDER BY poradi DESC
							LIMIT 2");
		if ($sql->num_rows($rows)>1){
			$poradi_1 = $sql->fetch_array($rows);
			$poradi_1 = $poradi_1['poradi'];
			$poradi_2 = $sql->fetch_array($rows);
			$poradi_2 = $poradi_2['poradi'];
			$poradi_new = $poradi_1 - (int)(($poradi_1 - $poradi_2) / 2);
			$sql->query("UPDATE operace_vnitrni SET poradi = $poradi_new, editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace' WHERE id_operace_vnitrni=$_GET[posun_nahoru]");
		} else if ($sql->num_rows($rows)>0){
			$poradi_1 = $sql->fetch_array($rows);
			$poradi_new = $poradi_1['poradi'] - 50;
			$sql->query("UPDATE operace_vnitrni SET poradi = $poradi_new, editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace' WHERE id_operace_vnitrni=$_GET[posun_nahoru]");
		}
	}

	if (isset($_GET['posun_dolu'])){
		$datum_editace = Time();
		$temp = $sql->query_array("select id_operace_vnitrni, poradi from operace_vnitrni where id_operace_vnitrni=$_GET[posun_dolu]");
		$id_operace_vnitrni = $temp['id_operace_vnitrni'];
		$poradi_old = $temp['poradi'];
		
		$rows = $sql->query("SELECT poradi FROM operace_vnitrni 
							WHERE poradi>$poradi_old
							ORDER BY poradi
							LIMIT 2");
		if ($sql->num_rows($rows)>1){
			$poradi_1 = $sql->fetch_array($rows);
			$poradi_1 = $poradi_1['poradi'];
			$poradi_2 = $sql->fetch_array($rows);
			$poradi_2 = $poradi_2['poradi'];
			$poradi_new = $poradi_2 - (int)(($poradi_2 - $poradi_1) / 2);
			$sql->query("UPDATE operace_vnitrni SET poradi = $poradi_new, editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace' WHERE id_operace_vnitrni=$_GET[posun_dolu]");
			echo "1<br />";
		} else if ($sql->num_rows($rows)>0){
			$poradi_1 = $sql->fetch_array($rows);
			$poradi_new = $poradi_1['poradi'] + 50;
			$sql->query("UPDATE operace_vnitrni SET poradi = $poradi_new, editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace' WHERE id_operace_vnitrni=$_GET[posun_dolu]");
			echo "2<br />";
		}
	}
	//posouvani operaci KONEC
	
	?>
	<div style="width: 100%; text-align:center; padding-bottom: 5px; font-size: 15px;">
		<div class="hlavicka"><a href="?show=operace_vnitrni_edit">Nová vnitřní operace</a></div>
	</div>
	<?
	$rows = $sql->query("SELECT o.id_operace_vnitrni, o.nazev_operace_vnitrni, o.datum_editace, u.name editoval FROM `operace_vnitrni` o
							JOIN `user` u ON u.id_uzivatel = o.editoval
						WHERE o.smazano=0
						ORDER BY o.poradi");
						
	?>
	<table cellspacing="0" cellpadding="5" border="0" width="50%" align="center">
		<?
		$i=0;
		while ($row=$sql->fetch_array($rows)){
			(($i % 2)==0) ? $color="#baeeff" : $color="#EEE";
			$i++;
			$datum_editace = StrFTime("%d.%m.%Y %H:%M", $row['datum_editace']);
			?>
			<tr style="text-align:center; background-color: <?echo $color;?>;">
				<td style="text-align:left;">
					<?echo $row['nazev_operace_vnitrni'];?>
				</td>
				<td>
					<a href="?show=operace_vnitrni&posun_nahoru=<?echo $row['id_operace_vnitrni'];?>"><img src="files/sipka_nahoru.png" height="15px" title="Posunout nahoru" /></a><br />
					<a href="?show=operace_vnitrni&posun_dolu=<?echo $row['id_operace_vnitrni'];?>"><img src="files/sipka_dolu.png" height="15px" title="Posunout dolu" /></a>
				</td>
				<td>
					<a href="?show=operace_vnitrni_edit&id_operace_vnitrni=<?echo $row['id_operace_vnitrni'];?>" style="text-decoration: none;" title="Naposledy editoval(a) <?echo $row['editoval'] . ' ' . $datum_editace;?>"><img src="files/edit.png" height="16px"></a>
				</td>
				<td style="width: 100px;">
					<span style="cursor: pointer;" id="odkaz_smazat_<?echo $row['id_operace_vnitrni'];?>"	onClick="ukaz_form_smazat(<?echo $row['id_operace_vnitrni'];?>)">
						<img src="files/smazat.png" height="16px">
					</span>
					<br />
					<span id="smazat_<?echo $row['id_operace_vnitrni'];?>" style="display: none;">
						<a href="?show=operace_vnitrni&smaz_id=<?echo $row['id_operace_vnitrni'];?>">Ano</a>
						<a style="margin-left: 20px;" href="javascript:void(0)" onclick="skryj_form_smazat(<?echo $row['id_operace_vnitrni'];?>)">Ne</a>
					</span>
				</td>
			</tr>
			<?
		}
		?>
	</table>
	<?
} else echo "<p class=\"chyba\">Na toto nemáte přiřazená práva.</p>";
?>
</div>