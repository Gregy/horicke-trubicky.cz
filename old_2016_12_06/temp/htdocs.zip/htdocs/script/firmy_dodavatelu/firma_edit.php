<div class="definice">
<?
if (haveRight('FIRMY_DODAVATELU')){
	if (isset($_GET['id_firmy'])){
		global $sql;
		$temp = $sql->query_array("SELECT id_firmy, nazev_firmy, ulice, mesto, psc, stat, telefon, email, bank_uc_pred, bank_uc_za, ic, dic, spec_symb, kontaktni_osoba FROM firmy_dodavatelu WHERE id_firmy='$_GET[id_firmy]'");
		$id_firmy = $temp['id_firmy'];
		$nazev_firmy = $temp['nazev_firmy'];
		$ulice = $temp['ulice'];
		$mesto = $temp['mesto'];
		$psc = $temp['psc'];
		$stat = $temp['stat'];
		$telefon = $temp['telefon'];
		$email = $temp['email'];
		$bank_uc_pred = $temp['bank_uc_pred'];
		$bank_uc_za = $temp['bank_uc_za'];
		$ic = $temp['ic'];
		$dic = $temp['dic'];
		$spec_symb = $temp['spec_symb'];
		$kontaktni_osoba = $temp['kontaktni_osoba'];
	}
	
	if ($_POST['save']=="Uložit"){
		$error="";
		if (isset($_POST['id_firmy']))
			$id_firmy = $_POST['id_firmy'];
		$nazev_firmy = $_POST['nazev_firmy'];
		$ulice = $_POST['ulice'];
		$mesto = $_POST['mesto'];
		$psc = $_POST['psc'];
		$stat = $_POST['stat'];
		$telefon = $_POST['telefon'];
		$email = $_POST['email'];
		$bank_uc_pred = $_POST['bank_uc_pred'];
		$bank_uc_za = $_POST['bank_uc_za'];
		$ic = $_POST['ic'];
		$dic = $_POST['dic'];
		$spec_symb = $_POST['spec_symb'];
		$kontaktni_osoba = $_POST['kontaktni_osoba'];
		
		$error.=(empty($nazev_firmy)) ? "<p class=\"chyba\">Nebyl zadán název firmy.</p>" : "";
		$error.=(empty($ulice)) ? "<p class=\"chyba\">Nebyla zadána ulice.</p>" : "";
		$error.=(empty($mesto)) ? "<p class=\"chyba\">Nebylo zadáno město.</p>" : "";
		$error.=(empty($psc)) ? "<p class=\"chyba\">Nebylo zadáno PSČ.</p>" : "";
		$error.=(empty($stat)) ? "<p class=\"chyba\">Nebyl zadán stát.</p>" : "";
		//$error.=(empty($email)) ? "<p class=\"chyba\">Nebyl zadán email.</p>" : "";
	}
	
	if ($error=="" && $_POST['save']=="Uložit"){
		$nazev_firmy=check_input($nazev_firmy);
		$datum_editace = Time();
		if (isset($id_firmy)){
			$sql->query("UPDATE firmy_dodavatelu SET nazev_firmy='$nazev_firmy', editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace', ulice='$ulice', mesto='$mesto', 
							psc='$psc',  stat='$stat',  telefon='$telefon',  email='$email',  bank_uc_pred='$bank_uc_pred',  bank_uc_za='$bank_uc_za', ic='$ic', dic='$dic', spec_symb='$spec_symb',
							kontaktni_osoba='$kontaktni_osoba' WHERE id_firmy=$id_firmy");
		} else {
				$sql->query("INSERT INTO firmy_dodavatelu VALUES (NULL, '$nazev_firmy', '$_SESSION[ot_userId]', '$datum_editace', '0', '$ulice', '$mesto', '$psc', '$stat', '$telefon', '$email', '$ic', '$dic', '$bank_uc_pred', '$bank_uc_za', '$spec_symb', '$kontaktni_osoba')");
				$id_firmy=$sql->insert_id();
		}
		
		if (isset($_GET['id_zakazky'])){
			$sql->query("UPDATE zakazky SET nazev_firmy='$nazev_firmy', editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace', ulice='$ulice', mesto='$mesto', 
							psc='$psc', stat='$stat', telefon='$telefon', email='$email', bank_uc_pred='$bank_uc_pred',  bank_uc_za='$bank_uc_za', ic='$ic', dic='$dic', spec_symb='$spec_symb',
							kontaktni_osoba='$kontaktni_osoba' WHERE id_zakazky=$_GET[id_zakazky]");
		}
		
		$saved=1;
		echo "<p class=\"oznameni\">Dodavatel v pořádku uložen.</p>";
		$refresh_page=$page->_head_path . "?show=firmy_dodavatelu";
		echo "<meta http-equiv=\"refresh\" content=\"1; url=$refresh_page\">";
		message_auto_forward($refresh_page);
	} else if ($error!=""){
		echo "<hr /><b>" . $error . "</b><hr />";
	}
		
		if ($saved==0){
			?>
			<form action="" method="post" name="firma">
				<div style="text-align: center; padding: 5px; border-bottom: #aaa 1px dashed;">
					<input type="submit" name="save" value="Uložit" id="ulozit" />
					<span style="padding-left: 100px">
						<a href="?show=firmy_dodavatelu" class="zpet">Zpět na seznam dodavatelů (bez uložení)</a>
					</span>
				</div>
				
				<?php
					if (isset($id_firmy)){
						?>
						<input type="hidden" name="id_firmy" value="<?echo $id_firmy;?>" />
						<?
					}
				?>
				<table cellspacing="0" cellpadding="5" border="0" width="100%" align="center">
					<tr>
						<td style="text-align: right"><b>Název dodavatele</b> (*)</td>
						<td colspan=2><input id="nazev_firmy" type="text" size="50" maxlength="100" name="nazev_firmy" value="<?php echo "$nazev_firmy";?>" /></td>
					</tr>
					<tr>
						<td colspan=3 style="font-weight: bold; color: #00F;">Fakturační adresa:</td>
					</tr>
					<tr>
						<td><b>Ulice</b> (*)<br /><input id="ulice" type="text" size="30" maxlength="100" name="ulice" value="<?php echo "$ulice";?>" /></td>
						<td><b>Telefon</b><br /><input id="telefon" type="text" size="20" maxlength="20" name="telefon" value="<?php echo "$telefon";?>" /></td>
						<td><b>IČ</b><br /><input id="ic" type="text" size="10" maxlength="20" name="ic" value="<?php echo "$ic";?>" /></td>
					</tr>
					<tr>
						<td><b>Město</b> (*)<br /><input id="mesto" type="text" size="30" maxlength="100" name="mesto" value="<?php echo "$mesto";?>" /></td>
						<td><b>Email</b><br /><input id="email" type="text" size="30" maxlength="100" name="email" value="<?php echo "$email";?>" /></td>
						<td><b>DIČ</b><br /><input id="dic" type="text" size="10" maxlength="20" name="dic" value="<?php echo "$dic";?>" /></td>
					</tr>
					<tr>
						<td><b>PSČ</b> (*)<br /><input id="psc" type="text" size="5" maxlength="10" name="psc" value="<?php echo "$psc";?>" /></td>
						<td><b>Bankovní účet</b><br /><input id="bank_uc_pred" type="text" size="10" maxlength="15" name="bank_uc_pred" value="<?php echo "$bank_uc_pred";?>" /> / <input id="bank_uc_za" type="text" size="5" maxlength="4" name="bank_uc_za" value="<?php echo "$bank_uc_za";?>" /></td>
						<td><b>Specifický symbol</b><br /><input id="spec_symb" type="text" size="20" maxlength="50" name="spec_symb" value="<?php echo "$spec_symb";?>" /></td>
					</tr>
					<tr>
						<td><b>Stát</b> (*)<br /><input id="stat" type="text" size="5" maxlength="50" name="stat" value="<?php echo "$stat";?>" /></td>
						<td><b>Kontaktní osoba</b><br /><input id="kontaktni_osoba" type="text" size="30" maxlength="100" name="kontaktni_osoba" value="<?php echo "$kontaktni_osoba";?>" /></td>
						<td></td>
					</tr>
				</table>
				<script type="text/javascript"> document.getElementById("nazev_firmy").focus(); </script>
			</form>
			<br /><br />(*) - povinné položky
			<?
		}
} else echo "<p class=\"chyba\">Na toto nemáte přiřazená práva.</p>";
?>
</div>