<div class="definice">
<?
if (haveRight('FIRMY')){
	include_once 'script/main/submenu.php';
	
	if (isset($_GET['smaz_id'])){
		$datum_editace = Time();
		$sql->query("UPDATE firmy_dodavatelu SET smazano=1, editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace' WHERE id_firmy=$_GET[smaz_id]");
	}
	
	?>
	<div style="width: 100%; text-align:center; padding-bottom: 5px; font-size: 15px;">
		<div class="hlavicka" style="float: left;">
			<a href="?show=firma_dodavatelu_edit">Nový dodavatel</a>
		</div>
	</div>
	<?
	$rows = $sql->query("SELECT f.id_firmy, f.nazev_firmy, f.datum_editace, u.name editoval FROM firmy_dodavatelu f
							JOIN user u ON u.id_uzivatel = f.editoval
						WHERE f.smazano=0
						ORDER BY nazev_firmy");
						
	?>
	<table cellspacing="0" cellpadding="5" border="0" width="50%" align="center">
		<?
		$i=0;
		while ($row=$sql->fetch_array($rows)){
			(($i % 2)==0) ? $color="#ffd0fa" : $color="#fff5f5";
			$i++;
			$datum_editace = StrFTime("%d.%m.%Y %H:%M", $row['datum_editace']);
			?>
			<tr style="background-color: <?echo $color;?>;">
				<td>
					<span style="font-weight: bold;">
						<?echo $row['nazev_firmy'];?>
					</span>
				</td>
				<td>
					<a href="?show=firma_dodavatelu_edit&id_firmy=<?echo $row['id_firmy'];?>" style="text-decoration: none;" title="Naposledy editoval(a) <?echo $row['editoval'] . ' ' . $datum_editace;?>"><img src="files/edit.png" height="16px"></a>
				</td>
				<td style="width: 100px; text-align:center;">
					<span style="cursor: pointer;" id="odkaz_smazat_<?echo $row['id_firmy'];?>"	onClick="ukaz_form_smazat(<?echo $row['id_firmy'];?>)">
						<img src="files/smazat.png" height="16px">
					</span>
					<br />
					<span id="smazat_<?echo $row['id_firmy'];?>" style="display: none;">
						<a href="?show=firmy_dodavatelu&smaz_id=<?echo $row['id_firmy'];?>">Ano</a>
						<a style="margin-left: 20px;" href="javascript:void(0)" onclick="skryj_form_smazat(<?echo $row['id_firmy'];?>)">Ne</a>
					</span>
				</td>
			</tr>
			<?
		}
		?>
	</table>
	<?
} else echo "<p class=\"chyba\">Na toto nemáte přiřazená práva.</p>";
?>
</div>