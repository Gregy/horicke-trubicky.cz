<?php
	$saved=0;
	if (isset($_GET['id_uzivatel'])){
		global $sql;
		$temp=$sql->query_array("select * from user where id_uzivatel='$_GET[id_uzivatel]'");
		$id_uzivatel=$temp['id_uzivatel'];
		$name=$temp['name'];
		$blocked=$temp['blocked'];
		$email=$temp['email'];
		$password=$temp['password'];
	}
	
	if ($_POST['save']=="Uložit"){
		$error="";
		if (isset($_POST['id_uzivatel']))
			$id_uzivatel=$_POST['id_uzivatel'];
		$name=$_POST['name'];
		(isset($_POST['blocked'])) ? $blocked=1 : $blocked=0;
		$email=$_POST['email'];
		
		if (!isset($id_uzivatel)){
			if ($sql->num_rows($sql->query("select * from user where email='$email'"))>0)
				$error.="<p class=\"chyba\">Uživatel s tímto mailem již existuje.</p>";
		}
		
		$error.=(empty($name)) ? "<p class=\"chyba\">Nebylo zadáno jméno.</p>" : "";	
			
		if (($_POST['password1']!=$_POST['password2']) || ($_POST['password1']=="")){
			$error.="<p class=\"chyba\">Hesla se neshodují.</p>";
			$password="";
		}
		else if (($_POST['password1']==$_POST['password2']) && ($_POST['password1']!=""))
			$password=$_POST['password1'];
			
		if (!(ereg("^.+@.+\\..+$", $_POST['email'])))
			$error.="<p class=\"chyba\">Zadán špatný formát e-mailové adresy.</p>";
	}
	
	if (haveRight('UZIVATELE')=='1' || is_owner($temp['id_uzivatel'])=='1'){
		if ($error=="" && $_POST['save']=="Uložit"){
			$name=check_input($name);
			$email=check_input($email);
			if (isset($id_uzivatel)){
				$temp=$sql->query_array("select password from user where id_uzivatel='$id_uzivatel'");
				if ($temp['password']!=$password){
					$email_password=$password;
					$password=md5($password);
					$message="Dobry den,
	zmenil(a) jste si heslo.
	nick - $nick
	heslo - $email_password
	";
					mail($email, "Obal-tisk, s.r.o. výrobní software  - zmena hesla",$message);
				}
				$sql->query("update user set `password`='$password', `name`='$name', `email`='$email', `blocked`='$blocked' 
								where id_uzivatel='$id_uzivatel'");
				$id_user=$id_uzivatel;
			} else {
				$password=md5($password);
				$sql->query("insert into user values ('','$password','$name','$email','$blocked')");
				$id_user=$sql->insert_id();
			}
			if (haveRight('UZIVATELE')=='1'){
				$sql->query("DELETE FROM uzivatel_prava WHERE id_uzivatel='$id_user'");
				$rows = $sql->query("SELECT * FROM prava");
				
				while ($row=$sql->fetch_array($rows)){
					$id_right = $row['id_pravo'];
					if (isset($_POST["pravo$id_right"])){
						$sql->query("INSERT INTO uzivatel_prava VALUES ($id_user, $id_right)");
					}
				}
			}
			$saved=1;
			echo "<p class=\"oznameni\">Uživatel v pořádku uložen.</p>";
			$refresh_page=$page->_head_path . "?show=users";
			echo "<meta http-equiv=\"refresh\" content=\"1; url=$refresh_page\">";
			message_auto_forward($refresh_page);
		} else if ($error!=""){
			echo "<hr /><b>" . $error . "</b><hr />";
		}
		if ($saved==0){
?>
		<form action="" method="post" >
			<div style="text-align:center;">
				<input type="submit" name="save" value="Uložit" id="ulozit" />
			</div>
			
			<?php
				if (isset($id)){
					echo "<input type=\"hidden\" name=\"id\" value=\"$id\" />";
				}
			?>
			<table cellspacing="0" cellpadding="5" border="0" width="90%">
				<tr>
					<td style="text-align: right;"><b>Jméno</b> (*)</td>
					<td><input type="text" size="30" name="name" value="<?php echo "$name";?>" /></td>
				</tr>
				<?php
					echo "<tr>";
						echo "<td style=\"text-align: right;\"><b>Heslo</b> (*)</td>";
						echo "<td><input type=\"password\" size=\"30\" name=\"password1\" value=\"$password\" /></td>";
					echo "</tr>";
					
					echo "<tr>";
						echo "<td style=\"text-align: right;\"><b>Heslo znovu</b> (*)</td>";
						echo "<td><input type=\"password\" size=\"30\" name=\"password2\" value=\"$password\" /></td>";
					echo "</tr>";
				
					echo "<tr>";
						echo "<td style=\"text-align: right;\"><b>Uživatel blokován</b></td>";
						if ($blocked==0){
							echo "<td><input type=\"checkbox\" size=2 name=\"blocked\" /></td>";
						} else {
							
							echo "<td><input type=\"checkbox\" size=2 name=\"blocked\" checked=\"checked\" /></td>";
						}
					echo "</tr>";
				?>
				<tr>
					<td style="text-align: right;"><b>E-mail</b> (*)</td>
					<td><input type="text" size="30" name="email" value="<?php echo "$email";?>" /></td>
				</tr>
				<?
				if (haveRight('UZIVATELE')=='1'){
					$rows = $sql->query("SELECT * FROM prava ORDER BY pravo");
					?>
					<tr>
						<td style="text-align: right;">Práva</td>
						<td></td>
					</tr>
					<?
					while ($row=$sql->fetch_array($rows)){
						$temp=$sql->query_array("SELECT count(*) pocet FROM prava p
												JOIN uzivatel_prava up ON p.id_pravo = up.id_pravo
													WHERE up.id_uzivatel='$_GET[id_uzivatel]' AND p.pravo='$row[pravo]'");
						($temp['pocet']>0) ? $checked='checked="checked"' : $checked="";
						?>
						<tr>
							<td style="text-align: right;"><b><?echo $row['pravo']?></b></td>
							<td><input type="checkbox" size=2 name="pravo<?echo $row['id_pravo']?>" <?echo $checked;?> /></td>
						</tr>
						<?
					}
				}
					?>
			</table>
			
			<br />(*) - povinné položky
		</form>

<?php
		}
	} else echo "<p class=\"chyba\">Na toto nemáte přiřazená práva.</p>";
?>