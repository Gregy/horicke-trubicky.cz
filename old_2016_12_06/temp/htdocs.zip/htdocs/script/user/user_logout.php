<?php
	unset ($_SESSION['ot_userId']);
	session_destroy();
	
	echo "<p class=\"oznameni\">Byli jste úspěšně odhlášeni.</p>";
	
	$refresh_page=$page->_head_path;
	echo "<meta http-equiv=\"refresh\" content=\"1; url=$refresh_page\">";
	message_auto_forward($refresh_page);
?>