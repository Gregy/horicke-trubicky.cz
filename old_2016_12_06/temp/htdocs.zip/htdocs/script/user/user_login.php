<?php 
	$loged=0;
	if ($_POST['login']=="Přihlásit"){
		$email=check_input($_POST['email']);
		$password=md5($_POST['password']);
		$result=$sql->query("select * from user where email='$email' and password='$password'");
		if ($sql->num_rows($result)>0){
			$temp=$sql->fetch_array($result);
			if ($temp['blocked']==0){
				$loged=1;
				$_SESSION['ot_userId']=$temp['id_uzivatel'];
				echo "<p class=\"oznameni\">Byl(a) jste úspěšně přihlášen do systému.</p>";
				$refresh_page=$_SESSION['refresh_page'];
				echo "<meta http-equiv=\"refresh\" content=\"1; url=$refresh_page\">";
				message_auto_forward($refresh_page);
			}	else echo "<hr width=\"35%\" align=\"left\" /><p class=\"chyba\">Uživatel blokován.</p><hr width=\"35%\" align=\"left\" />";		
		} else echo "<hr width=\"35%\" align=\"left\" /><p class=\"chyba\">Zadáno špatné uživatelské jméno nebo heslo</p><hr width=\"35%\" align=\"left\" />";
	} else $_SESSION['refresh_page']=$_SESSION['last_page'];
	if ($loged==0){
?>	
	<form action="" method="post">
		<table cellspacing="0" cellpadding="5" border="0" width="60%">
			<tr>
				<td align="center"><b>Email</b></td>
				<td><input id="email" type="text" size="30" name="email" value="<?php echo $email;?>" /></td>
			</tr>
			<tr>
				<td align="center"><b>Heslo</b></td>
				<td><input type="password" size="20" name="password" /></td>
			</tr>
			<tr>
				<td></td>
				<td><a href="index.php?show=forget_password">Zapomněli jste heslo?</a></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" name="login" value="Přihlásit" id="ulozit" /></td>
			</tr>
			
		</table>
	</form>
	<script type="text/javascript"> document.getElementById("email").focus(); </script>   
<?php 
	} 
?>
