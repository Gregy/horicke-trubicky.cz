<?php
	if (haveRight('UZIVATELE')=='1'){
	global $sql;
		$result=$sql->query("SELECT a.id_uzivatel, a.name, a.blocked
							FROM `user` AS a
							WHERE 1
							ORDER BY a.name");
		?>
		<div class="clanek">
			<div class="hlavicka"><a href="?show=user_edit">Nový uživatel</a></div>
			<div class="vnitrek">
			<?php
			if ($sql->num_rows($result)>0){
				?>
				<table cellspacing="0" cellpadding="5" border="0" width="50%" align="center">
					<tr style="text-align:center; font-weight:bold;">
						<td>Jméno</td>
						<td></td>
					</tr>
					<?php
					while ($temp=$sql->fetch_array($result)){
						(($i % 2)==0) ? $color="#ffff88" : $color="#FFF";
						$i++;
						?>
						<tr style="text-align:center; background-color: <?echo $color;?>;">
							<td><?php echo $temp['name'];?></td>
							<td><a href="?show=user_edit&id_uzivatel=<?php echo $temp['id_uzivatel'];?>"><img src="files/edit.png" height="16px"></a></td>
						</tr>
						<?php
					}
				?>
				</table>
				</div>
			
				<?php
			} else echo "V systému nejsou žádní aktivní uživatelé.";
			?>
		</div>
		<?php
	} else echo "<p class=\"chyba\">Na toto nemáte přiřazená práva.</p>";
	?>