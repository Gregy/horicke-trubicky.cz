<?php
	$ok=0;
	if ($_POST['send_password']=="Poslat"){
		$error="";
		$email=$_POST['email'];

		
		if (empty($email))
			$error.="<p class=\"chyba\">Nebyl zadán email.</p>";
		
		if (empty($error)){
			$result=$sql->query("select * from user where email='$email'");
			if ($sql->num_rows($result)==0)	
				$error.="<p class=\"chyba\">E-mail databáze neobsahuje.</p>";
		}	
	}
	if ($error=="" && $_POST['send_password']=="Poslat"){
		$password=(chr (rand(65,90))).(chr (rand(65,90))).(chr (rand(65,90))).(chr (rand(65,90))).
					(chr (rand(65,90))).(chr (rand(65,90))).(chr (rand(65,90))).(chr (rand(65,90)));
		$md5_password=md5($password);
		$sql->query("update user set password='$md5_password' where email='$email'");
		$message="Dobry den,
	email - $email
	heslo - $password
	";
		if (mail($email, "Obal-tisk, s.r.o. výrobní software - nove heslo", $message))
			echo "Nový kód k Vašemu účtu Vám byl poslán na e-mail $email.<br />";
		$ok=1;
	} else if ($error!=""){
			echo "<hr />" . $error . "<hr />";
	}
	
	if ($ok==0){
		?>	
		Po zadání e-mailu Vám bude posláno nové heslo na e-mail.
		<form action="" method="post">
			<table cellspacing="0" cellpadding="5" border="0" width="60%">
				<tr>
					<td align="center"><b>E-mail</b></td>
					<td><input type="text" size="20" name="email" value="<?php echo $email;?>" /></td>
				</tr>
				<tr>
					<td><input type="submit" name="send_password" value="Poslat" /></td>
					<td></td>
				</tr>
				
			</table>
		</form>
		<?php 
	}
?>