<div class="definice">
<?
if (haveRight('FIRMY')){
	if (isset($_GET['id_firmy'])){
		global $sql;
		$temp = $sql->query_array("SELECT id_firmy, nazev_firmy, ulice, mesto, psc, stat, telefon, email, bank_uc_pred, bank_uc_za, ic, dic, spec_symb, kontaktni_osoba FROM firmy WHERE id_firmy='$_GET[id_firmy]'");
		$id_firmy = $temp['id_firmy'];
		$nazev_firmy = $temp['nazev_firmy'];
		$ulice = $temp['ulice'];
		$mesto = $temp['mesto'];
		$psc = $temp['psc'];
		$stat = $temp['stat'];
		$telefon = $temp['telefon'];
		$email = $temp['email'];
		$bank_uc_pred = $temp['bank_uc_pred'];
		$bank_uc_za = $temp['bank_uc_za'];
		$ic = $temp['ic'];
		$dic = $temp['dic'];
		$spec_symb = $temp['spec_symb'];
		$kontaktni_osoba = $temp['kontaktni_osoba'];
	}
	
	if ($_POST['save']=="Uložit"){
		$error="";
		if (isset($_POST['id_firmy']))
			$id_firmy = $_POST['id_firmy'];
		$nazev_firmy = $_POST['nazev_firmy'];
		$ulice = $_POST['ulice'];
		$mesto = $_POST['mesto'];
		$psc = $_POST['psc'];
		$stat = $_POST['stat'];
		$telefon = $_POST['telefon'];
		$email = $_POST['email'];
		$bank_uc_pred = $_POST['bank_uc_pred'];
		$bank_uc_za = $_POST['bank_uc_za'];
		$ic = $_POST['ic'];
		$dic = $_POST['dic'];
		$spec_symb = $_POST['spec_symb'];
		$kontaktni_osoba = $_POST['kontaktni_osoba'];
		
		$error.=(empty($nazev_firmy)) ? "<p class=\"chyba\">Nebyl zadán název firmy.</p>" : "";
		$error.=(empty($ulice)) ? "<p class=\"chyba\">Nebyla zadána ulice.</p>" : "";
		$error.=(empty($mesto)) ? "<p class=\"chyba\">Nebylo zadáno město.</p>" : "";
		$error.=(empty($psc)) ? "<p class=\"chyba\">Nebylo zadáno PSČ.</p>" : "";
		$error.=(empty($stat)) ? "<p class=\"chyba\">Nebyl zadán stát.</p>" : "";
		//$error.=(empty($email)) ? "<p class=\"chyba\">Nebyl zadán email.</p>" : "";
	}
	
	if ($error=="" && $_POST['save']=="Uložit"){
		$nazev_firmy=check_input($nazev_firmy);
		$datum_editace = Time();
		if (isset($id_firmy)){
			$sql->query("UPDATE firmy SET nazev_firmy='$nazev_firmy', editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace', ulice='$ulice', mesto='$mesto', 
							psc='$psc',  stat='$stat',  telefon='$telefon',  email='$email',  bank_uc_pred='$bank_uc_pred',  bank_uc_za='$bank_uc_za', ic='$ic', dic='$dic', spec_symb='$spec_symb',
							kontaktni_osoba='$kontaktni_osoba' WHERE id_firmy=$id_firmy");
		} else {
				$sql->query("INSERT INTO firmy VALUES (NULL, '$nazev_firmy', '$_SESSION[ot_userId]', '$datum_editace', '0', '$ulice', '$mesto', '$psc', '$stat', '$telefon', '$email', '$ic', '$dic', '$bank_uc_pred', '$bank_uc_za', '$spec_symb', '$kontaktni_osoba')");
				$id_firmy=$sql->insert_id();
		}
		
		if (isset($_GET['id_zakazky'])){
			$sql->query("UPDATE zakazky SET nazev_firmy='$nazev_firmy', editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace', ulice='$ulice', mesto='$mesto', 
							psc='$psc', stat='$stat', telefon='$telefon', email='$email', bank_uc_pred='$bank_uc_pred',  bank_uc_za='$bank_uc_za', ic='$ic', dic='$dic', spec_symb='$spec_symb',
							kontaktni_osoba='$kontaktni_osoba' WHERE id_zakazky=$_GET[id_zakazky]");
		}
		
		$saved=1;
		echo "<p class=\"oznameni\">Odběratel v pořádku uložen.</p>";
		if (isset($_GET['id_zakazky'])){
			$refresh_page=$page->_head_path . "?show=zakazka_edit&id_zakazky=" . $_GET['id_zakazky'];
		} else {
			$refresh_page=$page->_head_path . "?show=firmy";
		}
		echo "<meta http-equiv=\"refresh\" content=\"1; url=$refresh_page\">";
		message_auto_forward($refresh_page);
	} else if ($error!=""){
		echo "<hr /><b>" . $error . "</b><hr />";
	}
		
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	if (isset($_POST['save_adresa'])){
		$error_under="";
		if (isset($_POST['id_firmy']))
			$id_firmy = $_POST['id_firmy'];
		$sub_jmeno = $_POST['sub_jmeno'];
		$sub_prijmeni = $_POST['sub_prijmeni'];
		$sub_nazev_adresy = $_POST['sub_nazev_adresy'];
		$sub_ulice = $_POST['sub_ulice'];
		$sub_mesto = $_POST['sub_mesto'];
		$sub_psc = $_POST['sub_psc'];
		$sub_stat = $_POST['sub_stat'];
		$sub_poznamka = $_POST['sub_poznamka'];
		$sub_email = $_POST['sub_email'];
		$sub_telefon = $_POST['sub_telefon'];
		
		$error_under.=(empty($sub_nazev_adresy)) ? "<p class=\"chyba\">Není zadán název dodací adresy.</p>" : "";
		//$error_under.=(empty($sub_jmeno)) ? "<p class=\"chyba\">Není zadáno jméno.</p>" : "";
		//$error_under.=(empty($sub_prijmeni)) ? "<p class=\"chyba\">Není zadáno příjmení.</p>" : "";
		$error_under.=(empty($sub_ulice)) ? "<p class=\"chyba\">Není zadána ulice.</p>" : "";
		$error_under.=(empty($sub_mesto)) ? "<p class=\"chyba\">Není zadáno město.</p>" : "";
		$error_under.=(empty($sub_psc)) ? "<p class=\"chyba\">Není zadáno PSČ.</p>" : "";
		$error_under.=(empty($sub_stat)) ? "<p class=\"chyba\">Není zadán stát.</p>" : "";
		//$error_under.=(empty($sub_email)) ? "<p class=\"chyba\">Není zadán email.</p>" : "";
	}
	
	if ($error_under=="" && isset($_POST['save_adresa'])){
		$datum_editace = Time();
		$sql->query("INSERT INTO adresy VALUES (NULL ,  '$id_firmy',  '$sub_jmeno',  '$sub_prijmeni',  '$sub_nazev_adresy',  '$sub_ulice',  '$sub_mesto',  '$sub_psc',  '$sub_stat',  '$sub_poznamka',  '$sub_email',  '$sub_telefon',  '$_SESSION[ot_userId]', $datum_editace, '0')");
		//unset($id_materialu);
	} else if ($error_under!=""){
		echo "<hr /><b>" . $error_under . "</b><hr />";
	}
	
	if (isset($_GET['smaz_id'])){
		$datum_editace = Time();
		$sql->query("UPDATE adresy SET smazano=1, editoval='$_SESSION[ot_userId]', datum_editace=$datum_editace WHERE id_adresy=$_GET[smaz_id]");
		//echo "<p class=\"oznameni\">Dodací adresa byla odstraněna.</p>";
	}
		
		if ($saved==0){
?>
		<form action="" method="post" name="firma">
			<div style="text-align: center; padding: 5px; border-bottom: #aaa 1px dashed;">
				<input type="submit" name="save" value="Uložit" id="ulozit" />
				<span style="padding-left: 100px">
					<?
					if (isset($_GET['id_zakazky'])){
						?>
						<a href="?show=zakazka_edit&id_zakazky=<?echo $_GET['id_zakazky'];?>" class="zpet">Zpět na editaci zakázky (bez uložení)</a>
						<?
					} else {
						?>
						<a href="?show=firmy" class="zpet">Zpět na seznam odběratelů a výrobků (bez uložení)</a>
						<?
					}
					?>
				</span>
			</div>
			
			<?php
				if (isset($id_firmy)){
					?>
					<input type="hidden" name="id_firmy" value="<?echo $id_firmy;?>" />
					<?
				}
			?>
			<table cellspacing="0" cellpadding="5" border="0" width="100%" align="center">
				<tr>
					<td style="text-align: right"><b>Název odběratele</b> (*)</td>
					<td colspan=2><input id="nazev_firmy" type="text" size="50" maxlength="100" name="nazev_firmy" value="<?php echo "$nazev_firmy";?>" /></td>
				</tr>
				<tr>
					<td colspan=3 style="font-weight: bold; color: #00F;">Fakturační adresa:</td>
				</tr>
				<tr>
					<td><b>Ulice</b> (*)<br /><input id="ulice" type="text" size="30" maxlength="100" name="ulice" value="<?php echo "$ulice";?>" /></td>
					<td><b>Telefon</b><br /><input id="telefon" type="text" size="20" maxlength="20" name="telefon" value="<?php echo "$telefon";?>" /></td>
					<td><b>IČ</b><br /><input id="ic" type="text" size="10" maxlength="20" name="ic" value="<?php echo "$ic";?>" /></td>
				</tr>
				<tr>
					<td><b>Město</b> (*)<br /><input id="mesto" type="text" size="30" maxlength="100" name="mesto" value="<?php echo "$mesto";?>" /></td>
					<td><b>Email</b><br /><input id="email" type="text" size="30" maxlength="100" name="email" value="<?php echo "$email";?>" /></td>
					<td><b>DIČ</b><br /><input id="dic" type="text" size="10" maxlength="20" name="dic" value="<?php echo "$dic";?>" /></td>
				</tr>
				<tr>
					<td><b>PSČ</b> (*)<br /><input id="psc" type="text" size="5" maxlength="10" name="psc" value="<?php echo "$psc";?>" /></td>
					<td><b>Bankovní účet</b><br /><input id="bank_uc_pred" type="text" size="10" maxlength="15" name="bank_uc_pred" value="<?php echo "$bank_uc_pred";?>" /> / <input id="bank_uc_za" type="text" size="5" maxlength="4" name="bank_uc_za" value="<?php echo "$bank_uc_za";?>" /></td>
					<td><b>Specifický symbol</b><br /><input id="spec_symb" type="text" size="20" maxlength="50" name="spec_symb" value="<?php echo "$spec_symb";?>" /></td>
				</tr>
				<tr>
					<td><b>Stát</b> (*)<br /><input id="stat" type="text" size="5" maxlength="50" name="stat" value="<?php echo "$stat";?>" /></td>
					<td><b>Kontaktní osoba</b><br /><input id="kontaktni_osoba" type="text" size="30" maxlength="100" name="kontaktni_osoba" value="<?php echo "$kontaktni_osoba";?>" /></td>
					<td></td>
				</tr>
			</table>
		<script type="text/javascript"> document.getElementById("nazev_firmy").focus(); </script>
		
		<hr />
		
		
		
		<?
		if (isset($id_firmy)){
			$rows = $sql->query("SELECT a.id_adresy, a.jmeno, a.prijmeni, a.nazev_adresy, a.ulice, a.mesto, a.psc, a.stat, a.poznamka, a.email, a.telefon, u.name editoval, a.datum_editace  FROM adresy a
								JOIN user u ON u.id_uzivatel = a.editoval
								WHERE a.id_firmy=$id_firmy and a.smazano=0
								ORDER BY a.nazev_adresy");
			if ($sql->num_rows($rows)>0){
				?>
					<table cellspacing="0" cellpadding="5" border="0" width="100%" align="center">
						<tr style="text-align:center; background-color: <?echo $color;?>;">
							<tr>
								<td colspan=2 style="font-weight: bold; color: #00F;">
									Dodací adresy:
									<?
									if (isset($_GET['id_zakazky'])){
										?>
										(zaškrtnutím adresy ji zvolíte do zakázky - zaškrtněte pouze jednu)
										<?
									}
									?>
								</td>
							</tr>
					</table>
					<table cellspacing="0" cellpadding="5" border="0" width="100%" align="center">
					<?
					$i=0;
					while ($row=$sql->fetch_array($rows)){
						(($i % 2)==0) ? $color="#DDD" : $color="#FFF";
						$i++;
						$datum_editace = StrFTime("%d.%m.%Y %H:%M", $row['datum_editace']);
						?>
						<tr style="text-align:center; background-color: <?echo $color;?>;">
							<td style="font-weight: bold;">
								<?echo $row['nazev_adresy'];?>
							</td>
							<td>
								<?
									echo $row['jmeno'] . ", " . $row['prijmeni'] . ", " . $row['ulice'] . ", " . $row['mesto'] . ", " . $row['psc'] . ", " . 
										$row['stat'] . ", " . $row['email'] . ", " . $row['telefon'] . ", " . $row['poznamka'];
								?>
							</td>
							<td style="width: 100px;">
								<span style="cursor: pointer;" id="odkaz_smazat_<?echo $row['id_adresy'];?>"	onClick="ukaz_form_smazat(<?echo $row['id_adresy'];?>)"
								title="Vytvořil(a) <?echo $row['editoval'] . ' ' . $datum_editace;?>">
									<img src="files/smazat.png" height="16px">
								</span>
								<br />
								<span id="smazat_<?echo $row['id_adresy'];?>" style="display: none;">
									<a href="?show=firma_edit&id_firmy=<?echo $id_firmy; if (isset($_GET['id_zakazky'])){echo "&id_zakazky=$_GET[id_zakazky]";}?>&smaz_id=<?echo $row['id_adresy'];?>">Ano</a>
									<a style="margin-left: 20px;" href="javascript:void(0)" onclick="skryj_form_smazat(<?echo $row['id_adresy'];?>)">Ne</a>
								</span>
							</td>
						</tr>
						<?
					}
				?>
				</table>
				<?
			} else {
				echo "<p class=\"oznameni\">Dodací adresy zatím nejsou zadané.</p>";
			}
			?>
			</form>
			<a id="nova_adresa" style="margin-left: 20px;" href="javascript:void(0)" onclick="ukaz_skryj('dodaci_adresa'); ukaz_skryj('nova_adresa')">Vložit novou dodací adresu</a>
			
			<form action="" method="post" id="dodaci_adresa" style="display: none;">
				<?
					if (isset($id_firmy)){
						?>
						<input type="hidden" name="id_firmy" value="<?echo $id_firmy;?>" />
						<?
					}
				?>
				<div style="text-align: left; margin-top: 20px; padding: 5px; border-bottom: #aaa 1px dashed;border-top: #aaa 1px dashed;">
					<table cellspacing="0" cellpadding="5" border="0" width="50%">
						<tr>
							<td><b>Název dodací adresy</b> (*)</td>
							<td><input id="sub_nazev_adresy" type="text" size="30" maxlength="100" name="sub_nazev_adresy" value="<?php echo "$sub_nazev_adresy";?>" /></td>
						</tr>
						<tr>
							<td><b>Jméno</b></td>
							<td><input id="sub_jmeno" type="text" size="20" maxlength="50" name="sub_jmeno" value="<?php echo "$sub_jmeno";?>" /></td>
						</tr>
						<tr>
							<td><b>Příjmení</b></td>
							<td><input id="sub_prijmeni" type="text" size="20" maxlength="50" name="sub_prijmeni" value="<?php echo "$sub_prijmeni";?>" /></td>
						</tr>
					</table>	
					<table cellspacing="0" cellpadding="5" border="0" width="70%">
						<tr>
							<td><b>Ulice</b> (*)<br /><input id="sub_ulice" type="text" size="20" maxlength="50" name="sub_ulice" value="<?php echo "$sub_ulice";?>" /></td>
							<td><b>Město</b> (*)<br /><input id="sub_mesto" type="text" size="20" maxlength="50" name="sub_mesto" value="<?php echo "$sub_mesto";?>" /></td>
							<td><b>Email</b><br /><input id="sub_email" type="text" size="30" maxlength="100" name="sub_email" value="<?php echo "$sub_email";?>" /></td>
						</tr>
						<tr>
							<td><b>PSČ</b> (*)<br /><input id="sub_psc" type="text" size="5" maxlength="10" name="sub_psc" value="<?php echo "$sub_psc";?>" /></td>
							<td><b>Stát</b> (*)<br /><input id="sub_stat" type="text" size="20" maxlength="50" name="sub_stat" value="<?php echo "$sub_stat";?>" /></td>
							<td><b>Telefon</b><br /><input id="sub_telefon" type="text" size="10" maxlength="20" name="sub_telefon" value="<?php echo "$sub_telefon";?>" /></td>
						</tr>
						<tr>
							<td colspan=3><b>Poznámka</b><br /><input id="sub_poznamka" type="text" size="80" maxlength="500" name="sub_poznamka" value="<?php echo "$sub_poznamka";?>" /></td>
						</tr>
					</table>
					
					<div>
						<input type="submit" name="save_adresa" value="Vložit dodací adresu" id="ulozit" />
					</div>
				</div>
			</form>
			
			<?
		} else {
			?>
			</form>
			<?
		}
		?>
		
		<br /><br />(*) - povinné položky
		<?
		}
} else echo "<p class=\"chyba\">Na toto nemáte přiřazená práva.</p>";
?>
</div>