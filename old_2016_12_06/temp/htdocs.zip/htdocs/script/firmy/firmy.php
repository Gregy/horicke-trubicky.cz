<div class="definice">
<?
if (haveRight('FIRMY')){
	include_once 'script/main/submenu.php';
	
	if (isset($_GET['smaz_id'])){
		$datum_editace = Time();
		$sql->query("UPDATE vyrobky SET smazano=1, editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace' WHERE id_firmy=$_GET[smaz_id]");
		$sql->query("UPDATE firmy SET smazano=1, editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace' WHERE id_firmy=$_GET[smaz_id]");
		echo "<p class=\"oznameni\">Firma a její výrobky jsou smazány.</p>";
	}
	
	if (isset($_GET['smaz_id_vyrobku'])){
		$datum_editace = Time();
		$sql->query("UPDATE vyrobky SET smazano=1, editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace' WHERE id_vyrobku=$_GET[smaz_id_vyrobku]");
	}
	
	if (isset($_GET['kopirovat_id_vyrobku'])){
		$datum_editace = Time();
		$temp = $sql->query_array("SELECT nazev_vyrobku	FROM vyrobky WHERE id_vyrobku=$_GET[kopirovat_id_vyrobku]");
		$novy_nazev = "Kopie - " . $temp['nazev_vyrobku'];
		$sql->query("INSERT INTO vyrobky
					SELECT NULL, '$novy_nazev', id_firmy, '$_SESSION[ot_userId]', $datum_editace, smazano, id_baleni, id_lakovani, barevnost, konstrukce_obalu, cislo_vykresu 
						FROM vyrobky WHERE id_vyrobku=$_GET[kopirovat_id_vyrobku]");
		$nove_id_vyrobku = $sql->insert_id();
		
		$materialy = $sql->query("SELECT id_vyrobek_material FROM vyrobek_material WHERE id_vyrobku=$_GET[kopirovat_id_vyrobku]");
		while ($material = $sql->fetch_array($materialy)){
			$sql->query("INSERT INTO vyrobek_material
						SELECT NULL, $nove_id_vyrobku, id_materialu, razeni, '$_SESSION[ot_userId]', $datum_editace, hodnota 
							FROM vyrobek_material 
						WHERE id_vyrobek_material=$material[id_vyrobek_material]");
			$nove_id_vyrobek_material = $sql->insert_id();
			
			$sql->query("INSERT INTO vyrobek_material_atribut
						SELECT NULL, id_atributu, $nove_id_vyrobek_material, hodnota, '$_SESSION[ot_userId]', $datum_editace 
							FROM vyrobek_material_atribut 
						WHERE id_vyrobek_material=$material[id_vyrobek_material]");
		}
		$sql->query("INSERT INTO vyrobek_vysekove_formy
					SELECT NULL, id_vysekove_formy, $nove_id_vyrobku
					FROM vyrobek_vysekove_formy 
					WHERE id_vyrobku=$_GET[kopirovat_id_vyrobku]");
		$sql->query("INSERT INTO vyrobek_operace_vnejsi
					SELECT $nove_id_vyrobku, id_operace_vnejsi, poznamka 
					FROM vyrobek_operace_vnejsi 
					WHERE id_vyrobku=$_GET[kopirovat_id_vyrobku]");
		
		$sql->query("INSERT INTO vyrobek_operace_vnitrni
					SELECT $nove_id_vyrobku, id_operace_vnitrni, poznamka 
					FROM vyrobek_operace_vnitrni 
					WHERE id_vyrobku=$_GET[kopirovat_id_vyrobku]");
	}
	
	?>
	<div style="width: 100%; text-align:center; padding-bottom: 5px; font-size: 15px;">
		<div class="firmy" style="float: left;">
			<a href="?show=firma_edit">Nový odběratel</a>
			<a href="?show=vyrobek_edit" style="margin-left: 100px">Nový výrobek</a>
		</div>
	</div>
	<?
	$rows = $sql->query("SELECT f.id_firmy, f.nazev_firmy, f.datum_editace, u.name editoval FROM firmy f
							JOIN user u ON u.id_uzivatel = f.editoval
						WHERE f.smazano=0
						ORDER BY nazev_firmy");
						
	?>
	<table cellspacing="0" cellpadding="5" border="0" width="60%" align="center">
		<?
		$i=0;
		while ($row=$sql->fetch_array($rows)){
			(($i % 2)==0) ? $color="#ffc2c2" : $color="#fff5f5";
			$i++;
			$datum_editace = StrFTime("%d.%m.%Y %H:%M", $row['datum_editace']);
			?>
			<tr style="background-color: <?echo $color;?>; cursor: pointer;">
				<td>
					<span onclick="ukaz_skryj('trow<?echo $row['id_firmy'];?>');" title="kliknutím zobrazíte/skryjete detail" style="cursor: pointer; font-weight: bold;">
						<?echo $row['nazev_firmy'];?>
					</span>
				</td>
				<td>
					<a href="?show=firma_edit&id_firmy=<?echo $row['id_firmy'];?>" style="text-decoration: none;" title="Naposledy editoval(a) <?echo $row['editoval'] . ' ' . $datum_editace;?>"><img src="files/edit.png" height="16px"></a>
				</td>
				<td style="width: 100px; text-align:center;">
					<span style="cursor: pointer;" id="odkaz_smazat_<?echo $row['id_firmy'];?>"	onClick="ukaz_form_smazat(<?echo $row['id_firmy'];?>)">
						<img src="files/smazat.png" height="16px">
					</span>
					<br />
					<span id="smazat_<?echo $row['id_firmy'];?>" style="display: none;">
						<a href="?show=firmy&smaz_id=<?echo $row['id_firmy'];?>">Ano</a>
						<a style="margin-left: 20px;" href="javascript:void(0)" onclick="skryj_form_smazat(<?echo $row['id_firmy'];?>)">Ne</a>
					</span>
				</td>
			</tr>
			<tr style="background-color: <?echo $color;?>;" >
				<td colspan="3">
					<?
					if ($_GET['id_firmy'] == $row['id_firmy']){
						$display="block";
					} else {
						$display="none";
					}
					?>
					<table cellspacing="0" cellpadding="5" style="display: <?echo $display;?>;" id="trow<?echo $row['id_firmy'];?>">
						<?
						$vyrobky = $sql->query("SELECT v.id_vyrobku, v.nazev_vyrobku, u.name editoval, v.datum_editace FROM vyrobky v
												JOIN user u ON u.id_uzivatel = v.editoval
												WHERE id_firmy=$row[id_firmy] and smazano=0");
						$j=0;
						while ($vyrobek=$sql->fetch_array($vyrobky)){
							(($j % 2)==0) ? $color="#CCC" : $color="#EEE";
							$j++;
							$datum_editace = StrFTime("%d.%m.%Y %H:%M", $vyrobek['datum_editace']);
							?>
							<tr style="background-color: <?echo $color;?>;">
								<td style="width: 300px;">
									<?
									echo $vyrobek['nazev_vyrobku'];
									?>
								</td>
								<td>
									<a href="?show=vyrobek_edit&id_vyrobku=<?echo $vyrobek['id_vyrobku'];?>" style="text-decoration: none;" title="Naposledy editoval(a) <?echo $vyrobek['editoval'] . ' ' . $datum_editace;?>"><img src="files/edit.png" height="16px"></a>
								</td>
								<td style="width: 100px; text-align:center;">
									<span style="cursor: pointer;" id="odkaz_kopirovat_<?echo $vyrobek['id_vyrobku'];?>" onClick="ukaz_form_kopirovat_vyrobek(<?echo $vyrobek['id_vyrobku'];?>)">
										<img src="files/copy.png" height="16px" title="Kopírovat výrobek" />
									</span>
									<br />
									<span id="kopirovat_vyrobek_<?echo $vyrobek['id_vyrobku'];?>" style="display: none;">
										<a href="?show=firmy&id_firmy=<?echo $row['id_firmy'];?>&kopirovat_id_vyrobku=<?echo $vyrobek['id_vyrobku'];?>">Ano</a>
										<a style="margin-left: 20px;" href="javascript:void(0)" onclick="skryj_form_kopirovat_vyrobek(<?echo $vyrobek['id_vyrobku'];?>)">Ne</a>
									</span>
								</td>
								<td style="width: 100px; text-align:center;">
									<span style="cursor: pointer;" id="odkaz_smazat_<?echo $vyrobek['id_vyrobku'];?>" onClick="ukaz_form_smazat_vyrobek(<?echo $vyrobek['id_vyrobku'];?>)">
										<img src="files/smazat.png" height="16px" title="Smazat výrobek" />
									</span>
									<br />
									<span id="smazat_vyrobek_<?echo $vyrobek['id_vyrobku'];?>" style="display: none;">
										<a href="?show=firmy&id_firmy=<?echo $row['id_firmy'];?>&smaz_id_vyrobku=<?echo $vyrobek['id_vyrobku'];?>">Ano</a>
										<a style="margin-left: 20px;" href="javascript:void(0)" onclick="skryj_form_smazat_vyrobek(<?echo $vyrobek['id_vyrobku'];?>)">Ne</a>
									</span>
								</td>
							</tr>
							<?
						}
						?>
					</table>
				</td>
			</tr>
			<?
		}
		?>
	</table>
	<?
} else echo "<p class=\"chyba\">Na toto nemáte přiřazená práva.</p>";
?>
</div>