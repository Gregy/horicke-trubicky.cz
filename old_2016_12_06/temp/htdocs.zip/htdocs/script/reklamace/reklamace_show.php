<?
if (haveRight('REKLAMACE')){
	if (isset($_GET['id_reklamace'])){
		global $sql;
		$temp=$sql->query_array("SELECT distinct r.id_reklamace, r.cislo_reklamace, r.rok_reklamace, r.pocet, z.nazev_firmy, zv.nazev_vyrobku, sr.nazev_stavu
								FROM reklamace r
								JOIN zak_vyrobky zv ON zv.id_zak_vyrobku = r.id_zak_vyrobku
								JOIN zakazky z ON z.id_zakazky = zv.id_zakazky
								JOIN stavy_rek sr ON sr.id_stavu = r.id_stavu
								WHERE r.id_reklamace = '$_GET[id_reklamace]'
								LIMIT 1");
								
		$id_reklamace = $temp['id_reklamace'];
	}
	if (isset($_POST['add_zapis'])){
		$error_under="";
		if ($_POST['id_stavu']>0) {
			$id_stavu = $_POST['id_stavu'];
			$zapis_txt = $_POST['zapis_txt'];
		} else {
			$error_under.="<p class=\"chyba\">Vyberte stav.</p>";
		}
	}
	
	if ($error_under=="" && (isset($_POST['add_zapis']))){
		$datum_editace = Time();
		
		$sql->query("INSERT INTO rek_zapisy VALUES (NULL, '$id_reklamace', '$id_stavu', '$zapis_txt', '$_SESSION[ot_userId]', $datum_editace, 0)");
		if ($id_stavu!=500){
			$sql->query("UPDATE reklamace SET id_stavu='$id_stavu', editoval='$_SESSION[ot_userId]', datum_editace=$datum_editace WHERE id_reklamace=$id_reklamace");
		}
		unset($id_stavu);
		unset($zapis_txt);
	} else if ($error_under!=""){
		echo "<hr /><b>" . $error_under . "</b><hr />";
	}
	
	$datum_editace = StrFTime("%d.%m.%Y", $temp['datum_editace']);
	
	if (!is_print_mod()){
		?>
		<div style="text-align: center; padding: 5px; border-bottom: #aaa 1px dashed;">
			<span> 
				<a href="?show=reklamace" class="zpet">Do reklamací</a>
			</span>
		</div>
		<?
	}
	?>
	<table cellspacing="0" cellpadding="5" border="1" width="95%" align="center">
		<tr style="text-align: center; font-size: 22px; font-weigt: bold;">
			<td colspan="3">
				<?
				if (is_print_mod()){
					?>
					<img src="files/logo_velke.png" height="100px" /><br />
					<?
				}
				?>
				<span style="padding-right: 200px;">Reklamace</span>
				<span>Číslo: <?echo cislo_rok($temp['cislo_reklamace'], $temp['rok_reklamace']); ?></span>
			</td>
		</tr>
		<tr style="font-size: 14px; vertical-align: top;">
			<td style="font-weight: bold;">
				Odběratel:
			</td>
			<td colspan="2">
				<?
				echo $temp['nazev_firmy'];
				?>
			</td>
		</tr>
		<tr>
			<td colspan="3"></td>
		</tr>
		<tr style="font-size: 14px; vertical-align: top;">
			<td style="font-weight: bold;">
				Výrobek:
			</td>
			<td>
				<?
				echo $temp['nazev_vyrobku'];
				?>
			</td>
			<td>
				<b>Počet ks</b><br />
				<?
				$pocet = $temp['pocet'];
				if (haveRight('REKLAMACE_NOVY_ZAPIS') && !is_print_mod()){
					?>
					<input type="text" size="4" maxlength="7" name="pocet" id="pocet" value="<?echo $pocet;?>"
						onblur="ajax('script/reklamace/aj_pocet.php?id_reklamace=<?echo $temp['id_reklamace'];?>&pocet='+document.getElementById('pocet').value,'pocet_result');" />
					<span id="pocet_result" style="width: 16px"></span>
					<?
				} else {
					echo number_format($pocet, 0, '.', ' ');
				}
				?>
			</td>
		</tr>
		<tr>
			<td colspan="3"></td>
		</tr>
		<?
		$zapisy = $sql->query("SELECT rz.id_rek_zapisu, rz.popis, rz.datum_editace, sr.nazev_stavu, u.name, rz.id_stavu
								FROM rek_zapisy rz
								JOIN stavy_rek sr ON sr.id_stavu = rz.id_stavu
								JOIN user u ON u.id_uzivatel = rz.editoval
								WHERE rz.smazano=0 
									AND rz.id_reklamace='$_GET[id_reklamace]'");
		if ($sql->num_rows($zapisy)>0){
			?>
			<tr style="font-size: 12px; vertical-align: top;">
				<td style="width: 100px;">
					Stav
				</td>
				<td>
					Poznámka
				</td>
				<td style="width: 100px;">
					Zápis provedl
				</td>
			</tr>
			<?
			while ($zapis = $sql->fetch_array($zapisy)){
				$datum_editace = StrFTime("%d.%m.%Y %H:%M", $zapis['datum_editace']);
				if (!is_print_mod() || $zapis['id_stavu']!=500){
				?>
				<tr style="font-size: 12px; vertical-align: top;">
					<td>
						<?
						echo $zapis['nazev_stavu'];
						?>
					</td>
					<td>
						<?
						echo $zapis['popis'];
						
						if (haveRight("REKLAMACE_EDITACE_ZAPISU") && !is_print_mod()){
							?>
							<br />
							<span style="cursor: pointer;" id="odkaz_smazat_<?echo $zapis['id_rek_zapisu'];?>"	onClick="ukaz_form_smazat(<?echo $zapis['id_rek_zapisu'];?>)">
								<img src="files/smazat.png" height="16px">
							</span>
							<br />
							<span id="smazat_<?echo $zapis['id_rek_zapisu'];?>" style="display: none;">
								<a href="?show=reklamace_show&smaz_id=<?echo $zapis['id_rek_zapisu'];?>">Ano</a>
								<a style="margin-left: 20px;" href="javascript:void(0)" onclick="skryj_form_smazat(<?echo $zapis['id_rek_zapisu'];?>)">Ne</a>
							</span>
							<?
						}
						?>
					</td>
					<td>
						<?
						echo $datum_editace . "<br />" . $zapis['name'];
						?>
					</td>
				</tr>
				<?
				}
			}
		}
		?>
	</table>
	<?
	if (!is_print_mod()){
		?>
		<form action="" method="post" name="zapis">				
			<?php
				if (isset($id_reklamace)){
					?>
					<input type="hidden" name="id_reklamace" value="<?echo $id_reklamace;?>" />
					<?
				}
			?>
			<table cellspacing="0" cellpadding="5" border="0" width="50%" align="">
				<tr>
					<td><b>Stav</b></td>
					<td>
						<select name="id_stavu" >
							<OPTION value="0">Vyberte možnost...</OPTION>
							<?
							$result=$sql->query("SELECT id_stavu, nazev_stavu
												FROM stavy_rek sr
												ORDER BY id_stavu");
							while ($row=$sql->fetch_array($result)){
								if ($row['id_stavu'] == $id_stavu){
									?>
									<OPTION value="<?echo $row['id_stavu'];?>" selected="selected"><?echo $row['nazev_stavu'];?></OPTION>
									<?
								} else {
									?>
									<OPTION value="<?echo $row['id_stavu'];?>"><?echo $row['nazev_stavu'];?></OPTION>
									<?
								}
							}
							?>
						</select>
					</td>
				</tr>
				<tr>
					<td><b>Zápis</b></td>
					<td><textarea name="zapis_txt" maxlength="200" cols="70" rows="3"><?echo $zapis_txt;?></textarea></td>
				</tr>
				
			</table>
			<div>
				<input type="submit" name="add_zapis" value="Vložit nový stav" id="ulozit" />
			</div>
		</form>
		<?
	}
}
?>