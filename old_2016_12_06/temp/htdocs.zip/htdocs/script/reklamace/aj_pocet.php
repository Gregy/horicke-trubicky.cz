<?
	require_once '../../classes/class_mysql.php';
		$sql=new mysql;

	require_once '../../classes/class_user.php';
		$user=new classUser;
	
	require_once "../../includes/common.php";

	if (isset($_GET['id_reklamace']) && haveRight('REKLAMACE_NOVY_ZAPIS')){
		$pocet_temp = str_replace(",", ".", $_GET['pocet']);
		if (!empty($pocet_temp) && is_numeric($pocet_temp) && $pocet_temp!=0){
			$datum_editace = Time();
			$sql->query("UPDATE reklamace SET pocet='$pocet_temp', editoval='$_SESSION[ot_userId]', datum_editace=$datum_editace WHERE id_reklamace=$_GET[id_reklamace]");
			?>
			<img src="../../files/ok.png" height="13px" />
			<?
		}
		else {
			?>
			<img src="../../files/ko.png" height="13px" />
			<?
		}
	}
?>