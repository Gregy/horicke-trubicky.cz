<?
	require_once '../../classes/class_mysql.php';
	$sql=new mysql;
		
?>
	<select name="id_zak_vyrobku" >
		<OPTION value="0">Vyberte možnost...</OPTION>
		<?
		$result=$sql->query("SELECT id_zak_vyrobku, nazev_vyrobku
							FROM zak_vyrobky
							WHERE smazano=0 and id_zakazky=$_GET[id_zakazky]
							ORDER BY nazev_vyrobku");
		while ($row=$sql->fetch_array($result)){
			?>
			<OPTION value="<?echo $row['id_zak_vyrobku'];?>">
				<?
				echo $row['nazev_vyrobku'];
				?>
			</OPTION>
			<?
		}
		?>
	</select>
	