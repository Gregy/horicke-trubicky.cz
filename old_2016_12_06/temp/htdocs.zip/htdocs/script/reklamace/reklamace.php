<?
if (haveRight("REKLAMACE")){
	$datum_editace = Time();
	
	if (isset($_GET['id_firmy'])){
		$_SESSION['filtr_reklamaci']['filtr_id_firmy'] = $_GET['id_firmy'];
	}
	if (isset($_GET['cislo_reklamace'])){
		$_SESSION['filtr_reklamaci']['cislo_reklamace'] = $_GET['cislo_reklamace'];
	}
	if (isset($_GET['rok_reklamace'])){
		$_SESSION['filtr_reklamaci']['rok_reklamace'] = $_GET['rok_reklamace'];
	}
	
	if (isset($_GET['zrus_filtr'])){
		unset($_SESSION['filtr_reklamaci']);
	}
	
	if (haveRight("REKLAMACE_EDITACE_ZAPISU")){
		if (isset($_GET['smaz_id'])){
			$sql->query("UPDATE dodaci_listy SET smazano=1, editoval='$_SESSION[ot_userId]', datum_editace='$datum_editace' WHERE id_reklamace=$_GET[smaz_id]");
		}
	}
	
	if (haveRight("REKLAMACE_NOVY_ZAPIS")){
		?>
		<div style="width: 100%; text-align:center; padding-bottom: 5px; margin-bottom: 5px; font-size: 15px; border-bottom: 1px dashed;">
			<a href="?show=reklamace_new">Nová reklamace</a>
		</div>
		<?
	}
	?>
	<div onclick="ukaz_skryj('filtr_reklamaci');" style="cursor: pointer;">
		Zobraz / skryj filtr
		<?
		if (!empty($_SESSION['filtr_reklamaci']['filtr_id_firmy']) || !empty($_SESSION['filtr_reklamaci']['cislo_reklamace']) || !empty($_SESSION['filtr_reklamaci']['rok_reklamace'])){
				?> 
				<span style="padding-left: 200px; color: #D55; font-weight: bold;">Filtr je AKTIVNÍ</span>
				<a href="?show=reklamace&zrus_filtr=1" style="margin-left: 200px; color: #555; font-weight: bold;">Zrušit filtr</a>
				<?
		}
		?>
	</div>
	<div id="filtr_reklamaci" style="display: none;">
		<form action="" method="GET">
			<input type="hidden" name="show" value="reklamace">
			<table cellspacing="0" cellpadding="5" border="0" width="60%">
				<tr>
					<td>
						<b>Číslo reklamace / rok</b>
					</td>
					<td>
						<input id="cislo_reklamace" name="cislo_reklamace" type="text" value="<?echo $_SESSION['filtr_reklamaci']['cislo_reklamace'];?>" size="5" maxlength="5" />
						/
						<input id="rok_reklamace" name="rok_reklamace" type="text" value="<?echo $_SESSION['filtr_reklamaci']['rok_reklamace'];?>" size="5" maxlength="5" />
					</td>
				</tr>
				<tr>
					<td>
						<b>Pro firmu</b>
					</td>
					<td>
						<select id="id_firmy" name="id_firmy" onchange="ajax('script/reklamace/aj_nacist_vyrobky.php?id_firmy='+document.getElementById('id_firmy').value,'filtr_id_vyrobku');">
							<OPTION value="0">Vyberte možnost...</OPTION>
							<?
							$result=$sql->query("SELECT id_firmy, nazev_firmy FROM firmy
												ORDER BY nazev_firmy");
							while ($row=$sql->fetch_array($result)){
								if ($row['id_firmy'] == $_SESSION['filtr_reklamaci']['filtr_id_firmy']){
									?>
									<OPTION value="<?echo $row['id_firmy'];?>" selected="selected"><?echo $row['nazev_firmy'];?></OPTION>
									<?
								} else {
									?>
									<OPTION value="<?echo $row['id_firmy'];?>"><?echo $row['nazev_firmy'];?></OPTION>
									<?
								}
							}
							?>
						</select>
					</td>
				</tr>
			</table>
			<div style="padding: 5px;">
				<input type="submit" name="save" value="Použít filtr" id="inform" />
			</div>
		</form>
	</div>
	<?
	//$prvni=true;
	if (isset($_SESSION['filtr_reklamaci'])){
		if (!empty($_SESSION['filtr_reklamaci']['filtr_id_firmy'])){
			($prvni==false) ? $where .= " AND " : $where .= "";
			$where .= "z.id_firmy=" . $_SESSION['filtr_reklamaci']['filtr_id_firmy'];
			$prvni=false;
		}
		if (!empty($_SESSION['filtr_reklamaci']['cislo_reklamace'])){
			($prvni==false) ? $where .= " AND " : $where .= "";
			$where .= "r.cislo_reklamace=" . $_SESSION['filtr_reklamaci']['cislo_reklamace'];
			$prvni=false;
		}
		if (!empty($_SESSION['filtr_reklamaci']['rok_reklamace'])){
			($prvni==false) ? $where .= " AND " : $where .= "";
			$aktualni_cas=Time();
			$where .= "r.rok_reklamace=" . $_SESSION['filtr_reklamaci']['rok_reklamace'];
			$prvni=false;
		}
	} else {
		$where = "AND r.id_stavu<1000";
	}
	
	$where = " WHERE r.smazano = 0 " . $where;
	
	$rows = $sql->query("SELECT distinct r.id_reklamace, r.cislo_reklamace, r.rok_reklamace, z.nazev_firmy, zv.nazev_vyrobku, sr.nazev_stavu
						FROM reklamace r
						JOIN zak_vyrobky zv ON zv.id_zak_vyrobku = r.id_zak_vyrobku
						JOIN zakazky z ON z.id_zakazky = zv.id_zakazky
						JOIN stavy_rek sr ON sr.id_stavu = r.id_stavu
						$where
						ORDER BY r.rok_reklamace DESC, r.cislo_reklamace DESC");
	
	if ($sql->num_rows($rows)>0){
		?>
		<table cellspacing="0" cellpadding="5" border="0" width="70%" align="center">
			<tr style="text-align:center; font-weight:bold; border-bottom: 1px solid #555;">
				<td style="width: 90px;">Číslo reklamace</td>
				<td style="width: 150px;">Název firmy</td>
				<td style="width: 200px;">Výrobek</td>
				<td style="width: 50px;">Stav</td>
				<td style="width: 50px;"></td>
				<td></td>
			</tr>
			<?
			$i=0;
			while ($row=$sql->fetch_array($rows)){
				(($i % 2)==0) ? $color="#b0ffb0" : $color="#FFF";
				$i++;
				?>
				<tr style="text-align:center; background-color: <?echo $color;?>;">
					<td><?echo $row['cislo_reklamace'] . "/" . $row['rok_reklamace'];?></td>
					<td><?echo $row['nazev_firmy'];?></td>
					<td><?echo $row['nazev_vyrobku'];?></td>
					<td><?echo $row['nazev_stavu'];?></td>
					<td>
						<a style="text-decoration: none;" href="?show=reklamace_show&id_reklamace=<?echo $row['id_reklamace'];?>"><img src="files/show.png" title="Zobrazit reklamaci" height="18px" /></a>
					</td>
					<td style="width: 100px; text-align:center;">
						<?
						if (haveRight("REKLAMACE_EDITACE_ZAPISU")){
							?>
							<span style="cursor: pointer;" id="odkaz_smazat_<?echo $row['id_reklamace'];?>"	onClick="ukaz_form_smazat(<?echo $row['id_reklamace'];?>)">
								<img src="files/smazat.png" height="16px">
							</span>
							<br />
							<span id="smazat_<?echo $row['id_reklamace'];?>" style="display: none;">
								<a href="?show=reklamace&smaz_id=<?echo $row['id_reklamace'];?>">Ano</a>
								<a style="margin-left: 20px;" href="javascript:void(0)" onclick="skryj_form_smazat(<?echo $row['id_reklamace'];?>)">Ne</a>
							</span>
							<?
						}
						?>
					</td>
				</tr>
				<?
			}
			?>
		</table>
		<?
	}
}
?>