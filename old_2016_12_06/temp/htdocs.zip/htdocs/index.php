<?php
	@session_start();
	
	require_once 'classes/class_mysql.php';
	$sql=new mysql;
	
	require_once 'classes/class_page.php';
	$page=new page;
	
	require_once "includes/common.php";
	
	$_SESSION['last_page']=$_SESSION['actual_page'];
	$_SESSION['actual_page']=$_SERVER["REQUEST_URI"];
	
	if (!is_print_mod()) {
		include 'script/main/header.php';
	} else {
		include 'script/main/header_print.php';
	}
	
	include 'script/' . $page->_path_dir . '/' . $page->_path_file . '.php';
	
	if (!is_print_mod()) {
		include 'script/main/footer.php';
	} else {
		include 'script/main/footer_print.php';
	}
?>