<?php 
	function generate_menu() {
		global $user;
		global $sql;
		
		if (isset($_SESSION['id_menu'])){
			$id_category=$_SESSION['id_menu'];
		}
		
		if (isset($_SESSION['ot_userId'])) {
			$result=$sql->query("select id, name, link, right_needed, NULL from menu WHERE right_needed is NULL
								UNION
								SELECT m.id, m.name, m.link, m.right_needed, p.pravo FROM menu m
								JOIN prava p ON m.right_needed = p.pravo 
								JOIN uzivatel_prava up ON p.id_pravo = up.id_pravo
								AND up.id_uzivatel=$_SESSION[ot_userId]
								ORDER BY id");
			if ($sql->num_rows($result)>0){
				while ($temp=$sql->fetch_array($result)){
					($temp['id']==$id_category) ? $type="1" : $type="2";
					title($temp['name'], $type, $temp['link']);
				}
			}
		} else {
			$result=$sql->query("select * from menu WHERE right_needed is NULL order by id");
			if ($sql->num_rows($result)>0){
				while ($temp=$sql->fetch_array($result)){
					($temp['id']==$id_category) ? $type="1" : $type="2";
					title($temp['name'], $type, $temp['link']);
				}
			}
		}
		
		title("Tisk", 2, "$_SERVER[REQUEST_URI]&print=1\" target=\"_blank");
		
		
		
		if (isset($_SESSION['ot_userId'])) {
			($id_category==101) ? $type="1" : $type="2";
			title("Odhlášení", $type, "?show=user_logout");
		} else {
			($id_category==100) ? $type="1" : $type="2";
			title("Přihlášení", $type, "?show=user_login");
		}
	}
	
	function title($text, $type, $link){
		switch ($type){
			case "1":
				$left_image="files/menu_active_left.gif";
				$middle_image="files/menu_active_middle.gif";
				$right_image="files/menu_active_right.gif";
				$style_span1="width:10px; height:30px; float: left;";
				$style_span2="background-repeat: repeat-x; padding-top: 10px; padding-bottom: 10px; padding-left: 0px; padding-right: 0px; float: left; font-weight: bold;";
				$style_span3="width:10px; height:30px; float: left; margin-right: 10px;";
				$color="#FFF";
				break;
			case "2":
				$left_image="files/menu_passive_left.gif";
				$middle_image="files/menu_passive_middle.gif";
				$right_image="files/menu_passive_right.gif";
				$style_span1="width:10px; height:30px; float: left;";
				$style_span2="background-repeat: repeat-x; padding-top: 7px; padding-bottom: 13px; padding-left: 0px; padding-right: 0px; float: left;";
				$style_span3="width:10px; height:30px; float: left; margin-right: 10px;";
				$color="#000";
				break;
			case "3":
				$left_image="files/button_left.gif";
				$middle_image="files/button_middle.gif";
				$right_image="files/button_right.gif";
				$style_span1="width:8px; height:20px; float: left;";
				$style_span2="background-repeat: repeat-x; padding-top: 3px; padding-bottom: 3px; padding-left: 0px; padding-right: 0px; float: left;";
				$style_span3="width:8px; height:20px; float: left;";
				$color="#FFF";
				break;
		}
		?>
				<span style="background-image:  url('<?echo $left_image;?>'); <?echo $style_span1;?>"></span>
				
				<span style="background-image:  url('<?echo $middle_image;?>'); <?echo $style_span2;?>">
					<a style="text-decoration: none; color:<?echo $color;?>;"href="<? echo $link;?>"><?echo $text;?></a>
				</span>
				<span style="background-image:  url('<?echo $right_image;?>'); <?echo $style_span3;?>"></span>
		<?
	}
	
	function content_header(){
		?>
		<table cellspacing="0" cellpadding="0" border="0" width="100%" style="margin: 0px;padding: 0px;">
			<tr style="height: 10px;">
				<td style="width:10px; background-image: url('files/content_left_top.gif');
					background-repeat: no-repeat;"></td>
				<td style="background-color:#FFF; width:938px"></td>
				<td style="width:10px; background-image: url('files/content_right_top.gif');
					background-repeat: no-repeat;"></td>
			</tr>
		</table>
		<?
	}
	
	function content_footer(){
		?>
		<table cellspacing="0" cellpadding="0" border="0" width="100%">
			<tr style="height: 10px;">
				<td style="width:10px; background-image: url('files/content_left_bot.gif');
					background-repeat: no-repeat;"></td>
				<td style="background-color:#FFF;  width:938px"></td>
				<td style="width:10px; background-image: url('files/content_right_bot.gif');
					background-repeat: no-repeat;"></td>
			</tr>
		</table>
		<?
	}
	
	function delete_file ($file){
		if (file_exists($file))
			unlink ($file);
	}
	
	function check_input($text){
		$text=htmlspecialchars($text);
		
		return $text;
	}
	
	function message_auto_forward($refresh_page){
		echo "<div style=\"margin-top: 20px;\">Vyčkejte, budete automaticky přesměrováni na následující stránku.</div>";
		echo "Pokud ne, kliknete <a href=\"$refresh_page\">sem</a>";
	}
	
	function is_print_mod(){
		if (isset($_GET['print'])){
			return 1;
		} else {
			return 0;
		}
	}
	
	function zaskrtavaci_policko_o($popis, $nazev, $podminka, $barva, $poznamka){
		($podminka == 0) ? $background_color = "#FFF" : $background_color = $barva;
		?>
		<div id="<?echo $nazev;?>" style="background: <?echo $background_color;?>;" class="polozky" >
			<span style="cursor: pointer;" onclick="oznaceni_checkboxu('o_c_<?echo $nazev;?>'); zmen_barvu_pozadi_o('<?echo $nazev;?>', '<?echo $barva;?>');"><?echo $popis;?></span>
			<?
			if ($podminka==0){
				?>
				<input type="checkbox" size=2 id="o_c_<?echo $nazev;?>" name="o_c_<?echo $nazev;?>" onClick="zmen_barvu_pozadi_o('<?echo $nazev;?>', '<?echo $barva;?>');" />
				<?
			} else {
				?>
				<input type="checkbox" size=2 id="o_c_<?echo $nazev;?>" name="o_c_<?echo $nazev;?>" checked="checked" onClick="zmen_barvu_pozadi_o('<?echo $nazev;?>', '<?echo $barva;?>')" />
				<?
			}
			?>
			<br />
			<input type="text" size="20" id="o_t_<?echo $nazev;?>" name="o_t_<?echo $nazev;?>" style="margin-left: 10px" maxlength="100" value="<?echo $poznamka;?>" />
		</div>
		<?
	}
	
	function zaskrtavaci_policko_o_v($popis, $nazev, $podminka, $barva, $poznamka){
		($podminka == 0) ? $background_color = "#FFF" : $background_color = $barva;
		?>
		<div id="<?echo $nazev;?>" style="background: <?echo $background_color;?>;" class="polozky" >
			<span style="cursor: pointer;" onclick="oznaceni_checkboxu('o_c_<?echo $nazev;?>'); zmen_barvu_pozadi_o('<?echo $nazev;?>', '<?echo $barva;?>');"><?echo $popis;?></span>
			<?
			if ($podminka==0){
				?>
				<input type="checkbox" size=2 id="o_c_<?echo $nazev;?>" name="o_c_<?echo $nazev;?>" onClick="zmen_barvu_pozadi_o('<?echo $nazev;?>', '<?echo $barva;?>');" />
				<?
			} else {
				?>
				<input type="checkbox" size=2 id="o_c_<?echo $nazev;?>" name="o_c_<?echo $nazev;?>" checked="checked" onClick="zmen_barvu_pozadi_o('<?echo $nazev;?>', '<?echo $barva;?>')" />
				<?
			}
			?>
			<br />
			<input type="text" size="20" id="o_t_<?echo $nazev;?>" name="o_t_<?echo $nazev;?>" style="margin-left: 10px" maxlength="100" value="<?echo $poznamka;?>" />
		</div>
		<?
	}
	
	function barva($i){
		$barvy = array("#fdb9b9", "#b9c2fd", "#e4b9fd", "#fdfbb9", "#f3fdb9", "#fdb9f6", "#b9fdde", "#b9fdf7", "#b9dffd",
					   "#ccb9fd", "#fdd4b9", "#fdb9b9", "#cdfdb9", "#fdeab9");
		//$a = rand(0,count($barvy)-1);
		return $barvy[$i];
	}
	
	function haveRight($right){
		global $sql;
		$id_uzivatel=$_SESSION['ot_userId'];
		$rows=$sql->query("SELECT pravo FROM prava p
							JOIN uzivatel_prava up ON p.id_pravo = up.id_pravo
							WHERE up.id_uzivatel=$id_uzivatel");
		$i = 0;
		
		while($row = $sql->fetch_array($rows)){
			$rights[$i] = $row['pravo'];
			$i++;
		}
		
		if (isset($rights)){
			foreach ($rights as $row){
				if ($row == $right)
					return 1;
			}
		}
		return 0;
	}
	
	function is_owner ($id_user){
		if ($_SESSION['ot_userId']!=$id_user || $id_user==""){
			return 0;
		} else {
			return 1;
		}		
	}
	
	function cislo_rok($id_zakazky, $rok){
		$temp="";
		for($i=strlen($id_zakazky); $i<4; $i++){
			$temp.="0";
		}
		$temp=$temp . $id_zakazky . "/" . $rok;
		return $temp;
	}
?>